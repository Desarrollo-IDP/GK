<?php
// Archivo de prueba simple para Mercado Pago
include '../includes/db.php';
include '../includes/config.php';
include '../config/mercadopago_config.php';

initConfig();

echo "<h1>Prueba Simple de Mercado Pago</h1>";

try {
    // 1. Verificar que las credenciales estén configuradas
    echo "<h2>1. Verificando credenciales...</h2>";
    
    if (!defined('MP_ACCESS_TOKEN') || empty(MP_ACCESS_TOKEN)) {
        echo "<p style='color: red;'>❌ MP_ACCESS_TOKEN no está configurado</p>";
        exit;
    }
    
    if (!defined('MP_PUBLIC_KEY') || empty(MP_PUBLIC_KEY)) {
        echo "<p style='color: red;'>❌ MP_PUBLIC_KEY no está configurado</p>";
        exit;
    }
    
    echo "<p style='color: green;'>✅ Credenciales configuradas</p>";
    echo "<p>Access Token: " . substr(MP_ACCESS_TOKEN, 0, 10) . "...</p>";
    echo "<p>Public Key: " . MP_PUBLIC_KEY . "</p>";
    
    // 2. Inicializar Mercado Pago
    echo "<h2>2. Inicializando Mercado Pago...</h2>";
    mpInit();
    echo "<p style='color: green;'>✅ Mercado Pago inicializado</p>";
    
    // 3. Crear una preferencia de prueba simple
    echo "<h2>3. Creando preferencia de prueba...</h2>";
    
    $preferenceClient = new \MercadoPago\Client\Preference\PreferenceClient();
    
    $item = [
        'title' => 'Prueba de Membresía',
        'quantity' => 1,
        'unit_price' => 100.00,
        'currency_id' => 'MXN'
    ];
    
    $preferenceRequest = [
        'items' => [$item],
        'external_reference' => 'TEST_' . time(),
        'back_urls' => [
            'success' => 'https://membresia.secureitmx.com/membresias/dashboard.php?test=success',
            'failure' => 'https://membresia.secureitmx.com/membresias/dashboard.php?test=failure',
            'pending' => 'https://membresia.secureitmx.com/membresias/dashboard.php?test=pending'
        ],
        'auto_return' => 'approved'
    ];
    
    echo "<p>Creando preferencia con datos: " . json_encode($preferenceRequest) . "</p>";
    
    $preference = $preferenceClient->create($preferenceRequest);
    
    if ($preference && $preference->id) {
        echo "<p style='color: green;'>✅ Preferencia creada exitosamente</p>";
        echo "<p>ID de preferencia: " . $preference->id . "</p>";
        echo "<p>URL de pago: " . $preference->init_point . "</p>";
        
        echo "<h3>Enlaces de prueba:</h3>";
        echo "<p><a href='" . $preference->init_point . "' target='_blank' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Probar Pago</a></p>";
        echo "<p><a href='dashboard.php' style='background: #2196F3; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Volver al Dashboard</a></p>";
        
    } else {
        echo "<p style='color: red;'>❌ Error al crear preferencia</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Stack trace: " . $e->getTraceAsString() . "</p>";
}

echo "<hr>";
echo "<p><strong>Información del sistema:</strong></p>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>MercadoPago SDK Version: " . (class_exists('\MercadoPago\Client\Preference\PreferenceClient') ? 'Disponible' : 'No disponible') . "</p>";
echo "<p>Composer autoload: " . (file_exists('../vendor/autoload.php') ? 'Disponible' : 'No disponible') . "</p>";
?>
