<?php
// Archivo de prueba para verificar el flujo de suscripción
include '../includes/db.php';
include '../includes/config.php';
include '../config/mercadopago_config.php';

initConfig();

echo "<h1>Prueba del Flujo de Suscripción</h1>";

// Verificar si hay sesión activa
if (!isset($_SESSION['cliente'])) {
    echo "<p style='color: red;'>❌ No hay sesión activa. Por favor, inicia sesión primero.</p>";
    echo "<p><a href='login.php'>Ir al Login</a></p>";
    exit;
}

// Usar el cliente de la sesión
$cliente_id = $_SESSION['cliente']['id'];
$cliente_nombre = $_SESSION['cliente']['nombre'];

echo "<h2>1. Verificando datos de entrada...</h2>";
echo "<p>Cliente ID: $cliente_id (Sesión activa)</p>";
echo "<p>Cliente Nombre: $cliente_nombre</p>";

// Buscar un plan disponible
$stmt = $pdo->prepare("SELECT id, nombre, precio, duracion_dias FROM tipos_membresia WHERE is_active = 1 ORDER BY precio ASC LIMIT 1");
$stmt->execute();
$plan = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$plan) {
    echo "<p style='color: red;'>❌ No hay planes disponibles en la base de datos</p>";
    exit;
}

$plan_id = $plan['id'];
$precio = $plan['precio'];
$plan_nombre = $plan['nombre'];

echo "<p>Plan ID: $plan_id</p>";
echo "<p>Precio: $precio</p>";
echo "<p>Plan: $plan_nombre</p>";

try {
    // Verificar que el cliente existe
    echo "<h2>2. Verificando cliente...</h2>";
    $stmt = $pdo->prepare("SELECT id, nombre, correo FROM clientes WHERE id = ?");
    $stmt->execute([$cliente_id]);
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$cliente) {
        echo "<p style='color: red;'>❌ Cliente no encontrado en la base de datos</p>";
        echo "<p>ID buscado: $cliente_id</p>";
        exit;
    }
    
    echo "<p style='color: green;'>✅ Cliente encontrado: " . $cliente['nombre'] . "</p>";
    
    // Verificar que el plan existe
    echo "<h2>3. Verificando plan...</h2>";
    echo "<p style='color: green;'>✅ Plan encontrado: " . $plan['nombre'] . " ($" . $plan['precio'] . ")</p>";
    
    // Verificar si el cliente ya tiene una membresía activa
    echo "<h2>4. Verificando membresía existente...</h2>";
    $stmt = $pdo->prepare("
        SELECT id, mp_status 
        FROM membresias 
        WHERE cliente_id = ? AND mp_status IN ('pending', 'authorized', 'paused')
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $stmt->execute([$cliente_id]);
    $membresia_existente = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($membresia_existente) {
        echo "<p style='color: orange;'>⚠️ Cliente ya tiene membresía activa (ID: " . $membresia_existente['id'] . ", Status: " . $membresia_existente['mp_status'] . ")</p>";
        $membresia_id = $membresia_existente['id'];
    } else {
        echo "<p style='color: blue;'>ℹ️ Cliente no tiene membresía activa, se creará una nueva</p>";
        $membresia_id = null;
    }
    
    // Crear identificador único para la suscripción
    $timestamp = time();
    $external_reference = "MEM_{$cliente_id}_{$membresia_id}_{$plan_id}_{$timestamp}";
    
    if (strlen($external_reference) > 100) {
        $external_reference = substr($external_reference, 0, 100);
    }
    
    echo "<p>External Reference: $external_reference</p>";
    
    // Inicializar Mercado Pago
    echo "<h2>5. Inicializando Mercado Pago...</h2>";
    mpInit();
    echo "<p style='color: green;'>✅ Mercado Pago inicializado</p>";
    
    // Crear preferencia de pago
    echo "<h2>6. Creando preferencia de pago...</h2>";
    $preferenceClient = new \MercadoPago\Client\Preference\PreferenceClient();
    
    $item = [
        'title' => $plan_nombre,
        'quantity' => 1,
        'unit_price' => floatval($precio),
        'currency_id' => 'MXN'
    ];
    
    $preferenceRequest = [
        'items' => [$item],
        'external_reference' => $external_reference,
        'notification_url' => 'https://membresia.secureitmx.com/membresias/payment_success.php',
        'back_urls' => [
            'success' => 'https://membresia.secureitmx.com/membresias/dashboard.php?payment=success',
            'failure' => 'https://membresia.secureitmx.com/membresias/dashboard.php?payment=failure',
            'pending' => 'https://membresia.secureitmx.com/membresias/dashboard.php?payment=pending'
        ],
        'auto_return' => 'approved',
        'expires' => true,
        'expiration_date_to' => date('Y-m-d\TH:i:s.000-03:00', strtotime('+7 days'))
    ];
    
    echo "<p>Creando preferencia con datos:</p>";
    echo "<pre>" . json_encode($preferenceRequest, JSON_PRETTY_PRINT) . "</pre>";
    
    $preference = $preferenceClient->create($preferenceRequest);
    
    if (!$preference || !$preference->id) {
        throw new Exception('Error al crear preferencia en Mercado Pago');
    }
    
    echo "<p style='color: green;'>✅ Preferencia creada exitosamente</p>";
    echo "<p>ID de preferencia: " . $preference->id . "</p>";
    
    // Simular guardado en base de datos
    echo "<h2>7. Simulando guardado en base de datos...</h2>";
    
    // Verificar si la tabla payment_preferences existe
    $stmt = $pdo->prepare("SHOW TABLES LIKE 'payment_preferences'");
    $stmt->execute();
    if ($stmt->fetch()) {
        echo "<p style='color: green;'>✅ Tabla payment_preferences existe</p>";
        
        // Insertar en payment_preferences
        $stmt = $pdo->prepare("
            INSERT INTO payment_preferences 
            (cliente_id, membresia_id, plan_id, external_reference, preference_id, amount, status, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())
        ");
        
        $stmt->execute([
            $cliente_id,
            $membresia_id,
            $plan_id,
            $external_reference,
            $preference->id,
            $precio
        ]);
        
        echo "<p style='color: green;'>✅ Registro insertado en payment_preferences</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ Tabla payment_preferences no existe</p>";
    }
    
    // Crear URL de pago
    $payment_url = $preference->init_point;
    
    if (!$payment_url) {
        throw new Exception('No se pudo obtener la URL de pago de la preferencia');
    }
    
    echo "<h2>8. URL de pago generada:</h2>";
    echo "<p style='color: green;'>✅ URL: " . $payment_url . "</p>";
    
    // Crear enlace para probar
    echo "<h2>9. Enlace de prueba:</h2>";
    echo "<p><a href='" . $payment_url . "' target='_blank' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Probar Pago</a></p>";
    
    // Mostrar URL completa que se generaría desde el dashboard
    echo "<h2>10. URL que se generaría desde el dashboard:</h2>";
    $dashboard_url = "https://membresia.secureitmx.com/membresias/create_subscription.php?" . 
        "cliente_id=$cliente_id&" .
        "plan_id=$plan_id&" .
        "precio=$precio&" .
        "plan=" . urlencode($plan_nombre) . "&" .
        "token=" . md5($cliente_id . $plan_id . time());
    
    if ($membresia_id) {
        $dashboard_url .= "&membresia_id=$membresia_id";
    }
    
    echo "<p><a href='" . $dashboard_url . "' target='_blank' style='background: #2196F3; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Probar desde Dashboard</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Stack trace:</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<h2>11. Información adicional:</h2>";
echo "<p>Fecha y hora: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>Timezone: " . date_default_timezone_get() . "</p>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p><a href='dashboard.php'>← Volver al Dashboard</a></p>";
?>
