<?php
// Archivo de prueba que simula el dashboard real
include '../includes/db.php';
include '../includes/config.php';
include '../config/mercadopago_config.php';

initConfig();

echo "<h1>Prueba del Dashboard Real</h1>";

// Verificar si hay sesión activa
if (!isset($_SESSION['cliente'])) {
    echo "<p style='color: red;'>❌ No hay sesión activa. Por favor, inicia sesión primero.</p>";
    echo "<p><a href='login.php'>Ir al Login</a></p>";
    exit;
}

$cliente = $_SESSION['cliente'];
$cliente_id = $cliente['id'];

echo "<h2>1. Información del cliente logueado:</h2>";
echo "<p>ID: $cliente_id</p>";
echo "<p>Nombre: " . $cliente['nombre'] . "</p>";
echo "<p>Email: " . $cliente['correo'] . "</p>";

try {
    // Obtener datos reales de la membresía del cliente (como lo hace el dashboard)
    echo "<h2>2. Obteniendo datos de membresía...</h2>";
    $stmt = $pdo->prepare("
        SELECT 
            m.id,
            m.cliente_id,
            m.empresa_id,
            m.tipo_membresia_id,
            m.fecha_inicio,
            m.fecha_fin,
            m.metodo_pago,
            m.mp_status as estado,
            m.mp_subscription_id,
            m.mp_payment_method,
            m.mp_last_payment_date,
            m.mp_next_payment_date,
            m.mp_cancellation_fee,
            m.mp_cancelled_at,
            m.mp_cancellation_reason,
            m.created_at,
            tm.nombre as plan_nombre,
            tm.descripcion,
            tm.precio,
            tm.duracion_dias,
            tm.interval,
            tm.interval_count,
            tm.monto_cancelacion,
            c.nombre as cliente_nombre,
            c.apellido_paterno,
            c.apellido_materno,
            c.correo as cliente_email,
            c.telefono as cliente_telefono,
            c.mp_card_token,
            e.nombre as empresa_nombre
        FROM membresias m
        LEFT JOIN tipos_membresia tm ON m.tipo_membresia_id = tm.id
        LEFT JOIN clientes c ON m.cliente_id = c.id
        LEFT JOIN empresas e ON m.empresa_id = e.id
        WHERE m.cliente_id = ?
        ORDER BY m.created_at DESC
        LIMIT 1
    ");
    $stmt->execute([$cliente_id]);
    $membresia = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Verificar si tiene método de pago registrado (token de tarjeta)
    $hasPaymentMethod = !empty($membresia['mp_card_token']);
    
    if (!$membresia) {
        echo "<p style='color: orange;'>⚠️ No hay membresía activa para este cliente</p>";
        
        // Buscar un plan por defecto
        $stmt = $pdo->prepare("SELECT id, nombre, precio, duracion_dias FROM tipos_membresia WHERE is_active = 1 ORDER BY precio ASC LIMIT 1");
        $stmt->execute();
        $plan_default = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($plan_default) {
            $membresia = [
                'plan_nombre' => $plan_default['nombre'],
                'precio' => $plan_default['precio'],
                'estado' => 'sin_membresia',
                'fecha_inicio' => null,
                'fecha_fin' => null,
                'cliente_nombre' => $cliente['nombre'],
                'apellido_paterno' => $cliente['apellido_paterno'] ?? '',
                'apellido_materno' => $cliente['apellido_materno'] ?? '',
                'cliente_email' => $cliente['correo'] ?? '',
                'cliente_telefono' => $cliente['telefono'] ?? '',
                'empresa_nombre' => 'Empresa por defecto',
                'duracion_dias' => $plan_default['duracion_dias'],
                'monto_cancelacion' => 0.00,
                'tipo_membresia_id' => $plan_default['id']
            ];
            echo "<p style='color: green;'>✅ Usando plan por defecto: " . $plan_default['nombre'] . "</p>";
        } else {
            echo "<p style='color: red;'>❌ No hay planes disponibles</p>";
            exit;
        }
    } else {
        echo "<p style='color: green;'>✅ Membresía encontrada: " . $membresia['plan_nombre'] . "</p>";
        echo "<p>Estado: " . $membresia['estado'] . "</p>";
    }
    
    echo "<h2>3. Verificación de método de pago:</h2>";
    echo "<p>Método de pago configurado: " . ($hasPaymentMethod ? 'Sí' : 'No') . "</p>";
    if ($hasPaymentMethod) {
        echo "<p style='color: green;'>✅ Token de tarjeta: " . substr($membresia['mp_card_token'], 0, 10) . "...</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ No hay token de tarjeta configurado</p>";
    }
    
    // Simular la función createSubscriptionURL() del dashboard
    echo "<h2>4. Generando URL de suscripción (como lo hace el dashboard)...</h2>";
    
    $baseUrl = "https://membresia.secureitmx.com";
    $membresiaId = $membresia['id'] ?? null;
    $planId = $membresia['tipo_membresia_id'] ?? null;
    $precio = $membresia['precio'];
    $planNombre = $membresia['plan_nombre'];
    
    echo "<p>Base URL: $baseUrl</p>";
    echo "<p>Cliente ID: $cliente_id</p>";
    echo "<p>Membresía ID: " . ($membresiaId ?? 'null') . "</p>";
    echo "<p>Plan ID: " . ($planId ?? 'null') . "</p>";
    echo "<p>Precio: $precio</p>";
    echo "<p>Plan: $planNombre</p>";
    
    // Verificar si hay plan_id
    if (!$planId) {
        echo "<p style='color: red;'>❌ Error: No hay plan de membresía configurado</p>";
        exit;
    }
    
    // Generar token único
    $timestamp = time();
    $random = substr(md5(rand()), 0, 8);
    $data = "$cliente_id-" . ($membresiaId ?? 0) . "-$timestamp-$random";
    $token = md5($data);
    
    // Crear URL con parámetros únicos
    $subscriptionUrl = "$baseUrl/membresias/create_subscription.php?" . 
        "cliente_id=$cliente_id&" .
        "plan_id=$planId&" .
        "precio=$precio&" .
        "plan=" . urlencode($planNombre) . "&" .
        "token=$token";
    
    // Solo agregar membresia_id si existe
    if ($membresiaId) {
        $subscriptionUrl .= "&membresia_id=$membresiaId";
    }
    
    echo "<p style='color: green;'>✅ URL generada:</p>";
    echo "<p style='background: #f0f0f0; padding: 10px; border-radius: 5px; word-break: break-all;'>$subscriptionUrl</p>";
    
    // Probar la URL generada
    echo "<h2>5. Probando la URL generada:</h2>";
    echo "<p><a href='$subscriptionUrl' target='_blank' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Probar URL de Suscripción</a></p>";
    
    // También mostrar la URL con parámetros para debug
    echo "<h2>6. URL con parámetros para debug:</h2>";
    $debugUrl = "$baseUrl/membresias/debug_subscription.php?" . 
        "cliente_id=$cliente_id&" .
        "plan_id=$planId&" .
        "precio=$precio&" .
        "plan=" . urlencode($planNombre) . "&" .
        "token=$token";
    
    if ($membresiaId) {
        $debugUrl .= "&membresia_id=$membresiaId";
    }
    
    echo "<p><a href='$debugUrl' target='_blank' style='background: #2196F3; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Debug con Parámetros</a></p>";
    
    // Verificar estado del botón de activar
    echo "<h2>7. Estado del botón de activar:</h2>";
    if ($hasPaymentMethod) {
        echo "<p style='color: green;'>✅ El botón de 'Activar Tarjeta' debería estar HABILITADO</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ El botón de 'Activar Tarjeta' debería estar DESHABILITADO</p>";
    }
    
    // Mostrar información adicional
    echo "<h2>8. Información adicional:</h2>";
    echo "<p>Fecha y hora: " . date('Y-m-d H:i:s') . "</p>";
    echo "<p>Token generado: $token</p>";
    echo "<p>Datos para token: $data</p>";
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Stack trace:</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<h2>9. Enlaces útiles:</h2>";
echo "<p><a href='dashboard.php'>← Volver al Dashboard</a></p>";
echo "<p><a href='save_card.php'>Configurar Método de Pago</a></p>";
echo "<p><a href='test_mp_connection.php'>Probar Conexión MP</a></p>";
echo "<p><a href='test_subscription_flow.php'>Probar Flujo Completo</a></p>";
echo "<p><a href='debug_subscription.php'>Debug General</a></p>";
?>
