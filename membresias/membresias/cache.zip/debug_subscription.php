<?php
// Archivo de debug para verificar parámetros de create_subscription.php
include '../includes/db.php';
include '../includes/config.php';

initConfig();

echo "<h1>Debug de Parámetros - create_subscription.php</h1>";

echo "<h2>1. Parámetros GET recibidos:</h2>";
echo "<pre>";
print_r($_GET);
echo "</pre>";

echo "<h2>2. Parámetros POST recibidos:</h2>";
echo "<pre>";
print_r($_POST);
echo "</pre>";

echo "<h2>3. Variables de sesión:</h2>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo "<h2>4. Headers HTTP:</h2>";
echo "<pre>";
print_r(getallheaders());
echo "</pre>";

echo "<h2>5. Información del servidor:</h2>";
echo "<p>REQUEST_URI: " . ($_SERVER['REQUEST_URI'] ?? 'No disponible') . "</p>";
echo "<p>QUERY_STRING: " . ($_SERVER['QUERY_STRING'] ?? 'No disponible') . "</p>";
echo "<p>HTTP_REFERER: " . ($_SERVER['HTTP_REFERER'] ?? 'No disponible') . "</p>";
echo "<p>HTTP_USER_AGENT: " . ($_SERVER['HTTP_USER_AGENT'] ?? 'No disponible') . "</p>";

echo "<h2>6. Verificación de parámetros específicos:</h2>";

$cliente_id = $_GET['cliente_id'] ?? null;
$membresia_id = $_GET['membresia_id'] ?? null;
$plan_id = $_GET['plan_id'] ?? null;
$precio = $_GET['precio'] ?? null;
$plan_nombre = $_GET['plan'] ?? null;
$token = $_GET['token'] ?? null;

echo "<p>cliente_id: " . ($cliente_id ?? 'null') . "</p>";
echo "<p>membresia_id: " . ($membresia_id ?? 'null') . "</p>";
echo "<p>plan_id: " . ($plan_id ?? 'null') . "</p>";
echo "<p>precio: " . ($precio ?? 'null') . "</p>";
echo "<p>plan_nombre: " . ($plan_nombre ?? 'null') . "</p>";
echo "<p>token: " . ($token ?? 'null') . "</p>";

echo "<h2>7. Verificación de base de datos:</h2>";

if ($cliente_id) {
    try {
        $stmt = $pdo->prepare("SELECT id, nombre, correo FROM clientes WHERE id = ?");
        $stmt->execute([$cliente_id]);
        $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($cliente) {
            echo "<p style='color: green;'>✅ Cliente encontrado: " . $cliente['nombre'] . " (" . $cliente['correo'] . ")</p>";
        } else {
            echo "<p style='color: red;'>❌ Cliente no encontrado con ID: $cliente_id</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Error consultando cliente: " . $e->getMessage() . "</p>";
    }
}

if ($plan_id) {
    try {
        $stmt = $pdo->prepare("SELECT id, nombre, precio, duracion_dias FROM tipos_membresia WHERE id = ?");
        $stmt->execute([$plan_id]);
        $plan = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($plan) {
            echo "<p style='color: green;'>✅ Plan encontrado: " . $plan['nombre'] . " ($" . $plan['precio'] . ")</p>";
        } else {
            echo "<p style='color: red;'>❌ Plan no encontrado con ID: $plan_id</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Error consultando plan: " . $e->getMessage() . "</p>";
    }
}

if ($membresia_id) {
    try {
        $stmt = $pdo->prepare("SELECT id, cliente_id, mp_status FROM membresias WHERE id = ?");
        $stmt->execute([$membresia_id]);
        $membresia = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($membresia) {
            echo "<p style='color: green;'>✅ Membresía encontrada: ID " . $membresia['id'] . " (Cliente: " . $membresia['cliente_id'] . ", Status: " . $membresia['mp_status'] . ")</p>";
        } else {
            echo "<p style='color: red;'>❌ Membresía no encontrada con ID: $membresia_id</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color: red;'>❌ Error consultando membresía: " . $e->getMessage() . "</p>";
    }
}

echo "<h2>8. Verificación de sesión:</h2>";
if (isset($_SESSION['cliente'])) {
    echo "<p style='color: green;'>✅ Sesión activa para cliente: " . $_SESSION['cliente']['nombre'] . "</p>";
    echo "<p>ID de sesión: " . $_SESSION['cliente']['id'] . "</p>";
} else {
    echo "<p style='color: orange;'>⚠️ No hay sesión activa</p>";
}

echo "<h2>9. Validación de parámetros requeridos:</h2>";
$isLoggedIn = isset($_SESSION['cliente']);
$hasValidParams = $cliente_id && $plan_id && $token;

echo "<p>Está logueado: " . ($isLoggedIn ? 'Sí' : 'No') . "</p>";
echo "<p>Tiene parámetros válidos: " . ($hasValidParams ? 'Sí' : 'No') . "</p>";
echo "<p>cliente_id presente: " . ($cliente_id ? 'Sí' : 'No') . "</p>";
echo "<p>plan_id presente: " . ($plan_id ? 'Sí' : 'No') . "</p>";
echo "<p>token presente: " . ($token ? 'Sí' : 'No') . "</p>";

if (!$isLoggedIn && !$hasValidParams) {
    echo "<p style='color: red;'>❌ ERROR: No autorizado - Se requieren parámetros válidos o sesión activa</p>";
} else {
    echo "<p style='color: green;'>✅ Autorización válida</p>";
}

echo "<h2>10. Información adicional:</h2>";
echo "<p>Fecha y hora: " . date('Y-m-d H:i:s') . "</p>";
echo "<p>Timezone: " . date_default_timezone_get() . "</p>";
echo "<p>PHP Version: " . phpversion() . "</p>";

echo "<h2>11. Enlaces de prueba:</h2>";
echo "<p><a href='test_mp_connection.php' target='_blank'>Probar Conexión MP</a></p>";
echo "<p><a href='test_subscription_flow.php' target='_blank'>Probar Flujo de Suscripción</a></p>";
echo "<p><a href='test_dashboard_flow.php' target='_blank'>Probar Flujo del Dashboard</a></p>";
echo "<p><a href='test_dashboard_real.php' target='_blank'>Probar Dashboard Real</a></p>";
echo "<p><a href='test_simplified_flow.php' target='_blank'>Probar Flujo Simplificado</a></p>";
echo "<p><a href='dashboard.php' target='_blank'>Ir al Dashboard</a></p>";
?>
