<?php
// Archivo de prueba para verificar la conexión con Mercado Pago
include '../includes/db.php';
include '../includes/config.php';
include '../config/mercadopago_config.php';

initConfig();

echo "<h1>Prueba de Conexión con Mercado Pago</h1>";

try {
    // Verificar credenciales
    echo "<h2>1. Verificando credenciales...</h2>";
    $credentials = mpVerifyCredentials();
    
    if ($credentials['success']) {
        echo "<p style='color: green;'>✅ Credenciales válidas</p>";
        echo "<p>Collector ID: " . $credentials['collector_id'] . "</p>";
    } else {
        echo "<p style='color: red;'>❌ Error en credenciales: " . $credentials['error'] . "</p>";
        echo "<p>Detalles: " . $credentials['details'] . "</p>";
        exit;
    }
    
    // Inicializar Mercado Pago
    echo "<h2>2. Inicializando Mercado Pago...</h2>";
    mpInit();
    echo "<p style='color: green;'>✅ Mercado Pago inicializado</p>";
    
    // Crear una preferencia de prueba
    echo "<h2>3. Creando preferencia de prueba...</h2>";
    
    $preferenceClient = new \MercadoPago\Client\Preference\PreferenceClient();
    
    $item = [
        'title' => 'Prueba de Membresía',
        'quantity' => 1,
        'unit_price' => 100.00,
        'currency_id' => 'MXN'
    ];
    
    $preferenceRequest = [
        'items' => [$item],
        'external_reference' => 'TEST_' . time(),
        'notification_url' => 'https://membresia.secureitmx.com/membresias/payment_success.php',
        'back_urls' => [
            'success' => 'https://membresia.secureitmx.com/membresias/dashboard.php?payment=success',
            'failure' => 'https://membresia.secureitmx.com/membresias/dashboard.php?payment=failure',
            'pending' => 'https://membresia.secureitmx.com/membresias/dashboard.php?payment=pending'
        ],
        'auto_return' => 'approved',
        'expires' => true,
        'expiration_date_to' => date('Y-m-d\TH:i:s.000-03:00', strtotime('+1 hour'))
    ];
    
    echo "<p>Creando preferencia con datos:</p>";
    echo "<pre>" . json_encode($preferenceRequest, JSON_PRETTY_PRINT) . "</pre>";
    
    $preference = $preferenceClient->create($preferenceRequest);
    
    if ($preference && $preference->id) {
        echo "<p style='color: green;'>✅ Preferencia creada exitosamente</p>";
        echo "<p>ID de preferencia: " . $preference->id . "</p>";
        echo "<p>URL de pago: " . $preference->init_point . "</p>";
        
        // Crear enlace para probar
        echo "<h2>4. Enlace de prueba:</h2>";
        echo "<p><a href='" . $preference->init_point . "' target='_blank' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Probar Pago</a></p>";
        
    } else {
        echo "<p style='color: red;'>❌ Error al crear preferencia</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
    echo "<p>Stack trace:</p>";
    echo "<pre>" . $e->getTraceAsString() . "</pre>";
}

echo "<h2>5. Información del sistema:</h2>";
echo "<p>PHP Version: " . phpversion() . "</p>";
echo "<p>Mercado Pago SDK Version: " . (class_exists('\MercadoPago\MercadoPagoConfig') ? 'Disponible' : 'No disponible') . "</p>";
echo "<p>MP_ACCESS_TOKEN configurado: " . (defined('MP_ACCESS_TOKEN') && !empty(MP_ACCESS_TOKEN) ? 'Sí' : 'No') . "</p>";
echo "<p>MP_PUBLIC_KEY configurado: " . (defined('MP_PUBLIC_KEY') && !empty(MP_PUBLIC_KEY) ? 'Sí' : 'No') . "</p>";
?>
