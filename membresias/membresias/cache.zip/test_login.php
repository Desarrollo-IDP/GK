<?php
session_start();

// Verificar si ya está logueado
if (isset($_SESSION['cliente'])) {
    echo "Ya estás logueado como: " . $_SESSION['cliente']['nombre'];
    echo "<br><a href='dashboard.php'>Ir al Dashboard</a>";
    echo "<br><a href='logout.php'>Cerrar sesión</a>";
    exit;
}

// Procesar login de prueba
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Credenciales de prueba (deberías usar la base de datos real)
    if ($correo === 'test@test.com' && $password === '123456') {
        $_SESSION['cliente'] = [
            'id' => 1,
            'correo' => 'test@test.com',
            'nombre' => 'Usuario de Prueba'
        ];
        
        echo "Login exitoso! Redirigiendo...";
        echo "<script>setTimeout(function(){ window.location.href='dashboard.php'; }, 2000);</script>";
        exit;
    } else {
        $error = "Credenciales incorrectas";
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Test Login - Portal de Membresías</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            background: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
        .info {
            background: #e7f3ff;
            padding: 15px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Test Login</h1>
    
    <div class="info">
        <strong>Credenciales de prueba:</strong><br>
        Email: test@test.com<br>
        Contraseña: 123456
    </div>
    
    <?php if (isset($error)): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <form method="post">
        <div class="form-group">
            <label>Email:</label>
            <input type="email" name="correo" value="test@test.com" required>
        </div>
        
        <div class="form-group">
            <label>Contraseña:</label>
            <input type="password" name="password" value="123456" required>
        </div>
        
        <button type="submit">Iniciar Sesión</button>
    </form>
    
    <hr>
    <p><a href="login.php">Ir al Login Real</a></p>
</body>
</html>
