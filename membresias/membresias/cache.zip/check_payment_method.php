<?php
// Verificar método de pago del cliente
include '../includes/db.php';
include '../includes/config.php';

initConfig();

// Verificar si el cliente está logueado
if (!isset($_SESSION['cliente'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado']);
    exit;
}

$cliente_id = $_SESSION['cliente']['id'];

try {
    // Verificar si el cliente tiene un token de tarjeta guardado
    $stmt = $pdo->prepare("SELECT mp_card_token FROM clientes WHERE id = ?");
    $stmt->execute([$cliente_id]);
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $hasPaymentMethod = !empty($cliente['mp_card_token']);
    
    // Devolver respuesta JSON
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'hasPaymentMethod' => $hasPaymentMethod,
        'cliente_id' => $cliente_id
    ]);
    
} catch (PDOException $e) {
    error_log("Error verificando método de pago: " . $e->getMessage());
    
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error interno del servidor',
        'hasPaymentMethod' => false
    ]);
}
?>
