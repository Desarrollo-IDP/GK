<?php
// Crear suscripción de Mercado Pago
include '../includes/db.php';
include '../includes/config.php';
include '../config/mercadopago_config.php';

initConfig();

// Obtener parámetros
$cliente_id = $_GET['cliente_id'] ?? null;
$membresia_id = $_GET['membresia_id'] ?? null;
$plan_id = $_GET['plan_id'] ?? null;
$precio = $_GET['precio'] ?? 0;
$plan_nombre = $_GET['plan'] ?? 'Membresía';
$token = $_GET['token'] ?? null;

// Verificar si el cliente está logueado O si tiene parámetros válidos
$isLoggedIn = isset($_SESSION['cliente']);
$hasValidParams = $cliente_id && $plan_id && $token;

if (!$isLoggedIn && !$hasValidParams) {
    http_response_code(401);
    echo json_encode(['error' => 'No autorizado - Se requieren parámetros válidos o sesión activa']);
    exit;
}

// Si está logueado, usar el ID de la sesión
if ($isLoggedIn) {
    $cliente_id = $_SESSION['cliente']['id'];
}

// Validar que el cliente sea el correcto si está logueado
if ($isLoggedIn && $cliente_id != $_SESSION['cliente']['id']) {
    http_response_code(403);
    echo json_encode(['error' => 'Acceso denegado']);
    exit;
}

try {
    // Verificar que el cliente existe
    $stmt = $pdo->prepare("SELECT id, nombre, correo FROM clientes WHERE id = ?");
    $stmt->execute([$cliente_id]);
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$cliente) {
        http_response_code(404);
        echo json_encode(['error' => 'Cliente no encontrado']);
        exit;
    }
    
    // Verificar que el plan existe
    $stmt = $pdo->prepare("SELECT id, nombre, precio, duracion_dias, is_active FROM tipos_membresia WHERE id = ?");
    $stmt->execute([$plan_id]);
    $plan = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$plan) {
        // Log del error para debug
        error_log("Plan no encontrado - Plan ID: $plan_id, Cliente ID: $cliente_id");
        
        // Obtener todos los planes disponibles para debug
        $stmt = $pdo->prepare("SELECT id, nombre, is_active FROM tipos_membresia ORDER BY id");
        $stmt->execute();
        $planes_disponibles = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $planes_info = [];
        foreach ($planes_disponibles as $p) {
            $planes_info[] = "ID: {$p['id']}, Nombre: {$p['nombre']}, Activo: " . ($p['is_active'] ? 'Sí' : 'No');
        }
        
        error_log("Planes disponibles: " . implode(', ', $planes_info));
        
        http_response_code(404);
        echo json_encode([
            'error' => 'Plan no encontrado',
            'plan_id_requested' => $plan_id,
            'planes_disponibles' => $planes_info,
            'debug_info' => [
                'cliente_id' => $cliente_id,
                'timestamp' => date('Y-m-d H:i:s')
            ]
        ]);
        exit;
    }
    
    // Verificar que el plan esté activo
    if (!$plan['is_active']) {
        http_response_code(400);
        echo json_encode([
            'error' => 'Plan inactivo',
            'plan_id' => $plan_id,
            'plan_nombre' => $plan['nombre']
        ]);
        exit;
    }
    
    // Si no hay membresía_id, verificar si el cliente ya tiene una membresía activa
    if (!$membresia_id) {
        $stmt = $pdo->prepare("
            SELECT id, mp_status 
            FROM membresias 
            WHERE cliente_id = ? AND mp_status IN ('pending', 'authorized', 'paused')
            ORDER BY created_at DESC 
            LIMIT 1
        ");
        $stmt->execute([$cliente_id]);
        $membresia_existente = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($membresia_existente) {
            $membresia_id = $membresia_existente['id'];
        } else {
            // Crear una nueva membresía para el cliente
            $stmt = $pdo->prepare("
                INSERT INTO membresias 
                (cliente_id, empresa_id, tipo_membresia_id, fecha_inicio, fecha_fin, metodo_pago, mp_status, created_at) 
                VALUES (?, 1, ?, NULL, NULL, 'mercadopago', 'pending', NOW())
            ");
            $stmt->execute([$cliente_id, $plan_id]);
            $membresia_id = $pdo->lastInsertId();
        }
    } else {
        // Verificar que la membresía pertenece al cliente
        $stmt = $pdo->prepare("SELECT id FROM membresias WHERE id = ? AND cliente_id = ?");
        $stmt->execute([$membresia_id, $cliente_id]);
        if (!$stmt->fetch()) {
            http_response_code(404);
            echo json_encode(['error' => 'Membresía no encontrada']);
            exit;
        }
    }
    
    // Crear identificador único para la suscripción
    $timestamp = time();
    $external_reference = "MEM_{$cliente_id}_{$membresia_id}_{$plan_id}_{$timestamp}";
    
    // Si es muy largo, truncar
    if (strlen($external_reference) > 100) {
        $external_reference = substr($external_reference, 0, 100);
    }
    
    // Inicializar Mercado Pago
    mpInit();
    
    // Crear preferencia de pago usando el SDK v3
    $preferenceClient = new \MercadoPago\Client\Preference\PreferenceClient();
    
    // Crear item para la preferencia
    $item = [
        'title' => $plan_nombre,
        'quantity' => 1,
        'unit_price' => floatval($precio),
        'currency_id' => 'MXN'
    ];
    
    // Crear preferencia con expiración más larga (7 días en lugar de 1 hora)
    $preferenceRequest = [
        'items' => [$item],
        'external_reference' => $external_reference,
        'notification_url' => 'https://membresia.secureitmx.com/membresias/payment_success.php',
        'back_urls' => [
            'success' => 'https://membresia.secureitmx.com/membresias/dashboard.php?payment=success',
            'failure' => 'https://membresia.secureitmx.com/membresias/dashboard.php?payment=failure',
            'pending' => 'https://membresia.secureitmx.com/membresias/dashboard.php?payment=pending'
        ],
        'auto_return' => 'approved',
        'expires' => true,
        'expiration_date_to' => date('Y-m-d\TH:i:s.000-03:00', strtotime('+7 days'))
    ];
    
    error_log('MP Create Preference Request: ' . json_encode($preferenceRequest));
    
    $preference = $preferenceClient->create($preferenceRequest);
    
    if (!$preference || !$preference->id) {
        throw new Exception('Error al crear preferencia en Mercado Pago');
    }
    
    error_log('MP Preference created: ' . json_encode($preference));
    
    // Guardar en la base de datos
    $stmt = $pdo->prepare("
        INSERT INTO payment_preferences 
        (cliente_id, membresia_id, plan_id, external_reference, preference_id, amount, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())
    ");
    
    $stmt->execute([
        $cliente_id,
        $membresia_id,
        $plan_id,
        $external_reference,
        $preference->id,
        $precio
    ]);
    
    // Actualizar la membresía con la referencia externa
    if ($membresia_id) {
        $stmt = $pdo->prepare("UPDATE membresias SET mp_external_reference = ? WHERE id = ?");
        $stmt->execute([$external_reference, $membresia_id]);
    }
    
    // Crear URL de pago real
    $payment_url = $preference->init_point;
    
    if (!$payment_url) {
        throw new Exception('No se pudo obtener la URL de pago de la preferencia');
    }
    
    error_log('MP Payment URL: ' . $payment_url);
    
    // Redirigir al usuario a la página de pago
    header('Location: ' . $payment_url);
    exit;
    
} catch (Exception $e) {
    error_log("Error creando suscripción: " . $e->getMessage());
    
    // Mostrar página de error
    ?>
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error - Crear Suscripción</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                margin: 0;
                padding: 20px;
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .error-container {
                background: white;
                padding: 40px;
                border-radius: 20px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                text-align: center;
                max-width: 500px;
            }
            .error-icon {
                font-size: 48px;
                color: #f44336;
                margin-bottom: 20px;
            }
            h1 {
                color: #333;
                margin-bottom: 20px;
            }
            p {
                color: #666;
                margin-bottom: 30px;
            }
            .btn {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 12px 30px;
                border: none;
                border-radius: 25px;
                text-decoration: none;
                display: inline-block;
                font-weight: bold;
                transition: transform 0.3s;
            }
            .btn:hover {
                transform: translateY(-2px);
            }
        </style>
    </head>
    <body>
        <div class="error-container">
            <div class="error-icon">⚠️</div>
            <h1>Error al crear suscripción</h1>
            <p>Hubo un problema al procesar tu solicitud de pago. Por favor, intenta nuevamente.</p>
            <p style="font-size: 12px; color: #999;">Error: <?= htmlspecialchars($e->getMessage()) ?></p>
            <a href="dashboard.php" class="btn">Volver al Dashboard</a>
        </div>
    </body>
    </html>
    <?php
}
?>
