<?php
// Archivo de prueba para verificar el flujo simplificado
include '../includes/db.php';
include '../includes/config.php';
include '../config/mercadopago_config.php';

initConfig();

echo "<h1>Prueba del Flujo Simplificado</h1>";

// Verificar si hay sesión activa
if (!isset($_SESSION['cliente'])) {
    echo "<p style='color: orange;'>⚠️ No hay sesión activa. Por favor, inicia sesión primero.</p>";
    echo "<p><a href='login.php'>Ir al Login</a></p>";
    exit;
}

$cliente = $_SESSION['cliente'];
$cliente_id = $cliente['id'];

echo "<h2>1. Información del cliente logueado:</h2>";
echo "<p>ID: $cliente_id</p>";
echo "<p>Nombre: " . $cliente['nombre'] . "</p>";
echo "<p>Email: " . $cliente['correo'] . "</p>";

try {
    // Verificar si tiene método de pago configurado
    echo "<h2>2. Verificación de método de pago:</h2>";
    $stmt = $pdo->prepare("SELECT mp_card_token FROM clientes WHERE id = ?");
    $stmt->execute([$cliente_id]);
    $cliente_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($cliente_data && !empty($cliente_data['mp_card_token'])) {
        echo "<p style='color: green;'>✅ Método de pago configurado</p>";
        echo "<p>Token: " . substr($cliente_data['mp_card_token'], 0, 10) . "...</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ No tiene método de pago configurado</p>";
    }
    
    // Verificar membresía
    echo "<h2>3. Verificación de membresía:</h2>";
    $stmt = $pdo->prepare("
        SELECT m.*, tm.nombre as plan_nombre, tm.precio 
        FROM membresias m 
        LEFT JOIN tipos_membresia tm ON m.tipo_membresia_id = tm.id 
        WHERE m.cliente_id = ? 
        ORDER BY m.created_at DESC 
        LIMIT 1
    ");
    $stmt->execute([$cliente_id]);
    $membresia = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($membresia) {
        echo "<p style='color: green;'>✅ Membresía encontrada</p>";
        echo "<p>Plan: " . $membresia['plan_nombre'] . "</p>";
        echo "<p>Precio: $" . $membresia['precio'] . "</p>";
        echo "<p>Estado: " . $membresia['mp_status'] . "</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ No tiene membresía activa</p>";
        
        // Buscar plan por defecto
        $stmt = $pdo->prepare("SELECT id, nombre, precio FROM tipos_membresia WHERE is_active = 1 ORDER BY precio ASC LIMIT 1");
        $stmt->execute();
        $plan_default = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($plan_default) {
            echo "<p style='color: blue;'>ℹ️ Plan por defecto disponible: " . $plan_default['nombre'] . " ($" . $plan_default['precio'] . ")</p>";
        }
    }
    
    // Probar generación de URL de suscripción
    echo "<h2>4. Prueba de generación de URL de suscripción:</h2>";
    
    $baseUrl = "https://membresia.secureitmx.com";
    $membresiaId = $membresia['id'] ?? null;
    $planId = $membresia['tipo_membresia_id'] ?? $plan_default['id'] ?? null;
    $precio = $membresia['precio'] ?? $plan_default['precio'] ?? 0;
    $planNombre = $membresia['plan_nombre'] ?? $plan_default['nombre'] ?? 'Plan por defecto';
    
    if ($planId) {
        // Generar token único
        $timestamp = time();
        $random = substr(md5(rand()), 0, 8);
        $data = "$cliente_id-" . ($membresiaId ?? 0) . "-$timestamp-$random";
        $token = md5($data);
        
        // Crear URL
        $subscriptionUrl = "$baseUrl/membresias/create_subscription.php?" . 
            "cliente_id=$cliente_id&" .
            "plan_id=$planId&" .
            "precio=$precio&" .
            "plan=" . urlencode($planNombre) . "&" .
            "token=$token";
        
        if ($membresiaId) {
            $subscriptionUrl .= "&membresia_id=$membresiaId";
        }
        
        echo "<p style='color: green;'>✅ URL generada correctamente</p>";
        echo "<p><a href='$subscriptionUrl' target='_blank' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Probar URL de Suscripción</a></p>";
        
        // Mostrar URL para debug
        echo "<p style='background: #f0f0f0; padding: 10px; border-radius: 5px; word-break: break-all; font-size: 12px;'>$subscriptionUrl</p>";
    } else {
        echo "<p style='color: red;'>❌ No se pudo generar URL - falta plan_id</p>";
    }
    
    // Verificar archivos necesarios
    echo "<h2>5. Verificación de archivos:</h2>";
    $archivos_necesarios = [
        'login.php',
        'save_card.php',
        'create_card_token.php',
        'get_identification_types.php',
        'check_payment_method.php',
        'create_subscription.php'
    ];
    
    foreach ($archivos_necesarios as $archivo) {
        if (file_exists($archivo)) {
            echo "<p style='color: green;'>✅ $archivo existe</p>";
        } else {
            echo "<p style='color: red;'>❌ $archivo no existe</p>";
        }
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<h2>6. Enlaces de prueba:</h2>";
echo "<p><a href='dashboard.php'>← Volver al Dashboard</a></p>";
echo "<p><a href='save_card.php'>Configurar Método de Pago</a></p>";
echo "<p><a href='test_dashboard_real.php'>Probar Dashboard Real</a></p>";
echo "<p><a href='debug_subscription.php'>Debug General</a></p>";
?>
