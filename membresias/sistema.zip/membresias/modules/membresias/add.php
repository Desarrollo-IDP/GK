<?php
// Define current page for active menu highlighting
$current_page = 'membresias_add';

include '../../includes/db.php';

// Obtener tipos de membresía
try {
    $tipos_stmt = $pdo->query("SELECT id, nombre FROM tipos_membresia ORDER BY nombre");
    $tipos = $tipos_stmt->fetchAll(PDO::FETCH_OBJ);
} catch (PDOException $e) {
    die("Error al obtener tipos de membresía: " . $e->getMessage());
}

// Inicializar variables para el formulario
$errores = [];
$mensaje = '';
$tipoMensaje = '';

$errores = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Datos del cliente
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido_paterno = trim($_POST['apellido_paterno'] ?? '');
    $apellido_materno = trim($_POST['apellido_materno'] ?? '');
    $edad = intval($_POST['edad'] ?? 0);
    $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
    $sexo = $_POST['sexo'] ?? '';
    $curp = trim($_POST['curp'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $foto = null;

    // Datos de membresía
    $tipo_membresia_id = $_POST['tipo_membresia_id'] ?? '';
    $fecha_inicio = $_POST['fecha_inicio'] ?? date('Y-m-d');
    $fecha_fin = $_POST['fecha_fin'] ?? '';
    $metodo_pago = $_POST['metodo_pago'] ?? '';
    $firma = null;

    // Validaciones básicas cliente
    if ($nombre === '') $errores[] = 'El nombre es obligatorio.';
    if ($apellido_paterno === '') $errores[] = 'El apellido paterno es obligatorio.';
    if ($edad <= 0) $errores[] = 'La edad debe ser mayor a 0.';
    if ($fecha_nacimiento === '') $errores[] = 'La fecha de nacimiento es obligatoria.';
    if ($sexo === '') $errores[] = 'El sexo es obligatorio.';
    if ($curp === '') $errores[] = 'El CURP es obligatorio.';
    if ($correo === '') $errores[] = 'El correo es obligatorio.';
    if ($telefono === '') $errores[] = 'El número de teléfono es obligatorio.';

    // Manejo de la foto (base64)
    if (isset($_POST['foto_data']) && $_POST['foto_data'] !== '') {
        $fotoData = $_POST['foto_data'];
        $dirFotos = '../../uploads/fotos/';
        if (!is_dir($dirFotos)) {
            mkdir($dirFotos, 0777, true);
        }
        $fotoNombre = uniqid('foto_') . '.png';
        $fotoPath = $dirFotos . $fotoNombre;
        $fotoBase64 = explode(',', $fotoData, 2)[1];
        if (file_put_contents($fotoPath, base64_decode($fotoBase64))) {
            $foto = str_replace('../../', '', $fotoPath);
        } else {
            $errores[] = 'Error al guardar la foto.';
        }
    } else {
        $errores[] = 'La foto es obligatoria.';
    }

    // Validaciones membresía
    if ($tipo_membresia_id === '') $errores[] = 'El tipo de membresía es obligatorio.';
    if ($fecha_inicio === '') $errores[] = 'La fecha de inicio es obligatoria.';
    if ($fecha_fin === '') $errores[] = 'La fecha de fin es obligatoria.';
    if ($metodo_pago === '') $errores[] = 'El método de pago es obligatorio.';

    // Manejo de la firma (canvas)
    if (isset($_POST['firma_data']) && $_POST['firma_data'] !== '') {
        $firmaData = $_POST['firma_data'];
        $dirFirmas = '../../uploads/firmas/';
        if (!is_dir($dirFirmas)) {
            mkdir($dirFirmas, 0777, true);
        }
        $firmaNombre = uniqid('firma_') . '.png';
        $firmaPath = $dirFirmas . $firmaNombre;
        $firmaBase64 = explode(',', $firmaData, 2)[1];
        if (file_put_contents($firmaPath, base64_decode($firmaBase64))) {
            $firma = str_replace('../../', '', $firmaPath);
        } else {
            $errores[] = 'Error al guardar la firma digital.';
        }
    } else {
        $errores[] = 'La firma digital es obligatoria.';
    }

    // Si no hay errores, guardar cliente y membresía
    if (empty($errores)) {
        try {
            $pdo->beginTransaction();
            
            // Insertar cliente
            $sql = "INSERT INTO clientes (nombre, apellido_paterno, apellido_materno, edad, fecha_nacimiento, sexo, curp, foto, direccion, correo, telefono) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $nombre, 
                $apellido_paterno, 
                $apellido_materno,
                $edad, 
                $fecha_nacimiento, 
                $sexo, 
                $curp, 
                $foto, 
                $direccion, 
                $correo, 
                $telefono
            ]);
            
            $cliente_id = $pdo->lastInsertId();

            // Insertar membresía
            $sqlMembresia = "INSERT INTO membresias (cliente_id, tipo_membresia_id, fecha_inicio, fecha_fin, metodo_pago, firma_digital) 
                            VALUES (?, ?, ?, ?, ?, ?)";
            $stmtMembresia = $pdo->prepare($sqlMembresia);
            $stmtMembresia->execute([
                $cliente_id, 
                $tipo_membresia_id, 
                $fecha_inicio, 
                $fecha_fin, 
                $metodo_pago, 
                $firma
            ]);
            
            // Si todo salió bien, confirmar la transacción
            $pdo->commit();
            
            // Redirigir al listado
            header('Location: list.php');
            exit;
            
        } catch (Exception $e) {
            // Si hay algún error, revertir la transacción
            $pdo->rollBack();
            $errores[] = "Error al guardar los datos: " . $e->getMessage();
        }
    }
}
?>
<?php include '../../includes/header.php'; ?>

<style>
/* Signature Pad Styles */
.signature-pad {
    border: 1px solid var(--gray-200);
    border-radius: 0.5rem;
    margin: 1rem 0;
    background: white;
    padding: 1rem;
}

.signature-pad--body {
    border: 1px dashed var(--gray-300);
    border-radius: 0.375rem;
    background: var(--gray-50);
    margin-bottom: 1rem;
    position: relative;
    width: 100%;
    height: 200px;
}

.signature-pad--body canvas {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: white;
}

.signature-pad--footer {
    margin-top: 1rem;
    color: var(--gray-500);
    font-size: 0.875rem;
}

.signature-pad--footer .description {
    margin-bottom: 0.5rem;
    color: var(--gray-600);
}

.body-bg {
    background: #f8f9fc;
    min-height: 100vh;
    width: 100%;
    overflow-x: hidden;
    padding: 1rem 0;
}

.main-content-boxed {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem 1.5rem;
    background: #fff;
    border-radius: 0.75rem;
    box-shadow: 0 0.5rem 1.5rem rgba(0, 0, 0, 0.05);
    margin-top: 1rem;
    margin-bottom: 2rem;
}

.form-section {
    background: #fff;
    border-radius: 0.75rem;
    box-shadow: 0 0.125rem 0.5rem rgba(0, 0, 0, 0.04);
    padding: 1.75rem;
    margin-bottom: 1.5rem;
    border: 1px solid #e9ecef;
}

.form-section h5 {
    color: #2c3e50;
    font-weight: 600;
    font-size: 1.1rem;
    margin-bottom: 1.5rem;
    padding-bottom: 0.75rem;
    border-bottom: 1px solid #e9ecef;
    display: flex;
    align-items: center;
}

.form-section h5 i {
    margin-right: 0.5rem;
    color: #5e72e4;
}

.form-label {
    font-weight: 500;
    color: #4a5568;
    margin-bottom: 0.5rem;
    font-size: 0.875rem;
}

.form-control, .form-select {
    border-radius: 0.5rem;
    padding: 0.6rem 1rem;
    border: 1px solid #e2e8f0;
    transition: all 0.2s ease;
    font-size: 0.9375rem;
}

.form-control:focus, .form-select:focus {
    border-color: #5e72e4;
    box-shadow: 0 0 0 0.25rem rgba(94, 114, 228, 0.15);
}

.btn {
    border-radius: 0.5rem;
    padding: 0.6rem 1.25rem;
    font-weight: 500;
    font-size: 0.9375rem;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.btn i {
    margin-right: 0.5rem;
}

.btn-primary {
    background-color: #5e72e4;
    border-color: #5e72e4;
}

.btn-primary:hover {
    background-color: #4a5bd9;
    border-color: #4a5bd9;
}

.btn-outline-secondary {
    color: #4a5568;
    border-color: #e2e8f0;
}

.btn-outline-secondary:hover {
    background-color: #f8f9fa;
    border-color: #cbd5e0;
}

/* Estilos para la cámara */
#camara-container {
    margin: 1rem 0;
}

#video, #canvas_foto, #preview_foto {
    border-radius: 0.5rem;
    border: 1px solid #e2e8f0;
    max-width: 100%;
    height: auto;
}

#btnCamara, #btnTomarFoto, button[onclick="limpiarFirma()"] {
    margin: 0.5rem 0.5rem 0.5rem 0;
    padding: 0.5rem 1rem;
    border-radius: 0.5rem;
    background-color: #f8f9fa;
    border: 1px solid #e2e8f0;
    color: #4a5568;
    cursor: pointer;
    transition: all 0.2s ease;
}

#btnCamara:hover, #btnTomarFoto:hover, button[onclick="limpiarFirma()"]:hover {
    background-color: #edf2f7;
    border-color: #cbd5e0;
}

/* Estilos para la firma */
#firma {
    border: 1px solid #e2e8f0;
    border-radius: 0.5rem;
    background-color: #fff;
    margin: 0.5rem 0;
    cursor: crosshair;
    touch-action: none; /* Mejora el comportamiento táctil */
    box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
}

.signature-pad--body canvas {
    position: absolute;
    left: 0;
    top: 0;
    width: 100% !important;
    height: 100% !important;
    background: white;
    border-radius: 0.375rem;
}

/* Mejoras responsivas */
@media (max-width: 768px) {
    .main-content-boxed {
        padding: 1.5rem 1rem;
        margin: 0.5rem;
        width: auto;
    }
    
    .form-section {
        padding: 1.25rem;
    }
}
</style>

<div class="body-bg">
<div class="container-fluid">
    <div class="row">
        <?php include '../../includes/sidebar.php'; ?>
        <main class="main-content main-content-boxed">
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                <div>
                    <h1 class="h2 mb-2">Agregar Nueva Membresía</h1>
                    <p class="text-muted mb-0">Complete el formulario para registrar una nueva membresía</p>
                </div>
                <div class="d-flex gap-3 flex-wrap flex-md-nowrap">
                    <a href="list.php" class="btn btn-outline-secondary w-100 w-md-auto">
                        <i class="fas fa-arrow-left me-2"></i>Volver al Listado
                    </a>
                </div>
            </div>

            <?php if (!empty($errores)): ?>
            <div class="alert alert-danger alert-dismissible fade show fade-in" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Error:</strong> Por favor corrija los siguientes errores:
                <ul class="mb-0 mt-2">
                    <?php foreach ($errores as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <form method="post" enctype="multipart/form-data" onsubmit="return guardarFirmaYFoto()" class="needs-validation" novalidate>
                <div class="form-section">
                    <h5><i class="fas fa-user me-2"></i>Datos del Cliente</h5>
        <div class="row g-3">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="nombre" class="form-label">Nombre(s) <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="nombre" name="nombre" required>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="apellido_paterno" class="form-label">Apellido Paterno <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="apellido_paterno" name="apellido_paterno" required>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="apellido_materno" class="form-label">Apellido Materno</label>
                    <input type="text" class="form-control" id="apellido_materno" name="apellido_materno">
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="form-group">
                    <label for="edad" class="form-label">Edad <span class="text-danger">*</span></label>
                    <input type="number" class="form-control" id="edad" name="edad" min="1" required>
                </div>
            </div>
            
            <div class="col-md-5">
                <div class="form-group">
                    <label for="fecha_nacimiento" class="form-label">Fecha de nacimiento <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" required>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="form-group">
                    <label for="sexo" class="form-label">Sexo <span class="text-danger">*</span></label>
                    <select name="sexo" id="sexo" class="form-select" required>
                        <option value="">Seleccione</option>
                        <option value="M">Masculino</option>
                        <option value="F">Femenino</option>
                        <option value="Otro">Otro</option>
                    </select>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="curp" class="form-label">CURP <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="curp" name="curp" maxlength="18" required>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="correo" class="form-label">Correo electrónico <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="correo" name="correo" required>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="telefono" class="form-label">Teléfono <span class="text-danger">*</span></label>
                    <input type="tel" class="form-control" id="telefono" name="telefono" required>
                </div>
            </div>
            
            <div class="col-12">
                <div class="form-group">
                    <label for="direccion" class="form-label">Dirección</label>
                    <input type="text" class="form-control" id="direccion" name="direccion">
                </div>
            </div>
            
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">Fotografía <span class="text-danger">*</span></label>
                    <div id="camara-container" class="border rounded p-3 bg-light">
                        <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
                            <button type="button" id="btnCamara" class="btn btn-sm btn-outline-primary" onclick="toggleCamara()">
                                <i class="fas fa-camera me-1"></i>Activar cámara
                            </button>
                            <button type="button" onclick="tomarFoto()" id="btnTomarFoto" class="btn btn-sm btn-success" style="display:none;">
                                <i class="fas fa-camera me-1"></i>Tomar foto
                            </button>
                        </div>
                        <div class="text-center">
                            <video id="video" width="320" height="240" autoplay style="display:none; max-width:100%;"></video>
                            <canvas id="canvas_foto" width="320" height="240" style="display:none;"></canvas>
                            <img id="preview_foto" src="" alt="Vista previa de la foto" style="display:none; max-width:100%; max-height:300px; border-radius:0.5rem;"/>
                        </div>
                        <input type="hidden" name="foto_data" id="foto_data">
                        <div class="form-text mt-2">Permita el acceso a la cámara y tome la foto del cliente.</div>
                    </div>
                </div>
            </div>
        </div>
                </div>

                <div class="form-section">
                    <h5><i class="fas fa-id-card me-2"></i>Datos de la Membresía</h5>
        <div class="row g-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="tipo_membresia_id" class="form-label">Tipo de Membresía <span class="text-danger">*</span></label>
                    <select name="tipo_membresia_id" id="tipo_membresia_id" class="form-select" required>
                        <option value="">Seleccione un tipo</option>
                        <?php foreach ($tipos as $t): ?>
                            <option value="<?= $t->id ?>"><?= htmlspecialchars($t->nombre) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="metodo_pago" class="form-label">Método de pago <span class="text-danger">*</span></label>
                    <select name="metodo_pago" id="metodo_pago" class="form-select" required onchange="toggleTarjetaFields()">
                        <option value="">Seleccione un método</option>
                        <option value="Tarjeta">Tarjeta</option>
                        <option value="Efectivo">Efectivo</option>
                        <option value="Transferencia">Transferencia</option>
                    </select>
                </div>
            </div>
            
            <!-- Campos para pago con tarjeta -->
            <div id="tarjetaFields" style="display: none;">
                <div class="row g-3">
                    <div class="col-12">
                        <h6 class="mb-3">Información de la Tarjeta</h6>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="numero_tarjeta" class="form-label">Número de tarjeta <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="numero_tarjeta" name="numero_tarjeta" placeholder="#### #### #### ####" maxlength="19">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="nombre_tarjeta" class="form-label">Titular de la cuenta <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nombre_tarjeta" name="nombre_tarjeta" placeholder="Titular de la cuenta ">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="mes_vencimiento" class="form-label">Mes de vencimiento <span class="text-danger">*</span></label>
                            <select class="form-select" id="mes_vencimiento" name="mes_vencimiento">
                                <option value="">MM</option>
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?= str_pad($i, 2, '0', STR_PAD_LEFT) ?>"><?= str_pad($i, 2, '0', STR_PAD_LEFT) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="anio_vencimiento" class="form-label">Año de vencimiento <span class="text-danger">*</span></label>
                            <select class="form-select" id="anio_vencimiento" name="anio_vencimiento">
                                <option value="">AAAA</option>
                                <?php 
                                $currentYear = date('Y');
                                for($i = $currentYear; $i <= $currentYear + 10; $i++): 
                                ?>
                                    <option value="<?= $i ?>"><?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="cvv" class="form-label">CVV / CVC <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="cvv" name="cvv" placeholder="123" maxlength="4">
                        </div>
                    </div>
                </div>
            </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="fecha_inicio" class="form-label">Fecha de inicio <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="fecha_inicio" name="fecha_inicio" value="<?= date('Y-m-d') ?>" required>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label for="fecha_fin" class="form-label">Fecha de fin <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" id="fecha_fin" name="fecha_fin" required>
                </div>
            </div>
            
            <div class="col-12">
                <div class="form-group">
                    <label class="form-label">Firma digital <span class="text-danger">*</span></label>
                    <div id="signature-pad" class="signature-pad">
                        <div class="signature-pad--body">
                            <canvas id="firma" width="100%" height="200"></canvas>
                        </div>
                        <div class="signature-pad--footer">
                            <div class="description">Firme arriba en el área designada</div>
                            <div class="d-flex gap-2 mt-2">
                                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="limpiarFirma()">
                                    <i class="fas fa-eraser me-1"></i> Limpiar
                                </button>
                                <button type="button" class="btn btn-outline-primary btn-sm" onclick="guardarFirma()">
                                    <i class="fas fa-save me-1"></i> Guardar Firma
                                </button>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="firma_data" id="firma_data">
                </div>
            </div>
        </div>
                </div>

                <div class="d-flex justify-content-end gap-3 mt-5 pt-3 border-top">
                    <a href="list.php" class="btn btn-lg btn-outline-secondary">
                        <i class="fas fa-times me-2"></i>Cancelar
                    </a>
                    <button type="submit" class="btn btn-lg btn-primary px-4">
                        <i class="fas fa-save me-2"></i>Guardar Membresía
                    </button>
                </div>
</div>
</div>

<?php include '../../includes/footer.php'; ?>
<script>
// ... (rest of the code remains the same)
let video = document.getElementById('video');
let canvasFoto = document.getElementById('canvas_foto');
let previewFoto = document.getElementById('preview_foto');
let fotoData = document.getElementById('foto_data');
let btnCamara = document.getElementById('btnCamara');
let btnTomarFoto = document.getElementById('btnTomarFoto');
let stream = null;
let camaraActiva = false;

function toggleCamara() {
    if (!camaraActiva) {
        // Activar cámara
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(function(s) {
                    stream = s;
                    video.srcObject = stream;
                    video.style.display = 'block';
                    btnTomarFoto.style.display = 'inline-block';
                    btnCamara.textContent = 'Desactivar cámara';
                    camaraActiva = true;
                })
                .catch(function(err) {
                    alert('No se pudo acceder a la cámara: ' + err);
                });
        }
    } else {
        // Desactivar cámara
        if (stream) {
            let tracks = stream.getTracks();
            tracks.forEach(track => track.stop());
        }
        video.srcObject = null;
        video.style.display = 'none';
        btnTomarFoto.style.display = 'none';
        btnCamara.textContent = 'Activar cámara';
        camaraActiva = false;
    }
}

function tomarFoto() {
    canvasFoto.style.display = 'block';
    previewFoto.style.display = 'block';
    canvasFoto.getContext('2d').drawImage(video, 0, 0, canvasFoto.width, canvasFoto.height);
    let dataURL = canvasFoto.toDataURL('image/png');
    previewFoto.src = dataURL;
    fotoData.value = dataURL;
    // Opcional: desactivar cámara después de tomar la foto
    toggleCamara();
}

// --- FIRMA DIGITAL ---
let canvas = document.getElementById('firma');
let ctx = canvas.getContext('2d');
let dibujando = false;
let lastX = 0;
let lastY = 0;

// Configurar el canvas para alta resolución
function setupCanvas() {
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    
    // Establecer el tamaño real del canvas
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    
    // Establecer el tamaño CSS
    canvas.style.width = rect.width + 'px';
    canvas.style.height = rect.height + 'px';
    
    // Escalar el contexto
    ctx.scale(dpr, dpr);
    
    // Configurar el estilo del trazo
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#000';
}

// Inicializar el canvas cuando se carga la página
document.addEventListener('DOMContentLoaded', function() {
    setupCanvas();
});

// Reconfigurar el canvas cuando cambie el tamaño de la ventana
window.addEventListener('resize', function() {
    setupCanvas();
});

canvas.addEventListener('mousedown', startDrawing);
canvas.addEventListener('mouseup', stopDrawing);
canvas.addEventListener('mouseout', stopDrawing);
canvas.addEventListener('mousemove', draw);

canvas.addEventListener('touchstart', startDrawing);
canvas.addEventListener('touchend', stopDrawing);
canvas.addEventListener('touchcancel', stopDrawing);
canvas.addEventListener('touchmove', drawTouch);

function startDrawing(e) {
    dibujando = true;
    const pos = getPosition(e);
    lastX = pos.x;
    lastY = pos.y;
    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
}

function stopDrawing() {
    dibujando = false;
}

function getPosition(e) {
    const rect = canvas.getBoundingClientRect();
    let x, y;
    
    if (e.type.includes('touch')) {
        x = e.touches[0].clientX - rect.left;
        y = e.touches[0].clientY - rect.top;
    } else {
        x = e.clientX - rect.left;
        y = e.clientY - rect.top;
    }
    
    return { x, y };
}

function draw(e) {
    if (!dibujando) return;
    
    const pos = getPosition(e);
    const currentX = pos.x;
    const currentY = pos.y;
    
    ctx.lineTo(currentX, currentY);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(currentX, currentY);
    
    lastX = currentX;
    lastY = currentY;
}

function drawTouch(e) {
    e.preventDefault();
    draw(e);
}
function limpiarFirma() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // Resetear el estado de dibujo
    dibujando = false;
    lastX = 0;
    lastY = 0;
}

// Función para verificar si el canvas está en blanco
function isCanvasBlank(canvas) {
    const context = canvas.getContext('2d');
    const pixelBuffer = new Uint32Array(
        context.getImageData(0, 0, canvas.width, canvas.height).data.buffer
    );
    return !pixelBuffer.some(color => color !== 0);
}
function guardarFirma() {
    // Verificar si el canvas está en blanco
    if (isCanvasBlank(canvas)) {
        // Mostrar error si el canvas está vacío
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-warning alert-dismissible fade show';
        alertDiv.role = 'alert';
        alertDiv.innerHTML = `
            <i class="fas fa-exclamation-triangle me-2"></i> 
            <strong>Atención:</strong> Por favor, realice una firma antes de guardar.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        // Remover alertas existentes
        const existingAlert = document.querySelector('.alert-warning');
        if (existingAlert) {
            existingAlert.remove();
        }
        
        // Agregar la nueva alerta
        const form = document.querySelector('form');
        form.insertBefore(alertDiv, form.firstChild);
        
        // Auto-remover después de 5 segundos
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
        
        return false;
    }
    
    // Guardar la firma con alta calidad
    const dataURL = canvas.toDataURL('image/png', 1.0);
    document.getElementById('firma_data').value = dataURL;
    
    // Mostrar mensaje de éxito
    const successDiv = document.createElement('div');
    successDiv.className = 'alert alert-success alert-dismissible fade show';
    successDiv.role = 'alert';
    successDiv.innerHTML = `
        <i class="fas fa-check-circle me-2"></i> 
        <strong>Éxito:</strong> Firma guardada correctamente.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Remover alertas existentes de éxito
    const existingSuccess = document.querySelector('.alert-success');
    if (existingSuccess) {
        existingSuccess.remove();
    }
    
    // Agregar la nueva alerta
    const form = document.querySelector('form');
    form.insertBefore(successDiv, form.firstChild);
    
    // Auto-remover después de 3 segundos
    setTimeout(() => {
        if (successDiv.parentNode) {
            successDiv.remove();
        }
    }, 3000);
    
    return true;
}

function guardarFirmaYFoto() {
    // Validar firma
    if (!guardarFirma()) {
        return false;
    }
    // Validar foto
    if (!fotoData.value) {
        alert('Por favor, tome la foto del cliente.');
        return false;
    }
    
    // Validar campos de tarjeta si el método de pago es tarjeta
    let metodoPago = document.getElementById('metodo_pago').value;
    if (metodoPago === 'Tarjeta') {
        if (!validarTarjeta()) {
            return false;
        }
    }
    
    return true;
}

// --- PAGO CON TARJETA ---
function toggleTarjetaFields() {
    const metodoPago = document.getElementById('metodo_pago').value;
    const tarjetaFields = document.getElementById('tarjetaFields');
    
    if (metodoPago === 'Tarjeta') {
        tarjetaFields.style.display = 'block';
        // Hacer obligatorios los campos de tarjeta
        document.querySelectorAll('#tarjetaFields [required]').forEach(input => {
            input.required = true;
        });
    } else {
        tarjetaFields.style.display = 'none';
        // Quitar el atributo required de los campos de tarjeta
        document.querySelectorAll('#tarjetaFields [required]').forEach(input => {
            input.required = false;
        });
    }
}

// Formatear número de tarjeta con espacios cada 4 dígitos
document.getElementById('numero_tarjeta').addEventListener('input', function(e) {
    // Eliminar todo lo que no sean números
    let value = e.target.value.replace(/\D/g, '');
    
    // Agregar un espacio cada 4 dígitos
    value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
    
    // Actualizar el valor del campo
    e.target.value = value.trim();
});

// Validar CVV (solo números, máximo 4 dígitos)
document.getElementById('cvv').addEventListener('input', function(e) {
    e.target.value = e.target.value.replace(/\D/g, '').substring(0, 4);
});

// Función para validar los campos de tarjeta
function validarTarjeta() {
    const numeroTarjeta = document.getElementById('numero_tarjeta').value.replace(/\s/g, '');
    const nombreTarjeta = document.getElementById('nombre_tarjeta').value.trim();
    const mesVencimiento = document.getElementById('mes_vencimiento').value;
    const anioVencimiento = document.getElementById('anio_vencimiento').value;
    const cvv = document.getElementById('cvv').value.trim();
    
    // Validar número de tarjeta (entre 13 y 19 dígitos)
    if (!/^\d{13,19}$/.test(numeroTarjeta)) {
        alert('Por favor, ingrese un número de tarjeta válido (13-19 dígitos).');
        return false;
    }
    
    // Validar nombre en la tarjeta
    if (nombreTarjeta.length < 3) {
        alert('Por favor, ingrese el nombre como aparece en la tarjeta.');
        return false;
    }
    
    // Validar fecha de vencimiento
    if (!mesVencimiento || !anioVencimiento) {
        alert('Por favor, seleccione el mes y año de vencimiento de la tarjeta.');
        return false;
    }
    
    // Validar que la fecha no sea anterior a la actual
    const hoy = new Date();
    const mesActual = hoy.getMonth() + 1; // Los meses van de 0 a 11
    const anioActual = hoy.getFullYear();
    
    if (parseInt(anioVencimiento) < anioActual || 
        (parseInt(anioVencimiento) === anioActual && parseInt(mesVencimiento) < mesActual)) {
        alert('La tarjeta está vencida. Por favor, verifique la fecha de vencimiento.');
        return false;
    }
    
    // Validar CVV (3 o 4 dígitos)
    if (!/^\d{3,4}$/.test(cvv)) {
        alert('Por favor, ingrese un CVV válido (3 o 4 dígitos).');
        return false;
    }
    
    return true;
}

// Inicializar la visibilidad de los campos de tarjeta al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    toggleTarjetaFields();
    
    // Agregar indicador visual cuando se está dibujando
    canvas.addEventListener('mousedown', function() {
        canvas.style.cursor = 'crosshair';
    });
    
    canvas.addEventListener('mouseup', function() {
        canvas.style.cursor = 'crosshair';
    });
    
    canvas.addEventListener('mouseenter', function() {
        canvas.style.cursor = 'crosshair';
    });
    
    canvas.addEventListener('mouseleave', function() {
        canvas.style.cursor = 'default';
    });
});
</script>
<?php
include '../../includes/footer.php';