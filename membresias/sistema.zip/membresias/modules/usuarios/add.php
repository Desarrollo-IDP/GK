<?php
include '../../includes/header.php';
?>
<h1>Agregar Usuario</h1>
<form method="post">
    <!-- Campos del usuario -->
</form>
<?php
include '../../includes/footer.php'; 