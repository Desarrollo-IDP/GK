<?php
include '../../includes/header.php';
?>
<h1>Editar Usuario</h1>
<form method="post">
    <!-- Campos del usuario para editar -->
</form>
<?php
include '../../includes/footer.php'; 