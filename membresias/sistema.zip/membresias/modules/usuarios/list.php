<?php
include '../../includes/header.php';
?>
<h1>Lista de Usuarios</h1>
<!-- Tabla de usuarios -->
<?php
include '../../includes/footer.php'; 