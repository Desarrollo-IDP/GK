<?php
include '../../includes/header.php';

// Obtener datos del cliente
$sql = "SELECT * FROM clientes WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$_GET['id']]);
$cliente = $stmt->fetch();

if (!$cliente) {
    $_SESSION['error'] = 'Cliente no encontrado';
    header('Location: list.php');
    exit;
}

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido_paterno = trim($_POST['apellido_paterno'] ?? '');
    $apellido_materno = trim($_POST['apellido_materno'] ?? '');
    $edad = intval($_POST['edad'] ?? 0);
    $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
    $sexo = $_POST['sexo'] ?? '';
    $curp = trim($_POST['curp'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $foto = $cliente['foto']; // Mantener la foto actual por defecto
}
?>

<h1>Editar Cliente</h1>
<form method="post" enctype="multipart/form-data">
    <!-- Campos del cliente para editar -->
    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre" value="<?php echo $cliente['nombre'] ?? ''; ?>"><br><br>
    <label for="apellido_paterno">Apellido Paterno:</label>
    <input type="text" id="apellido_paterno" name="apellido_paterno" value="<?php echo $cliente['apellido_paterno'] ?? ''; ?>"><br><br>
    <label for="apellido_materno">Apellido Materno:</label>
    <input type="text" id="apellido_materno" name="apellido_materno" value="<?php echo $cliente['apellido_materno'] ?? ''; ?>"><br><br>
    <label for="edad">Edad:</label>
    <input type="number" id="edad" name="edad" value="<?php echo $cliente['edad'] ?? ''; ?>"><br><br>
    <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
    <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo $cliente['fecha_nacimiento'] ?? ''; ?>"><br><br>
    <label for="sexo">Sexo:</label>
    <select id="sexo" name="sexo">
        <option value="masculino" <?php echo ($cliente['sexo'] ?? '') == 'masculino' ? 'selected' : ''; ?>>Masculino</option>
        <option value="femenino" <?php echo ($cliente['sexo'] ?? '') == 'femenino' ? 'selected' : ''; ?>>Femenino</option>
    </select><br><br>
    <label for="curp">CURP:</label>
    <input type="text" id="curp" name="curp" value="<?php echo $cliente['curp'] ?? ''; ?>"><br><br>
    <label for="direccion">Dirección:</label>
    <input type="text" id="direccion" name="direccion" value="<?php echo $cliente['direccion'] ?? ''; ?>"><br><br>
    <label for="correo">Correo:</label>
    <input type="email" id="correo" name="correo" value="<?php echo $cliente['correo'] ?? ''; ?>"><br><br>
    <label for="telefono">Teléfono:</label>
    <input type="text" id="telefono" name="telefono" value="<?php echo $cliente['telefono'] ?? ''; ?>"><br><br>
    <label for="foto">Foto:</label>
    <input type="file" id="foto" name="foto">
    <img src="<?php echo $cliente['foto'] ?? ''; ?>" alt="Foto del cliente"><br><br>
    <input type="submit" value="Guardar cambios">
</form>
<?php
include '../../includes/footer.php'; 