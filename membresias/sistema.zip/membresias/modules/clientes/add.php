<?php
include '../../includes/header.php';
include '../../includes/db.php';

// Procesar formulario
$errores = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido_paterno = trim($_POST['apellido_paterno'] ?? '');
    $apellido_materno = trim($_POST['apellido_materno'] ?? '');
    $edad = intval($_POST['edad'] ?? 0);
    $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
    $sexo = $_POST['sexo'] ?? '';
    $curp = trim($_POST['curp'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $foto = null;

    // Validaciones básicas
    if ($nombre === '') $errores[] = 'El nombre es obligatorio.';
    if ($edad <= 0) $errores[] = 'La edad debe ser mayor a 0.';
    if ($fecha_nacimiento === '') $errores[] = 'La fecha de nacimiento es obligatoria.';
    if ($sexo === '') $errores[] = 'El sexo es obligatorio.';
    if ($curp === '') $errores[] = 'El CURP es obligatorio.';
    if ($correo === '') $errores[] = 'El correo es obligatorio.';
    if ($telefono === '') $errores[] = 'El número de teléfono es obligatorio.';

    // Manejo de la foto
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $fotoTmp = $_FILES['foto']['tmp_name'];
        $fotoNombre = basename($_FILES['foto']['name']);
        $ext = strtolower(pathinfo($fotoNombre, PATHINFO_EXTENSION));
        $permitidas = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($ext, $permitidas)) {
            $errores[] = 'Formato de foto no permitido.';
        } else {
            $dirFotos = '../../uploads/fotos/';
            if (!is_dir($dirFotos)) {
                mkdir($dirFotos, 0777, true);
            }
            $fotoFinal = $dirFotos . uniqid() . '_' . $fotoNombre;
            if (move_uploaded_file($fotoTmp, $fotoFinal)) {
                $foto = str_replace('../../', '', $fotoFinal); // Guardar ruta relativa
            } else {
                $errores[] = 'Error al subir la foto.';
            }
        }
    } else {
        $errores[] = 'La foto es obligatoria.';
    }

    // Si no hay errores, guardar en la base de datos
    if (empty($errores)) {
        $sql = "INSERT INTO clientes (nombre, apellido_paterno, apellido_materno, edad, fecha_nacimiento, sexo, curp, foto, direccion, correo, telefono) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        // Validar campos
        if (empty($nombre) || empty($apellido_paterno) || empty($edad) || empty($fecha_nacimiento) || empty($sexo) || empty($curp) || empty($direccion) || empty($correo) || empty($telefono)) {
            header('Location: list.php');
            exit;
        }
        $stmt->execute([$nombre, $apellido_paterno, $apellido_materno, $edad, $fecha_nacimiento, $sexo, $curp, $foto, $direccion, $correo, $telefono]);
        header('Location: list.php');
        exit;
    }
}
?>
<h1>Agregar Cliente</h1>
<?php if (!empty($errores)): ?>
    <div style="color:red;">
        <ul>
            <?php foreach ($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>
<form method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-4">
            <div class="form-group mb-3">
                <label for="nombre">Nombre(s):</label>
                <input type="text" class="form-control" id="nombre" name="nombre" required>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group mb-3">
                <label for="apellido_paterno">Apellido Paterno:</label>
                <input type="text" class="form-control" id="apellido_paterno" name="apellido_paterno" required>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group mb-3">
                <label for="apellido_materno">Apellido Materno:</label>
                <input type="text" class="form-control" id="apellido_materno" name="apellido_materno">
            </div>
        </div>
    </div>
    <label>Edad:<br><input type="number" name="edad" min="1" required></label><br><br>
    <label>Fecha de nacimiento:<br><input type="date" name="fecha_nacimiento" required></label><br><br>
    <label>Sexo:<br>
        <select name="sexo" required>
            <option value="">Seleccione</option>
            <option value="M">Masculino</option>
            <option value="F">Femenino</option>
            <option value="Otro">Otro</option>
        </select>
    </label><br><br>
    <label>CURP:<br><input type="text" name="curp" maxlength="18" required></label><br><br>
    <label>Foto:<br>
        <input type="file" name="foto" accept="image/*" capture="environment" required>
        <small>Puedes tomar una foto con la cámara del dispositivo.</small>
    </label><br><br>
    <label>Dirección:<br><input type="text" name="direccion"></label><br><br>
    <label>Correo:<br><input type="email" name="correo" required></label><br><br>
    <label>Número de teléfono:<br><input type="text" name="telefono" required></label><br><br>
    <button type="submit">Guardar</button>
</form>
<?php
include '../../includes/footer.php'; 