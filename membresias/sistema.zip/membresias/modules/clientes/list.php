<?php
include '../../includes/header.php';
include '../../includes/db.php';

// Debug: Mostrar información de conexión
echo '<!-- Debug: Intentando conectar a la base de datos -->';

// Obtener todos los clientes de la base de datos
try {
    // Debug: Mostrar consulta SQL
    $sql = 'SELECT * FROM clientes ORDER BY nombre';
    echo '<!-- Debug: Ejecutando consulta: ' . htmlspecialchars($sql) . ' -->';
    
    $stmt = $pdo->query($sql);
    $clientes = $stmt->fetchAll();
    
    // Debug: Mostrar número de clientes obtenidos
    echo '<!-- Debug: Número de clientes encontrados: ' . count($clientes) . ' -->';
    
    // Debug: Mostrar los primeros 3 clientes (solo para depuración)
    if (count($clientes) > 0) {
        echo '<!-- Debug: Primeros 3 clientes: ' . htmlspecialchars(print_r(array_slice($clientes, 0, 3), true)) . ' -->';
    }
    
} catch (PDOException $e) {
    $error_message = 'Error al cargar los clientes: ' . $e->getMessage();
    echo '<div class="alert alert-danger">' . htmlspecialchars($error_message) . '</div>';
    error_log($error_message);
    $clientes = [];
}
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Lista de Clientes</h1>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Clientes Registrados
            <a href="add.php" class="btn btn-primary btn-sm float-end">
                <i class="fas fa-plus"></i> Nuevo Cliente
            </a>
        </div>
        <div class="card-body">
            <?php if (empty($clientes)): ?>
                <div class="alert alert-info">No hay clientes registrados.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" id="clientesTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Apellido Paterno</th>
                            <th>Apellido Materno</th>
                            <th>Edad</th>
                            <th>Sexo</th>
                            <th>CURP</th>
                            <th>Teléfono</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                        <tbody>
                            <?php foreach ($clientes as $cliente): ?>
                                <tr>
                                <td><?= htmlspecialchars($cliente['nombre']) ?></td>
                                <td><?= htmlspecialchars($cliente['apellido_paterno']) ?></td>
                                <td><?= htmlspecialchars($cliente['apellido_materno'] ?? '') ?></td>
                                <td><?= htmlspecialchars($cliente['edad']) ?></td>
                                <td><?= htmlspecialchars($cliente['sexo']) ?></td>
                                <td><?= htmlspecialchars($cliente['curp']) ?></td>
                                <td><?= htmlspecialchars($cliente['telefono']) ?></td>
                                <td>
                                    <a href="edit.php?id=<?= $cliente['id'] ?>" class="btn btn-sm btn-warning">Editar</a>
                                    <a href="delete.php?id=<?= $cliente['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro de eliminar este cliente?')">Eliminar</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- DataTables CSS -->
<link href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<!-- DataTables JavaScript -->
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<!-- Inicialización de DataTable -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        $('#clientesTable').DataTable({
            language: {
                url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/es-MX.json'
            },
            responsive: true
        });
    });
</script>

<?php include '../../includes/footer.php'; ?> 