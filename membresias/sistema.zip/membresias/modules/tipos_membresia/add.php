<?php
include '../../includes/header.php';
include '../../includes/db.php';

$errores = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $precio = floatval($_POST['precio'] ?? 0);
    if ($nombre === '') $errores[] = 'El nombre es obligatorio.';
    if ($precio <= 0) $errores[] = 'El precio debe ser mayor a 0.';
    if (empty($errores)) {
        $sql = "INSERT INTO tipos_membresia (nombre, descripcion, precio) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nombre, $descripcion, $precio]);
        header('Location: list.php');
        exit;
    }
}
?>
<h1>Agregar Tipo de Membresía</h1>
<?php if (!empty($errores)): ?>
    <div style="color:red;">
        <ul>
            <?php foreach ($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>
<form method="post">
    <label>Nombre:<br><input type="text" name="nombre" required></label><br><br>
    <label>Descripción:<br><textarea name="descripcion"></textarea></label><br><br>
    <label>Precio:<br><input type="number" name="precio" min="1" step="0.01" required></label><br><br>
    <button type="submit">Guardar</button>
</form>
<?php
include '../../includes/footer.php'; 