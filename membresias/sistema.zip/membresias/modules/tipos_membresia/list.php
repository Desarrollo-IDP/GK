<?php
include '../../includes/header.php';
include '../../includes/db.php';

$tipos = $pdo->query("SELECT * FROM tipos_membresia ORDER BY nombre ASC")->fetchAll();
?>
<h1>Tipos de Membresía</h1>
<a href="add.php">Agregar tipo de membresía</a>
<table border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Precio</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($tipos as $t): ?>
            <tr>
                <td><?= htmlspecialchars($t['nombre']) ?></td>
                <td><?= htmlspecialchars($t['descripcion']) ?></td>
                <td>$<?= number_format($t['precio'], 2) ?></td>
                <td>
                    <a href="edit.php?id=<?= $t['id'] ?>">Editar</a> |
                    <a href="delete.php?id=<?= $t['id'] ?>" onclick="return confirm('¿Seguro que deseas eliminar este tipo de membresía?')">Eliminar</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php
include '../../includes/footer.php'; 