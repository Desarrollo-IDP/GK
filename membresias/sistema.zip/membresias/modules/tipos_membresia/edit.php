<?php
include '../../includes/header.php';
include '../../includes/db.php';

$id = $_GET['id'] ?? null;
if (!$id) {
    echo '<p>ID no especificado.</p>';
    include '../../includes/footer.php';
    exit;
}
$sql = "SELECT * FROM tipos_membresia WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$tipo = $stmt->fetch();
if (!$tipo) {
    echo '<p>Tipo de membresía no encontrado.</p>';
    include '../../includes/footer.php';
    exit;
}

$errores = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $precio = floatval($_POST['precio'] ?? 0);
    if ($nombre === '') $errores[] = 'El nombre es obligatorio.';
    if ($precio <= 0) $errores[] = 'El precio debe ser mayor a 0.';
    if (empty($errores)) {
        $sql = "UPDATE tipos_membresia SET nombre=?, descripcion=?, precio=? WHERE id=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nombre, $descripcion, $precio, $id]);
        header('Location: list.php');
        exit;
    }
}
?>
<h1>Editar Tipo de Membresía</h1>
<?php if (!empty($errores)): ?>
    <div style="color:red;">
        <ul>
            <?php foreach ($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>
<form method="post">
    <label>Nombre:<br><input type="text" name="nombre" value="<?= htmlspecialchars($tipo['nombre']) ?>" required></label><br><br>
    <label>Descripción:<br><textarea name="descripcion"><?= htmlspecialchars($tipo['descripcion']) ?></textarea></label><br><br>
    <label>Precio:<br><input type="number" name="precio" min="1" step="0.01" value="<?= htmlspecialchars($tipo['precio']) ?>" required></label><br><br>
    <button type="submit">Guardar cambios</button>
</form>
<?php
include '../../includes/footer.php'; 