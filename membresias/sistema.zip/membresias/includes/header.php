<?php
$base_url = '';
$current_dir = dirname($_SERVER['PHP_SELF']);
$root_dir = '/Tickets';

$levels_up = substr_count(str_replace($root_dir, '', $current_dir), '/');
for ($i = 0; $i < $levels_up; $i++) {
    $base_url .= '../';
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Membresías</title>
    
    <!-- Fuentes -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <!-- Sistema de diseño moderno -->
    <link rel="stylesheet" href="<?php echo $base_url; ?>membresias/css/modern-design-system.css">
    
    <style>
    :root {
        --primary-color: #202654;
        --secondary-color: #1a1f45;
        --accent-color: #3a86ff;
        --text-light: #f8f9fa;
        --text-muted: #adb5bd;
        --sidebar-width: 250px;
        --sidebar-collapsed-width: 70px;
        --header-height: 60px;
    }
    
    body {
        font-family: 'Inter', sans-serif;
        background-color: #f5f7fb;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }
    
    .main-content {
        margin-left: var(--sidebar-width);
        padding: 20px;
        margin-top: var(--header-height);
        flex: 1;
        transition: margin 0.3s ease;
    }
    
    .sidebar-collapsed + .main-content {
        margin-left: var(--sidebar-collapsed-width);
    }
    
    @media (max-width: 991.98px) {
        .main-content {
            margin-left: 0;
        }
        
        .sidebar-collapsed + .main-content {
            margin-left: 0;
        }
    }
    
    /* Estilos para el header */
    .navbar {
        height: var(--header-height);
        padding: 0 1.5rem;
        background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        z-index: 1030;
    }
    
    .navbar-brand {
        font-weight: 600;
        font-size: 1.2rem;
        color: var(--text-light) !important;
    }
    
    .navbar-brand i {
        font-size: 1.5rem;
    }
    
    .search-container {
        flex: 1;
        max-width: 600px;
        margin: 0 2rem;
    }
    
    .search-input {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: white;
        border-radius: 6px;
        padding: 0.5rem 1rem;
        transition: all 0.3s;
    }
    
    .search-input:focus {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.2);
        box-shadow: 0 0 0 0.25rem rgba(58, 134, 255, 0.25);
        color: white;
    }
    
    .search-input::placeholder {
        color: rgba(255, 255, 255, 0.6);
    }
    
    .avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.1rem;
    }
    
    .nav-link {
        color: rgba(255, 255, 255, 0.8) !important;
        padding: 0.5rem 1rem;
        transition: all 0.2s;
    }
    
    .nav-link:hover {
        color: white !important;
    }
    
    .dropdown-menu {
        border: none;
        box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        padding: 0.5rem 0;
        min-width: 220px;
    }
    
    .dropdown-item {
        padding: 0.5rem 1.5rem;
        color: #333;
        font-weight: 400;
    }
    
    .dropdown-item:hover {
        background-color: #f8f9fa;
        color: var(--primary-color);
    }
    
    .dropdown-divider {
        margin: 0.5rem 0;
    }
    
    .badge {
        font-size: 0.65rem;
        font-weight: 600;
        padding: 0.25rem 0.4rem;
    }
    
    /* Estilos para el toggle del sidebar en móvil */
    .navbar-toggler {
        border: none;
        padding: 0.5rem;
        color: white;
    }
    
    .navbar-toggler:focus {
        box-shadow: none;
        outline: none;
    }
    
    @media (max-width: 991.98px) {
        .search-container {
            display: none;
        }
    }
    </style>
</head>
<body>
    <!-- Header moderno -->
    <header class="navbar navbar-expand-md navbar-dark sticky-top">
        <div class="container-fluid">
            <!-- Botón toggle para sidebar en móvil -->
            <button class="navbar-toggler d-md-none me-3" type="button" id="sidebarToggle">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <!-- Logo y marca -->
            <a class="navbar-brand d-flex align-items-center" href="<?php echo $base_url; ?>dashboard.php">
                <i class="fas fa-id-card-alt me-2"></i>
                <span class="d-none d-md-inline">Sistema de Membresías</span>
            </a>
            
            <!-- Botón de búsqueda en móvil -->
            <button class="btn btn-link text-white d-md-none ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSearch">
                <i class="fas fa-search"></i>
            </button>
            
            <!-- Contenido del navbar -->
            <div class="collapse navbar-collapse" id="navbarSearch">
                <!-- Barra de búsqueda -->
                <div class="search-container ms-md-3">
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-end-0">
                            <i class="fas fa-search text-white-50"></i>
                        </span>
                        <input class="form-control search-input" type="text" placeholder="Buscar clientes, membresías..." aria-label="Buscar">
                    </div>
                </div>
                
                <!-- Menú de usuario -->
                <ul class="navbar-nav ms-auto">
                    <!-- Notificaciones -->
                    <li class="nav-item dropdown d-none d-md-block">
                        <a class="nav-link position-relative" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-bell"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                0
                                <span class="visually-hidden">notificaciones sin leer</span>
                            </span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><h6 class="dropdown-header">Notificaciones</h6></li>
                            <li><a class="dropdown-item" href="#">No hay notificaciones nuevas</a></li>
                        </ul>
                    </li>
                    
                    <!-- Perfil de usuario -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="avatar me-2">
                                <i class="fas fa-user-circle"></i>
                            </div>
                            <span class="d-none d-lg-inline"><?php echo $_SESSION['user']['username'] ?? 'Usuario'; ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <h6 class="dropdown-header">Sesión iniciada como</h6>
                                <div class="px-3 py-1 mb-2">
                                    <div class="fw-bold"><?php echo $_SESSION['user']['username'] ?? 'Usuario'; ?></div>
                                    <div class="text-muted small"><?php echo $_SESSION['user']['email'] ?? ''; ?></div>
                                </div>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item" href="<?php echo $base_url; ?>profile.php">
                                    <i class="fas fa-user-circle me-2"></i> Mi perfil
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="<?php echo $base_url; ?>settings.php">
                                    <i class="fas fa-cog me-2"></i> Configuración
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item text-danger" href="<?php echo $base_url; ?>logout.php">
                                    <i class="fas fa-sign-out-alt me-2"></i> Cerrar sesión
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </header> 