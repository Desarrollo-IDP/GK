<?php
// footer.php - Pie de página común
?>
    </div> <!-- Cierre de main-content -->
    
    <footer class="main-footer bg-light py-3 mt-4 border-top">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="footer-copyright text-muted">
                        &copy; <?= date('Y') ?> Sistema de Membresías - Todos los derechos reservados
                    </div>
                </div>
                <div class="col-md-6 text-md-end">
                    <div class="footer-version text-muted">
                        v1.0.0
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Toast Notifications -->
    <?php if (isset($_SESSION['mensaje'])): ?>
    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header <?= $_SESSION['tipo_mensaje'] === 'error' ? 'bg-danger text-white' : 'bg-success text-white' ?>">
                <strong class="me-auto">
                    <?= $_SESSION['tipo_mensaje'] === 'error' ? 'Error' : 'Éxito' ?>
                </strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <?= htmlspecialchars($_SESSION['mensaje']) ?>
            </div>
        </div>
    </div>
    <?php 
    // Clear the message after displaying
    unset($_SESSION['mensaje']);
    unset($_SESSION['tipo_mensaje']);
    endif; 
    ?>

    <!-- Custom Scripts -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize DataTables
        if ($.fn.DataTable.isDataTable('.datatable')) {
            $('.datatable').DataTable().destroy();
        }
        
        $('.datatable').DataTable({
            responsive: true,
            language: {
                url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/es-ES.json'
            },
            dom: "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'f>>" +
                 "<'row'<'col-sm-12'tr>>" +
                 "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
            pageLength: 10,
            lengthMenu: [5, 10, 25, 50, 100],
            order: [],
            columnDefs: [{
                orderable: false,
                targets: 'no-sort'
            }],
            initComplete: function() {
                // Initialize tooltips after table is loaded
                var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl);
                });
            }
        });
        
        // Initialize tooltips outside of DataTables
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]:not(.datatable [data-bs-toggle="tooltip"])'));
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
        
        // Confirmación para acciones de eliminar
        $(document).on('click', '.btn-delete', function(e) {
            if (!confirm('¿Está seguro de que desea eliminar este registro? Esta acción no se puede deshacer.')) {
                e.preventDefault();
                return false;
            }
        });
        
        // Initialize toasts
        var toastElList = [].slice.call(document.querySelectorAll('.toast'));
        var toastList = toastElList.map(function (toastEl) {
            return new bootstrap.Toast(toastEl, { autohide: true, delay: 5000 });
        });
    });
    </script>
</body>
</html>