<!-- Sidebar moderno -->
<nav class="sidebar sidebar-collapsed" id="sidebar">
    <div class="sidebar-nav">
        <!-- Logo y toggle -->
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-id-card-alt"></i>
                <span class="sidebar-logo-text">Membresías</span>
            </div>
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        
        <!-- Menú principal -->
        <div class="nav-section">
            <div class="nav-section-title">Menú Principal</div>
            
            <!-- Dashboard -->
            <div class="nav-item <?= strpos($current_page, 'dashboard') !== false ? 'active' : '' ?>">
                <a href="<?= $base_url ?>dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </div>
            
            <!-- Clientes -->
            <div class="nav-item <?= strpos($current_page, 'clientes') !== false ? 'active' : '' ?>">
                <a href="<?= $base_url ?>membresias/modules/clientes/list.php" class="nav-link">
                    <i class="fas fa-users"></i>
                    <span class="nav-text">Clientes</span>
                </a>
            </div>
            
            <!-- Membresías -->
            <div class="nav-item <?= strpos($current_page, 'membresias') !== false && strpos($current_page, 'tipos_membresia') === false ? 'active' : '' ?>">
                <a href="<?= $base_url ?>membresias/modules/membresias/list.php" class="nav-link">
                    <i class="fas fa-id-card"></i>
                    <span class="nav-text">Membresías</span>
                </a>
            </div>
            
            <!-- Tipos de Membresía -->
            <div class="nav-item <?= strpos($current_page, 'tipos_membresia') !== false ? 'active' : '' ?>">
                <a href="<?= $base_url ?>membresias/modules/tipos_membresia/list.php" class="nav-link">
                    <i class="fas fa-tags"></i>
                    <span class="nav-text">Tipos de Membresía</span>
                </a>
            </div>
            
            <!-- Usuarios -->
            <div class="nav-item <?= strpos($current_page, 'usuarios') !== false ? 'active' : '' ?>">
                <a href="<?= $base_url ?>membresias/modules/usuarios/list.php" class="nav-link">
                    <i class="fas fa-user-cog"></i>
                    <span class="nav-text">Usuarios</span>
                </a>
            </div>
        </div>
        
        <!-- Menú de cuenta -->
        <div class="nav-section mt-auto">
            <div class="nav-section-title">Cuenta</div>
            <div class="nav-item">
                <a href="<?= $base_url ?>profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span class="nav-text">Mi Perfil</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= $base_url ?>settings.php" class="nav-link">
                    <i class="fas fa-cog"></i>
                    <span class="nav-text">Configuración</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= $base_url ?>logout.php" class="nav-link text-danger">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="nav-text">Cerrar Sesión</span>
                </a>
            </div>
        </div>
    </div>
    
    <!-- Footer del sidebar -->
    <div class="sidebar-footer p-3">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center">
                <div class="avatar me-2">
                    <i class="fas fa-shield-alt" style="color: #202654;"></i>
                </div>
                <div class="sidebar-footer-text">
                    <div class="text-sm font-semibold">Membresías</div>
                    <div class="text-xs text-muted">v2.0</div>
                </div>
            </div>
        </div>
    </div>
</nav>

<style>
/* Estilos para el sidebar moderno */
:root {
    --sidebar-width: 260px;
    --sidebar-collapsed-width: 70px;
    --header-height: 60px;
    --primary-color: #3a86ff;
    --text-color: #2d3748;
    --text-muted: #718096;
    --border-color: #e2e8f0;
    --hover-bg: #f7fafc;
    --active-bg: #ebf4ff;
    --transition-speed: 0.3s;
}

.sidebar {
    width: var(--sidebar-width);
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background: white;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.05);
    display: flex;
    flex-direction: column;
    z-index: 1020;
    transition: all var(--transition-speed) ease;
    overflow-y: auto;
}

.sidebar-collapsed {
    width: var(--sidebar-collapsed-width);
    overflow: hidden;
}

/* Header del sidebar */
.sidebar-header {
    padding: 0 1rem;
    height: var(--header-height);
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid var(--border-color);
    position: sticky;
    top: 0;
    background: white;
    z-index: 10;
}

.sidebar-logo {
    display: flex;
    align-items: center;
    color: var(--primary-color);
    font-weight: 600;
    font-size: 1.1rem;
    white-space: nowrap;
    text-decoration: none;
}

.sidebar-logo i {
    font-size: 1.5rem;
    margin-right: 0.75rem;
    min-width: 24px;
    text-align: center;
}

.sidebar-logo-text {
    transition: opacity var(--transition-speed) ease;
}

.sidebar-collapsed .sidebar-logo-text {
    opacity: 0;
    width: 0;
    display: none;
}

.sidebar-toggle {
    background: none;
    border: none;
    color: var(--text-muted);
    font-size: 1.25rem;
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 4px;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
}

.sidebar-toggle:hover {
    background: var(--hover-bg);
    color: var(--primary-color);
}

/* Navegación */
.sidebar-nav {
    flex: 1;
    display: flex;
    flex-direction: column;
    padding: 1rem 0;
    overflow-y: auto;
}

.nav-section {
    margin-bottom: 1.5rem;
    padding: 0 0.5rem;
}

.nav-section-title {
    font-size: 0.7rem;
    font-weight: 600;
    text-transform: uppercase;
    color: var(--text-muted);
    padding: 0 1rem 0.5rem;
    margin-top: 0.5rem;
    letter-spacing: 0.5px;
    white-space: nowrap;
    transition: all var(--transition-speed) ease;
}

.sidebar-collapsed .nav-section-title {
    opacity: 0;
    width: 0;
    height: 0;
    padding: 0;
    margin: 0;
    overflow: hidden;
}

.nav-item {
    position: relative;
    margin: 0.125rem 0;
    border-radius: 6px;
    overflow: hidden;
}

.nav-link {
    display: flex;
    align-items: center;
    padding: 0.6rem 1rem;
    color: var(--text-color) !important;
    text-decoration: none;
    transition: all 0.2s;
    white-space: nowrap;
    border-radius: 6px;
}

.nav-link i {
    font-size: 1.1rem;
    width: 24px;
    text-align: center;
    margin-right: 0.75rem;
    color: var(--text-muted);
    transition: all 0.2s;
    flex-shrink: 0;
}

.nav-item:hover .nav-link {
    background-color: var(--hover-bg);
    color: var(--primary-color) !important;
}

.nav-item:hover .nav-link i {
    color: var(--primary-color);
}

.nav-item.active .nav-link {
    background-color: var(--active-bg);
    color: var(--primary-color) !important;
    font-weight: 500;
}

.nav-item.active .nav-link i {
    color: var(--primary-color);
}

.nav-item.active::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 3px;
    background-color: var(--primary-color);
    border-radius: 0 3px 3px 0;
}

.nav-text {
    transition: all var(--transition-speed) ease;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.sidebar-collapsed .nav-text {
    opacity: 0;
    width: 0;
    display: none;
}

/* Footer del sidebar */
.sidebar-footer {
    padding: 1rem;
    border-top: 1px solid var(--border-color);
    background-color: #f8fafc;
    transition: all var(--transition-speed) ease;
}

.sidebar-footer-text {
    transition: all var(--transition-speed) ease;
    white-space: nowrap;
    overflow: hidden;
}

.sidebar-collapsed .sidebar-footer-text {
    opacity: 0;
    width: 0;
    display: none;
}

.avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background-color: #e2e8f0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    flex-shrink: 0;
}

/* Estilos para móvil */
@media (max-width: 991.98px) {
    .sidebar {
        transform: translateX(-100%);
        z-index: 1040;
        box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
    }
    
    .sidebar.show {
        transform: translateX(0);
    }
    
    .sidebar-collapsed {
        width: var(--sidebar-width);
    }
    
    .sidebar-collapsed .sidebar-logo-text,
    .sidebar-collapsed .nav-text,
    .sidebar-collapsed .nav-section-title,
    .sidebar-collapsed .sidebar-footer-text {
        opacity: 1;
        width: auto;
        display: block;
    }
    
    .sidebar-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.5);
        z-index: 1039;
        display: none;
    }
    
    .sidebar-overlay.show {
        display: block;
    }
}

/* Transiciones suaves */
.nav-item, .nav-link, .sidebar-toggle, .sidebar-logo {
    transition: all var(--transition-speed) ease;
}

/* Estilos para el enlace de cerrar sesión */
.text-danger {
    color: #e53e3e !important;
}

.text-danger:hover {
    color: #c53030 !important;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const body = document.body;
    let sidebarOverlay;
    
    // Crear overlay para móvil
    function createOverlay() {
        if (window.innerWidth <= 991.98) {
            if (!document.querySelector('.sidebar-overlay')) {
                sidebarOverlay = document.createElement('div');
                sidebarOverlay.className = 'sidebar-overlay';
                document.body.appendChild(sidebarOverlay);
                
                sidebarOverlay.addEventListener('click', function() {
                    closeSidebar();
                });
            }
        } else if (sidebarOverlay) {
            sidebarOverlay.remove();
            sidebarOverlay = null;
        }
    }
    
    // Abrir sidebar en móvil
    function openSidebar() {
        if (!sidebar) return;
        
        // Crear overlay si no existe
        if (window.innerWidth <= 991.98 && !document.querySelector('.sidebar-overlay')) {
            createOverlay();
        }
        
        sidebar.classList.add('show');
        if (sidebarOverlay) {
            sidebarOverlay.classList.add('show');
        }
        document.body.style.overflow = 'hidden';
    }
    
    // Cerrar sidebar en móvil
    function closeSidebar() {
        if (!sidebar) return;
        
        sidebar.classList.remove('show');
        if (sidebarOverlay) {
            sidebarOverlay.classList.remove('show');
        }
        document.body.style.overflow = '';
    }
    
    // Toggle sidebar en desktop
    function toggleSidebar() {
        if (!sidebar) return;
        
        if (window.innerWidth > 991.98) {
            sidebar.classList.toggle('sidebar-collapsed');
            const isCollapsed = sidebar.classList.contains('sidebar-collapsed');
            localStorage.setItem('sidebarCollapsed', isCollapsed);
        } else {
            if (sidebar.classList.contains('show')) {
                closeSidebar();
            } else {
                openSidebar();
            }
        }
    }
    
    // Verificar estado inicial
    function initSidebar() {
        if (!sidebar) return;
        
        // Verificar si estamos en móvil
        if (window.innerWidth <= 991.98) {
            sidebar.classList.remove('sidebar-collapsed');
            createOverlay();
        } else {
            // En desktop, verificar estado guardado
            const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
            if (isCollapsed) {
                sidebar.classList.add('sidebar-collapsed');
            } else {
                sidebar.classList.remove('sidebar-collapsed');
            }
            
            // Asegurarnos de que el overlay no esté presente en desktop
            const existingOverlay = document.querySelector('.sidebar-overlay');
            if (existingOverlay) {
                existingOverlay.remove();
            }
        }
        
        // Actualizar el ícono del botón de toggle
        updateToggleIcon();
    }
    
    // Actualizar el ícono del botón de toggle
    function updateToggleIcon() {
        if (!sidebarToggle) return;
        
        if (window.innerWidth <= 991.98) {
            // En móvil, siempre mostrar el ícono de menú
            sidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
        } else {
            // En desktop, alternar entre menú y cerrar
            const isCollapsed = sidebar.classList.contains('sidebar-collapsed');
            sidebarToggle.innerHTML = isCollapsed ? 
                '<i class="fas fa-chevron-right"></i>' : 
                '<i class="fas fa-chevron-left"></i>';
        }
    }
    
    // Inicializar sidebar
    initSidebar();
    
    // Event listeners
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleSidebar();
            updateToggleIcon();
        });
    }
    
    // Cerrar sidebar al hacer clic en un enlace en móvil
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 991.98) {
                closeSidebar();
            }
        });
    });
    
    // Manejar cambio de tamaño de ventana
    function handleResize() {
        if (window.innerWidth > 991.98) {
            // En desktop, asegurarse de que el overlay no esté presente
            if (sidebarOverlay) {
                sidebarOverlay.remove();
                sidebarOverlay = null;
            }
            // Asegurarse de que el sidebar esté visible en desktop
            sidebar.classList.remove('show');
            document.body.style.overflow = '';
        } else {
            // En móvil, asegurarse de que el sidebar esté cerrado inicialmente
            if (!sidebar.classList.contains('show')) {
                closeSidebar();
            }
        }
        
        // Actualizar el ícono del botón de toggle
        updateToggleIcon();
    }
    
    // Añadir event listener para el redimensionamiento
    window.addEventListener('resize', handleResize);
    
    // Manejar tecla Escape para cerrar el sidebar
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && window.innerWidth <= 991.98 && sidebar.classList.contains('show')) {
            closeSidebar();
        }
    });
    
    // Cerrar sidebar al hacer clic fuera en móvil
    document.addEventListener('click', function(e) {
        if (window.innerWidth <= 991.98 && 
            sidebar.classList.contains('show') && 
            !sidebar.contains(e.target) && 
            !e.target.matches('.sidebar-toggle, .sidebar-toggle *')) {
            closeSidebar();
        }
    });
    
    // Prevenir el cierre del sidebar al hacer clic dentro de él
    if (sidebar) {
        sidebar.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    }
});
</script>