<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/config/mercadopago_config.php';

http_response_code(200);
header('Content-Type: application/json');

// Manejar modo de prueba
if (isset($_POST['test_mode']) && $_POST['test_mode'] == '1') {
    $event = [
        'type' => $_POST['type'] ?? 'preapproval',
        'data' => [
            'id' => $_POST['data']['id'] ?? 'test_preapproval_123',
            'status' => $_POST['data']['status'] ?? 'authorized',
            'payer_email' => $_POST['data']['payer_email'] ?? 'test@example.com',
            'external_reference' => $_POST['data']['external_reference'] ?? 'MEM_1'
        ]
    ];
    $raw = json_encode($event);
} else {
    $raw = file_get_contents('php://input');
    $event = json_decode($raw, true);
}

try {
    $raw = file_get_contents('php://input');
    $event = json_decode($raw, true);

    // Log
    if (!is_dir(__DIR__ . '/logs')) {
        @mkdir(__DIR__ . '/logs', 0755, true);
    }
    @file_put_contents(__DIR__ . '/logs/mercadopago_webhook.log', date('c') . ' ' . $raw . PHP_EOL, FILE_APPEND);

    if (!$event || !is_array($event)) {
        echo json_encode(['received' => true]);
        exit;
    }

    $type = $event['type'] ?? ($event['action'] ?? '');
    $dataId = $event['data']['id'] ?? null;

    error_log('Webhook MP - Type: ' . $type . ', Data ID: ' . $dataId);

    // Manejar diferentes tipos de eventos de suscripción
    if (($type === 'preapproval' || $type === 'subscription_preapproval' || $type === 'subscription_authorized_payment') && $dataId) {
        mpInit();
        
        // Para subscription_authorized_payment, el dataId es el payment ID, no el preapproval ID
        if ($type === 'subscription_authorized_payment') {
            // Obtener información del pago autorizado
            $paymentClient = new \MercadoPago\Client\Payment\PaymentClient();
            $payment = $paymentClient->get($dataId);
            
            // Buscar la suscripción asociada a este pago
            $preapprovalId = $payment->preapproval_id ?? null;
            $status = 'authorized';
            $externalRef = $payment->external_reference ?? null;
            $payerEmail = $payment->payer->email ?? null;
            $nextPaymentDate = null; // Se calculará después
            $lastPaymentDate = $payment->date_approved ?? null;
            $planId = null; // Se buscará en la base de datos
            
            error_log('Webhook MP - Payment data: ' . json_encode([
                'payment_id' => $dataId,
                'preapproval_id' => $preapprovalId,
                'external_ref' => $externalRef,
                'payer_email' => $payerEmail,
                'last_payment_date' => $lastPaymentDate
            ]));
            
        } else {
            // Para preapproval y subscription_preapproval
            $client = new \MercadoPago\Client\PreApproval\PreApprovalClient();
            $pre = $client->get($dataId);
            $status = $pre->status ?? null;
            $externalRef = $pre->external_reference ?? null;
            $payerEmail = $pre->payer_email ?? null;
            $nextPaymentDate = $pre->next_payment_date ?? null;
            $lastPaymentDate = $pre->last_payment_date ?? null;
            $planId = $pre->preapproval_plan_id ?? null;
            
            error_log('Webhook MP - Preapproval data: ' . json_encode([
                'status' => $status,
                'external_ref' => $externalRef,
                'payer_email' => $payerEmail,
                'next_payment_date' => $nextPaymentDate,
                'last_payment_date' => $lastPaymentDate,
                'plan_id' => $planId
            ]));
        }

        error_log('Webhook MP - Preapproval data: ' . json_encode([
            'status' => $status,
            'external_ref' => $externalRef,
            'payer_email' => $payerEmail,
            'next_payment_date' => $nextPaymentDate,
            'last_payment_date' => $lastPaymentDate,
            'plan_id' => $planId
        ]));

        // Buscar membresía por external_reference, plan_id o preapproval_id
        $membresiaId = null;
        
        if ($externalRef && preg_match('/^MEM_(\d+)$/', $externalRef, $m)) {
            // Caso 1: External reference con formato MEM_{id}
            $membresiaId = (int)$m[1];
            error_log('Webhook MP - Found membresia by external_ref: ' . $membresiaId);
        } elseif ($type === 'subscription_authorized_payment' && $preapprovalId) {
            // Caso 2: Para pagos autorizados, buscar por preapproval_id
            $preapprovalStmt = $pdo->prepare("SELECT id FROM membresias WHERE mp_preapproval_id = ?");
            $preapprovalStmt->execute([$preapprovalId]);
            $membresiaResult = $preapprovalStmt->fetch(PDO::FETCH_ASSOC);
            if ($membresiaResult) {
                $membresiaId = (int)$membresiaResult['id'];
                error_log('Webhook MP - Found membresia by preapproval_id: ' . $membresiaId);
            }
        } elseif ($planId) {
            // Caso 3: Buscar por plan_id en membresías pendientes
            $planStmt = $pdo->prepare("SELECT id FROM membresias WHERE mp_plan_id = ? AND mp_status = 'pending' ORDER BY created_at DESC LIMIT 1");
            $planStmt->execute([$planId]);
            $membresiaResult = $planStmt->fetch(PDO::FETCH_ASSOC);
            if ($membresiaResult) {
                $membresiaId = (int)$membresiaResult['id'];
                error_log('Webhook MP - Found membresia by plan_id: ' . $membresiaId);
            }
        }

        if ($membresiaId) {
            // Verificar que la membresía existe
            $membresiaStmt = $pdo->prepare("SELECT m.*, c.correo, c.nombre, c.apellido_paterno FROM membresias m 
                                           LEFT JOIN clientes c ON m.cliente_id = c.id 
                                           WHERE m.id = ?");
            $membresiaStmt->execute([$membresiaId]);
            $membresia = $membresiaStmt->fetch(PDO::FETCH_ASSOC);

            if ($membresia) {
                // Verificar columnas disponibles
                $cols = $pdo->query("SHOW COLUMNS FROM membresias")->fetchAll(PDO::FETCH_COLUMN);
                $hasStatus = in_array('mp_status', $cols);
                $hasNextPayment = in_array('mp_next_payment_date', $cols);
                $hasLastPayment = in_array('mp_last_payment_date', $cols);
                $hasPaymentMethod = in_array('mp_payment_method', $cols);

                // Construir query de actualización
                $parts = [];
                $params = [];

                if ($hasStatus) { 
                    $parts[] = 'mp_status = ?'; 
                    $params[] = $status; 
                }
                
                // Guardar el preapproval_id cuando se confirma la suscripción
                $hasPreapprovalId = in_array('mp_preapproval_id', $cols);
                if ($hasPreapprovalId) {
                    $parts[] = 'mp_preapproval_id = ?';
                    // Para subscription_authorized_payment, usar el preapproval_id del pago
                    // Para otros eventos, usar el dataId directamente
                    $preapprovalIdToSave = ($type === 'subscription_authorized_payment') ? $preapprovalId : $dataId;
                    $params[] = $preapprovalIdToSave;
                }
                
                if ($hasNextPayment && $nextPaymentDate) { 
                    $parts[] = 'mp_next_payment_date = ?'; 
                    $params[] = $nextPaymentDate; 
                }
                
                if ($hasLastPayment && $lastPaymentDate) { 
                    $parts[] = 'mp_last_payment_date = ?'; 
                    $params[] = $lastPaymentDate; 
                }

                // Si el estado es 'authorized', actualizar el email del cliente si es diferente
                if ($status === 'authorized' && $payerEmail && $membresia['correo'] !== $payerEmail) {
                    $clienteStmt = $pdo->prepare("UPDATE clientes SET correo = ? WHERE id = ?");
                    $clienteStmt->execute([$payerEmail, $membresia['cliente_id']]);
                    error_log('Webhook MP - Updated client email from ' . $membresia['correo'] . ' to ' . $payerEmail);
                }

                // Si hay cambios que actualizar
                if ($parts) {
                    $sql = 'UPDATE membresias SET ' . implode(', ', $parts) . ' WHERE id = ?';
                    $params[] = $membresiaId;
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                    
                    error_log('Webhook MP - Updated membresia ' . $membresiaId . ' with status: ' . $status);
                }

                // Manejar cancelación con cargo por cancelación
                if ($status === 'cancelled') {
                    try {
                        // Obtener datos del tipo de membresía para verificar si hay cargo por cancelación
                        $tipoStmt = $pdo->prepare("SELECT tm.*, e.nombre as empresa_nombre 
                                                  FROM tipos_membresia tm 
                                                  LEFT JOIN empresas e ON tm.empresa_id = e.id 
                                                  WHERE tm.id = ?");
                        $tipoStmt->execute([$membresia['tipo_membresia_id']]);
                        $tipo = $tipoStmt->fetch(PDO::FETCH_ASSOC);

                        if ($tipo && $tipo['monto_cancelacion'] > 0) {
                            // Registrar cargo por cancelación en la base de datos
                            // Los pagos reales requieren tokens válidos del frontend
                            try {
                                // Actualizar la membresía con información del cargo
                                $updateCancellationSql = "UPDATE membresias SET 
                                    mp_cancellation_fee = ?, 
                                    mp_cancelled_at = NOW() 
                                    WHERE id = ?";
                                $cancellationStmt = $pdo->prepare($updateCancellationSql);
                                $cancellationStmt->execute([$tipo['monto_cancelacion'], $membresiaId]);
                                
                                error_log('Webhook MP - Cancellation fee registered: $' . $tipo['monto_cancelacion'] . ' for membresia ' . $membresiaId);
                                
                            } catch (Exception $updateError) {
                                error_log('Webhook MP - Error updating cancellation fee: ' . $updateError->getMessage());
                            }
                        }
                        
                        // Enviar email de cancelación (con o sin cargo)
                        if ($tipo) {
                            $clienteData = [
                                'nombre' => $membresia['nombre'],
                                'apellido_paterno' => $membresia['apellido_paterno'],
                                'correo' => $payerEmail ?: $membresia['correo']
                            ];

                            $empresaData = [
                                'nombre' => $tipo['empresa_nombre'] ?: 'Nuestra Empresa'
                            ];

                            $cancellationFee = ($tipo['monto_cancelacion'] > 0) ? $tipo['monto_cancelacion'] : 0;
                            sendCancellationEmail($clienteData, $tipo, $empresaData, $cancellationFee);
                            error_log('Webhook MP - Sent cancellation email to ' . $clienteData['correo'] . ' with fee: $' . $cancellationFee);
                        }
                        
                    } catch (Exception $e) {
                        error_log('Webhook MP - Error handling cancellation: ' . $e->getMessage());
                    }
                }

                // Enviar email de confirmación si la suscripción fue autorizada
                if ($status === 'authorized') {
                    try {
                        // Obtener datos del tipo de membresía y empresa
                        $tipoStmt = $pdo->prepare("SELECT tm.*, e.nombre as empresa_nombre 
                                                  FROM tipos_membresia tm 
                                                  LEFT JOIN empresas e ON tm.empresa_id = e.id 
                                                  WHERE tm.id = ?");
                        $tipoStmt->execute([$membresia['tipo_membresia_id']]);
                        $tipo = $tipoStmt->fetch(PDO::FETCH_ASSOC);

                        if ($tipo) {
                            $clienteData = [
                                'nombre' => $membresia['nombre'],
                                'apellido_paterno' => $membresia['apellido_paterno'],
                                'correo' => $payerEmail ?: $membresia['correo']
                            ];

                            $empresaData = [
                                'nombre' => $tipo['empresa_nombre'] ?: 'Nuestra Empresa'
                            ];

                            sendSubscriptionEmail($clienteData, $tipo, $empresaData);
                            error_log('Webhook MP - Sent subscription confirmation email to ' . $clienteData['correo']);
                        }
                    } catch (Exception $e) {
                        error_log('Webhook MP - Error sending email: ' . $e->getMessage());
                    }
                }
            } else {
                error_log('Webhook MP - Membresia not found: ' . $membresiaId);
            }
        } else {
            error_log('Webhook MP - No membresia found for external_ref: ' . $externalRef . ' or plan_id: ' . $planId);
        }
    }

    echo json_encode(['received' => true]);
    exit;
} catch (Throwable $e) {
    error_log('Webhook MP error: ' . $e->getMessage());
    echo json_encode(['received' => true]);
    exit;
}

