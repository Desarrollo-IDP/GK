<?php
/**
 * Procesador de Webhooks Pendientes
 * 
 * Este script procesa manualmente los webhooks que ya llegaron
 * pero no se procesaron correctamente debido a problemas en el código
 */

require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'config/mercadopago_config.php';

initConfig();

echo "<h1>🔄 Procesador de Webhooks Pendientes</h1>\n";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { background-color: #d4edda; border-color: #c3e6cb; color: #155724; }
    .error { background-color: #f8d7da; border-color: #f5c6cb; color: #721c24; }
    .info { background-color: #d1ecf1; border-color: #bee5eb; color: #0c5460; }
    .warning { background-color: #fff3cd; border-color: #ffeaa7; color: #856404; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
    .step { font-weight: bold; margin-bottom: 10px; }
    .btn { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
    .btn:hover { background: #0056b3; }
</style>\n";

function showResult($title, $success, $message, $data = null) {
    $class = $success ? 'success' : 'error';
    echo "<div class='test-section $class'>\n";
    echo "<div class='step'>$title</div>\n";
    echo "<p>$message</p>\n";
    if ($data) {
        echo "<pre>" . print_r($data, true) . "</pre>\n";
    }
    echo "</div>\n";
}

function showInfo($title, $message, $data = null) {
    echo "<div class='test-section info'>\n";
    echo "<div class='step'>$title</div>\n";
    echo "<p>$message</p>\n";
    if ($data) {
        echo "<pre>" . print_r($data, true) . "</pre>\n";
    }
    echo "</div>\n";
}

// Procesar webhooks pendientes
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_webhooks'])) {
    echo "<h2>🔄 Procesando Webhooks Pendientes</h2>\n";
    
    // Webhooks que llegaron pero no se procesaron correctamente
    $pendingWebhooks = [
        [
            'type' => 'subscription_preapproval',
            'data_id' => '531b6c90b09f470f8430163666e4ad8b',
            'timestamp' => '2025-08-12T20:51:33Z'
        ],
        [
            'type' => 'subscription_authorized_payment',
            'data_id' => '7020886531',
            'timestamp' => '2025-08-12T20:53:06Z'
        ]
    ];
    
    $processed = 0;
    $errors = 0;
    
    foreach ($pendingWebhooks as $webhook) {
        try {
            echo "<div class='test-section info'>\n";
            echo "<div class='step'>Procesando: " . $webhook['type'] . " - " . $webhook['data_id'] . "</div>\n";
            
            // Simular el procesamiento del webhook
            $event = [
                'type' => $webhook['type'],
                'data' => [
                    'id' => $webhook['data_id']
                ]
            ];
            
            // Procesar según el tipo
            if ($webhook['type'] === 'subscription_preapproval') {
                // Buscar membresía pendiente más reciente
                $membresiaStmt = $pdo->prepare("
                    SELECT id FROM membresias 
                    WHERE mp_status = 'pending' AND mp_plan_id IS NOT NULL 
                    ORDER BY created_at DESC LIMIT 1
                ");
                $membresiaStmt->execute();
                $membresia = $membresiaStmt->fetch(PDO::FETCH_ASSOC);
                
                if ($membresia) {
                    // Actualizar con el preapproval_id
                    $updateSql = "UPDATE membresias SET 
                                 mp_preapproval_id = ?, 
                                 mp_status = 'authorized',
                                 mp_payment_method = 'credit_card',
                                 mp_last_payment_date = NOW(),
                                 mp_next_payment_date = DATE_ADD(NOW(), INTERVAL 1 MONTH)
                                 WHERE id = ?";
                    
                    $stmt = $pdo->prepare($updateSql);
                    $stmt->execute([$webhook['data_id'], $membresia['id']]);
                    
                    showResult("✅ Procesado", true, "Membresía " . $membresia['id'] . " actualizada con preapproval_id: " . $webhook['data_id']);
                    $processed++;
                } else {
                    showResult("❌ No se encontró membresía", false, "No hay membresías pendientes para procesar");
                    $errors++;
                }
                
            } elseif ($webhook['type'] === 'subscription_authorized_payment') {
                // Buscar membresía por preapproval_id
                $membresiaStmt = $pdo->prepare("
                    SELECT id FROM membresias 
                    WHERE mp_preapproval_id IS NOT NULL 
                    ORDER BY created_at DESC LIMIT 1
                ");
                $membresiaStmt->execute();
                $membresia = $membresiaStmt->fetch(PDO::FETCH_ASSOC);
                
                if ($membresia) {
                    // Actualizar con información del pago
                    $updateSql = "UPDATE membresias SET 
                                 mp_status = 'authorized',
                                 mp_payment_method = 'credit_card',
                                 mp_last_payment_date = NOW(),
                                 mp_next_payment_date = DATE_ADD(NOW(), INTERVAL 1 MONTH)
                                 WHERE id = ?";
                    
                    $stmt = $pdo->prepare($updateSql);
                    $stmt->execute([$membresia['id']]);
                    
                    showResult("✅ Procesado", true, "Membresía " . $membresia['id'] . " actualizada con pago autorizado");
                    $processed++;
                } else {
                    showResult("❌ No se encontró membresía", false, "No hay membresías con preapproval_id para procesar");
                    $errors++;
                }
            }
            
            echo "</div>\n";
            
        } catch (Exception $e) {
            showResult("❌ Error al procesar", false, "Error: " . $e->getMessage());
            $errors++;
        }
    }
    
    // Resumen
    echo "<div class='test-section " . ($errors == 0 ? 'success' : 'warning') . "'>\n";
    echo "<div class='step'>📊 Resumen del Procesamiento</div>\n";
    echo "<p><strong>Procesados:</strong> $processed</p>\n";
    echo "<p><strong>Errores:</strong> $errors</p>\n";
    echo "</div>\n";
}

// Mostrar webhooks pendientes
echo "<h2>📋 Webhooks Pendientes de Procesamiento</h2>\n";

$logFile = __DIR__ . '/logs/mercadopago_webhook.log';

if (file_exists($logFile)) {
    $logContent = file_get_contents($logFile);
    $logLines = explode(PHP_EOL, $logContent);
    
    // Buscar webhooks que contienen JSON (webhooks reales)
    $realWebhooks = [];
    foreach ($logLines as $line) {
        if (strpos($line, '{') !== false && strpos($line, '}') !== false) {
            $jsonData = json_decode($line, true);
            if ($jsonData && isset($jsonData['type'])) {
                $realWebhooks[] = [
                    'type' => $jsonData['type'],
                    'data_id' => $jsonData['data']['id'] ?? 'N/A',
                    'timestamp' => $jsonData['date'] ?? $jsonData['date_created'] ?? 'N/A',
                    'raw' => $line
                ];
            }
        }
    }
    
    if (empty($realWebhooks)) {
        showResult("✅ No hay webhooks pendientes", true, "Todos los webhooks han sido procesados");
    } else {
        showInfo("Webhooks encontrados", "Se encontraron " . count($realWebhooks) . " webhooks reales");
        
        foreach ($realWebhooks as $webhook) {
            echo "<div class='test-section info'>\n";
            echo "<div class='step'>" . $webhook['type'] . "</div>\n";
            echo "<p><strong>ID:</strong> " . $webhook['data_id'] . "</p>\n";
            echo "<p><strong>Timestamp:</strong> " . $webhook['timestamp'] . "</p>\n";
            echo "</div>\n";
        }
        
        // Formulario para procesar
        echo "<div class='test-section info'>\n";
        echo "<div class='step'>🔄 Procesar Webhooks</div>\n";
        echo "<form method='POST'>\n";
        echo "<button type='submit' name='process_webhooks' class='btn'>Procesar Webhooks Pendientes</button>\n";
        echo "</form>\n";
        echo "</div>\n";
    }
} else {
    showResult("❌ Log no encontrado", false, "No se puede acceder al archivo de log");
}

// Verificar estado actual
echo "<h2>📊 Estado Actual de Membresías</h2>\n";

try {
    $membresias = $pdo->query("
        SELECT m.*, c.nombre as cliente_nombre, c.apellido_paterno, t.nombre as tipo_nombre
        FROM membresias m 
        JOIN clientes c ON m.cliente_id = c.id 
        JOIN tipos_membresia t ON m.tipo_membresia_id = t.id 
        WHERE m.metodo_pago = 'mercadopago'
        ORDER BY m.created_at DESC
        LIMIT 10
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($membresias)) {
        showResult("❌ No hay membresías", false, "No se encontraron membresías");
    } else {
        showInfo("Membresías encontradas", "Estado actual de las membresías:");
        
        foreach ($membresias as $membresia) {
            $statusClass = $membresia['mp_status'] === 'authorized' ? 'success' : 'warning';
            echo "<div class='test-section $statusClass'>\n";
            echo "<div class='step'>Membresía ID: " . $membresia['id'] . "</div>\n";
            echo "<p><strong>Cliente:</strong> " . $membresia['cliente_nombre'] . " " . $membresia['apellido_paterno'] . "</p>\n";
            echo "<p><strong>Tipo:</strong> " . $membresia['tipo_nombre'] . "</p>\n";
            echo "<p><strong>Estado:</strong> " . $membresia['mp_status'] . "</p>\n";
            echo "<p><strong>PreApproval ID:</strong> " . ($membresia['mp_preapproval_id'] ?: 'No asignado') . "</p>\n";
            echo "<p><strong>Plan ID:</strong> " . ($membresia['mp_plan_id'] ?: 'No asignado') . "</p>\n";
            echo "</div>\n";
        }
    }
} catch (Exception $e) {
    showResult("❌ Error al consultar membresías", false, "Error: " . $e->getMessage());
}

echo "<p><em>Procesamiento completado el " . date('Y-m-d H:i:s') . "</em></p>\n";
?>
