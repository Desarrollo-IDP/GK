<?php
/**
 * Script de prueba para el sistema de cancelación de suscripciones
 * Este script permite probar manualmente la funcionalidad de cancelación
 */

require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'config/mercadopago_config.php';

initConfig();

echo "<h1>🧪 Prueba del Sistema de Cancelación</h1>\n";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { background-color: #d4edda; border-color: #c3e6cb; color: #155724; }
    .error { background-color: #f8d7da; border-color: #f5c6cb; color: #721c24; }
    .info { background-color: #d1ecf1; border-color: #bee5eb; color: #0c5460; }
    .warning { background-color: #fff3cd; border-color: #ffeaa7; color: #856404; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
    .step { font-weight: bold; margin-bottom: 10px; }
    .form-group { margin: 10px 0; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
    .form-group input, .form-group select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
    .btn { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
    .btn:hover { background: #0056b3; }
    .btn-danger { background: #dc3545; }
    .btn-danger:hover { background: #c82333; }
</style>\n";

function showResult($title, $success, $message, $data = null) {
    $class = $success ? 'success' : 'error';
    echo "<div class='test-section $class'>\n";
    echo "<div class='step'>$title</div>\n";
    echo "<p>$message</p>\n";
    if ($data) {
        echo "<pre>" . print_r($data, true) . "</pre>\n";
    }
    echo "</div>\n";
}

function showInfo($title, $message, $data = null) {
    echo "<div class='test-section info'>\n";
    echo "<div class='step'>$title</div>\n";
    echo "<p>$message</p>\n";
    if ($data) {
        echo "<pre>" . print_r($data, true) . "</pre>\n";
    }
    echo "</div>\n";
}

// Procesar prueba de cancelación
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_cancelacion'])) {
    $membresiaId = (int)$_POST['membresia_id'];
    $preapprovalId = $_POST['preapproval_id'];
    $cancellationFee = floatval($_POST['cancellation_fee']);
    $payerEmail = $_POST['payer_email'];
    
    try {
        // Verificar que la membresía existe
        $membresiaStmt = $pdo->prepare("SELECT m.*, c.correo, c.nombre, c.apellido_paterno, tm.nombre as tipo_nombre, tm.monto_cancelacion
                                       FROM membresias m 
                                       LEFT JOIN clientes c ON m.cliente_id = c.id 
                                       LEFT JOIN tipos_membresia tm ON m.tipo_membresia_id = tm.id
                                       WHERE m.id = ?");
        $membresiaStmt->execute([$membresiaId]);
        $membresia = $membresiaStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$membresia) {
            showResult("❌ Error", false, "Membresía no encontrada");
        } else {
            showInfo("📋 Información de la Membresía", "Datos de la membresía a cancelar", $membresia);
            
                         // Probar cancelación con cargo
             if ($cancellationFee > 0) {
                 showInfo("💰 Probando Cargo por Cancelación", "Aplicando cargo de $" . number_format($cancellationFee, 2) . " MXN");
                 
                 // Nota: Los pagos reales requieren un token válido del frontend
                 // Para pruebas, solo registramos el cargo en la base de datos
                 showInfo("📝 Registrando Cargo", "El cargo por cancelación se registrará en la base de datos. Para crear pagos reales se requiere un token válido de MercadoPago.");
             }
            
                         // Probar cancelación de suscripción
             if ($preapprovalId) {
                 showInfo("🔄 Probando Cancelación de Suscripción", "Cancelando suscripción en MercadoPago");
                 
                 try {
                     $result = mpCancelSubscription($preapprovalId, $cancellationFee, $payerEmail ?: $membresia['correo']);
                     
                     if ($result['success']) {
                         showResult("✅ Suscripción Cancelada", true, $result['message'], $result);
                         
                         // Actualizar estado en la base de datos
                         $updateSql = "UPDATE membresias SET 
                                      mp_status = 'cancelled',
                                      mp_cancellation_fee = ?,
                                      mp_cancelled_at = NOW()
                                      WHERE id = ?";
                         $stmt = $pdo->prepare($updateSql);
                         $stmt->execute([$cancellationFee, $membresiaId]);
                         
                         showResult("✅ Base de Datos Actualizada", true, "Estado de membresía actualizado a 'cancelled' con cargo registrado: $" . number_format($cancellationFee, 2) . " MXN");
                         
                     } else {
                         showResult("❌ Error en Cancelación", false, "Error al cancelar suscripción: " . ($result['error'] ?? 'Error desconocido'));
                     }
                     
                 } catch (Exception $cancelError) {
                     showResult("❌ Error en Cancelación", false, "Error al cancelar suscripción: " . $cancelError->getMessage());
                 }
             }
        }
    } catch (Exception $e) {
        showResult("❌ Error General", false, "Error: " . $e->getMessage());
    }
}

// Mostrar membresías disponibles
echo "<h2>📋 Membresías Disponibles para Prueba</h2>\n";

try {
    // Verificar si la columna monto_cancelacion existe
    $columns = $pdo->query("SHOW COLUMNS FROM tipos_membresia")->fetchAll(PDO::FETCH_COLUMN);
    $hasCancelacion = in_array('monto_cancelacion', $columns);
    
    if (!$hasCancelacion) {
        showResult("❌ Columna faltante", false, "La columna 'monto_cancelacion' no existe en la tabla tipos_membresia. Ejecuta el script sql/agregar_monto_cancelacion.sql primero.");
        return;
    }
    
    $membresias = $pdo->query("
        SELECT m.*, c.nombre as cliente_nombre, c.apellido_paterno, c.correo, tm.nombre as tipo_nombre, tm.monto_cancelacion
        FROM membresias m 
        JOIN clientes c ON m.cliente_id = c.id 
        JOIN tipos_membresia tm ON m.tipo_membresia_id = tm.id 
        WHERE m.mp_status = 'authorized' AND m.mp_preapproval_id IS NOT NULL
        ORDER BY m.created_at DESC
        LIMIT 10
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($membresias)) {
        showResult("⚠️ No hay membresías disponibles", false, "No se encontraron membresías activas con preapproval_id");
    } else {
        showInfo("Membresías activas", "Se encontraron " . count($membresias) . " membresías activas para prueba");
        
        foreach ($membresias as $membresia) {
            echo "<div class='test-section info'>\n";
            echo "<div class='step'>Membresía ID: " . $membresia['id'] . "</div>\n";
            echo "<p><strong>Cliente:</strong> " . $membresia['cliente_nombre'] . " " . $membresia['apellido_paterno'] . "</p>\n";
            echo "<p><strong>Email:</strong> " . $membresia['correo'] . "</p>\n";
            echo "<p><strong>Tipo:</strong> " . $membresia['tipo_nombre'] . "</p>\n";
            echo "<p><strong>PreApproval ID:</strong> " . $membresia['mp_preapproval_id'] . "</p>\n";
            echo "<p><strong>Cargo por Cancelación:</strong> $" . number_format($membresia['monto_cancelacion'], 2) . " MXN</p>\n";
            
            // Formulario para probar esta membresía
            echo "<form method='POST' style='margin-top: 10px;'>\n";
            echo "<input type='hidden' name='membresia_id' value='" . $membresia['id'] . "'>\n";
            echo "<input type='hidden' name='preapproval_id' value='" . $membresia['mp_preapproval_id'] . "'>\n";
            echo "<div class='form-group'>\n";
            echo "<label>Cargo por Cancelación (MXN):</label>\n";
            echo "<input type='number' name='cancellation_fee' value='" . $membresia['monto_cancelacion'] . "' step='0.01' min='0'>\n";
            echo "</div>\n";
            echo "<div class='form-group'>\n";
            echo "<label>Email del Cliente:</label>\n";
            echo "<input type='email' name='payer_email' value='" . $membresia['correo'] . "'>\n";
            echo "</div>\n";
            echo "<button type='submit' name='test_cancelacion' class='btn btn-danger'>Probar Cancelación</button>\n";
            echo "</form>\n";
            echo "</div>\n";
        }
    }
} catch (Exception $e) {
    showResult("❌ Error al consultar membresías", false, "Error: " . $e->getMessage());
}

// Instrucciones
echo "<h2>📖 Instrucciones de Prueba</h2>\n";

echo "<div class='test-section info'>\n";
echo "<div class='step'>🔧 Cómo usar este script de prueba</div>\n";
echo "<ol>\n";
echo "<li><strong>Selecciona una membresía:</strong> Elige una membresía activa de la lista</li>\n";
echo "<li><strong>Configura el cargo:</strong> Establece el monto de cargo por cancelación (0 = sin cargo)</li>\n";
echo "<li><strong>Verifica el email:</strong> Confirma que el email del cliente sea correcto</li>\n";
echo "<li><strong>Ejecuta la prueba:</strong> Haz clic en 'Probar Cancelación'</li>\n";
echo "<li><strong>Revisa los resultados:</strong> Verifica los logs y resultados de cada paso</li>\n";
echo "</ol>\n";
echo "</div>\n";

echo "<div class='test-section warning'>\n";
echo "<div class='step'>⚠️ Importante</div>\n";
echo "<p>Este script es solo para pruebas. Las cancelaciones reales deben hacerse desde la interfaz administrativa.</p>\n";
echo "<p><strong>Nota:</strong> Los cargos por cancelación se registran en la base de datos pero NO se procesan automáticamente.</p>\n";
echo "<p>Para procesar pagos reales se requiere un token válido de MercadoPago desde el frontend.</p>\n";
echo "</div>\n";

echo "<p><em>Script de prueba completado el " . date('Y-m-d H:i:s') . "</em></p>\n";
?>
