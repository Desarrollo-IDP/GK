<?php
/**
 * Script para actualizar la base de datos y agregar la columna monto_cancelacion
 * Este script debe ejecutarse una sola vez para habilitar la funcionalidad de cargos por cancelación
 */

require_once 'includes/db.php';
require_once 'includes/config.php';

initConfig();

echo "<h1>🔧 Actualización de Base de Datos - Cargos por Cancelación</h1>\n";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { background-color: #d4edda; border-color: #c3e6cb; color: #155724; }
    .error { background-color: #f8d7da; border-color: #f5c6cb; color: #721c24; }
    .info { background-color: #d1ecf1; border-color: #bee5eb; color: #0c5460; }
    .warning { background-color: #fff3cd; border-color: #ffeaa7; color: #856404; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
    .step { font-weight: bold; margin-bottom: 10px; }
    table { width: 100%; border-collapse: collapse; margin: 10px 0; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
</style>\n";

function showSection($title, $type = 'info', $content = '') {
    echo "<div class='section $type'>\n";
    echo "<div class='step'>$title</div>\n";
    if ($content) {
        echo $content;
    }
    echo "</div>\n";
}

// 1. Verificar estado actual
echo "<h2>1. 🔍 Verificación del Estado Actual</h2>\n";

try {
    // Verificar si la columna ya existe
    $columns = $pdo->query("SHOW COLUMNS FROM tipos_membresia")->fetchAll(PDO::FETCH_COLUMN);
    $hasCancelacion = in_array('monto_cancelacion', $columns);
    
    if ($hasCancelacion) {
        showSection("✅ Columna ya existe", "success", 
            "<p>La columna 'monto_cancelacion' ya existe en la tabla tipos_membresia.</p>"
        );
        
        // Mostrar datos actuales
        $tipos = $pdo->query("SELECT id, nombre, precio, monto_cancelacion FROM tipos_membresia")->fetchAll(PDO::FETCH_ASSOC);
        if (!empty($tipos)) {
            $content = "<table><thead><tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Cargo Cancelación</th></tr></thead><tbody>";
            foreach ($tipos as $tipo) {
                $content .= "<tr>";
                $content .= "<td>" . $tipo['id'] . "</td>";
                $content .= "<td>" . $tipo['nombre'] . "</td>";
                $content .= "<td>$" . number_format($tipo['precio'], 2) . "</td>";
                $content .= "<td>$" . number_format($tipo['monto_cancelacion'], 2) . "</td>";
                $content .= "</tr>";
            }
            $content .= "</tbody></table>";
            showSection("📊 Tipos de membresía actuales", "info", $content);
        }
        
        echo "<p><strong>✅ No se requiere actualización. El sistema ya está listo para usar cargos por cancelación.</strong></p>\n";
        return;
        
    } else {
        showSection("⚠️ Columna faltante", "warning", 
            "<p>La columna 'monto_cancelacion' no existe en la tabla tipos_membresia.</p>" .
            "<p>Se procederá a agregarla...</p>"
        );
    }
    
} catch (Exception $e) {
    showSection("❌ Error al verificar", "error", 
        "<p>Error: " . $e->getMessage() . "</p>"
    );
    return;
}

// 2. Agregar la columna
echo "<h2>2. 🔧 Agregando Columna</h2>\n";

try {
    $sql = "ALTER TABLE tipos_membresia ADD COLUMN monto_cancelacion DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Monto de cargo por cancelación de suscripción'";
    $pdo->exec($sql);
    
    showSection("✅ Columna agregada", "success", 
        "<p>La columna 'monto_cancelacion' se agregó exitosamente a la tabla tipos_membresia.</p>"
    );
    
} catch (Exception $e) {
    showSection("❌ Error al agregar columna", "error", 
        "<p>Error: " . $e->getMessage() . "</p>"
    );
    return;
}

// 3. Verificar la nueva estructura
echo "<h2>3. 🔍 Verificación de la Nueva Estructura</h2>\n";

try {
    $columns = $pdo->query("SHOW COLUMNS FROM tipos_membresia")->fetchAll(PDO::FETCH_COLUMN);
    $hasCancelacion = in_array('monto_cancelacion', $columns);
    
    if ($hasCancelacion) {
        showSection("✅ Verificación exitosa", "success", 
            "<p>La columna 'monto_cancelacion' está presente y lista para usar.</p>"
        );
        
        // Mostrar la nueva estructura
        $structure = $pdo->query("DESCRIBE tipos_membresia")->fetchAll(PDO::FETCH_ASSOC);
        $content = "<table><thead><tr><th>Campo</th><th>Tipo</th><th>Nulo</th><th>Llave</th><th>Por Defecto</th><th>Extra</th></tr></thead><tbody>";
        foreach ($structure as $col) {
            $content .= "<tr>";
            $content .= "<td>" . $col['Field'] . "</td>";
            $content .= "<td>" . $col['Type'] . "</td>";
            $content .= "<td>" . $col['Null'] . "</td>";
            $content .= "<td>" . $col['Key'] . "</td>";
            $content .= "<td>" . $col['Default'] . "</td>";
            $content .= "<td>" . $col['Extra'] . "</td>";
            $content .= "</tr>";
        }
        $content .= "</tbody></table>";
        showSection("📋 Estructura actualizada", "info", $content);
        
    } else {
        showSection("❌ Error en verificación", "error", 
            "<p>La columna no se agregó correctamente.</p>"
        );
        return;
    }
    
} catch (Exception $e) {
    showSection("❌ Error al verificar estructura", "error", 
        "<p>Error: " . $e->getMessage() . "</p>"
    );
    return;
}

// 4. Mostrar tipos de membresía con el nuevo campo
echo "<h2>4. 📊 Tipos de Membresía Actualizados</h2>\n";

try {
    $tipos = $pdo->query("SELECT id, nombre, precio, monto_cancelacion FROM tipos_membresia")->fetchAll(PDO::FETCH_ASSOC);
    
    if (!empty($tipos)) {
        $content = "<table><thead><tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Cargo Cancelación</th></tr></thead><tbody>";
        foreach ($tipos as $tipo) {
            $content .= "<tr>";
            $content .= "<td>" . $tipo['id'] . "</td>";
            $content .= "<td>" . $tipo['nombre'] . "</td>";
            $content .= "<td>$" . number_format($tipo['precio'], 2) . "</td>";
            $content .= "<td>$" . number_format($tipo['monto_cancelacion'], 2) . "</td>";
            $content .= "</tr>";
        }
        $content .= "</tbody></table>";
        showSection("📋 Tipos de membresía", "info", $content);
        
        showSection("💡 Próximos pasos", "info", 
            "<p><strong>Para configurar cargos por cancelación:</strong></p>" .
            "<ol>" .
            "<li>Ve a <strong>Tipos de Membresía > Editar</strong></li>" .
            "<li>En el campo 'Monto por Cancelación' ingresa el valor deseado</li>" .
            "<li>Guarda los cambios</li>" .
            "<li>Prueba la funcionalidad con <strong>test_cancelacion.php</strong></li>" .
            "</ol>"
        );
        
    } else {
        showSection("⚠️ No hay tipos de membresía", "warning", 
            "<p>No se encontraron tipos de membresía en la base de datos.</p>"
        );
    }
    
} catch (Exception $e) {
    showSection("❌ Error al consultar tipos", "error", 
        "<p>Error: " . $e->getMessage() . "</p>"
    );
}

// 5. Resumen final
echo "<h2>5. ✅ Resumen de la Actualización</h2>\n";

showSection("🎉 Actualización completada", "success", 
    "<p><strong>La base de datos se actualizó exitosamente.</strong></p>" .
    "<p>Ahora puedes:</p>" .
    "<ul>" .
    "<li>✅ Configurar cargos por cancelación en los tipos de membresía</li>" .
    "<li>✅ Probar la funcionalidad con test_cancelacion.php</li>" .
    "<li>✅ Usar la interfaz de cancelación en el panel administrativo</li>" .
    "<li>✅ Recibir webhooks de cancelación con cargos automáticos</li>" .
    "</ul>"
);

echo "<p><em>Actualización completada el " . date('Y-m-d H:i:s') . "</em></p>\n";
?>
