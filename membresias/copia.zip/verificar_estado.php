<?php
/**
 * Script para verificar el estado actual del sistema de cancelación
 */

require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'config/mercadopago_config.php';

initConfig();

echo "<h1>🔍 Verificación del Estado del Sistema</h1>\n";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { background-color: #d4edda; border-color: #c3e6cb; color: #155724; }
    .error { background-color: #f8d7da; border-color: #f5c6cb; color: #721c24; }
    .info { background-color: #d1ecf1; border-color: #bee5eb; color: #0c5460; }
    .warning { background-color: #fff3cd; border-color: #ffeaa7; color: #856404; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
    .step { font-weight: bold; margin-bottom: 10px; }
    table { width: 100%; border-collapse: collapse; margin: 10px 0; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
</style>\n";

function showSection($title, $type = 'info', $content = '') {
    echo "<div class='section $type'>\n";
    echo "<div class='step'>$title</div>\n";
    if ($content) {
        echo $content;
    }
    echo "</div>\n";
}

// 1. Verificar configuración de MercadoPago
echo "<h2>1. 🔧 Configuración de MercadoPago</h2>\n";

try {
    $result = mpVerifyCredentials();
    if ($result['success']) {
        showSection("✅ Credenciales de MercadoPago", "success", 
            "<p>Las credenciales de MercadoPago son válidas.</p>" .
            "<pre>" . print_r($result, true) . "</pre>"
        );
    } else {
        showSection("❌ Error en Credenciales", "error", 
            "<p>Error en las credenciales de MercadoPago:</p>" .
            "<pre>" . print_r($result, true) . "</pre>"
        );
    }
} catch (Exception $e) {
    showSection("❌ Error al verificar credenciales", "error", 
        "<p>Error: " . $e->getMessage() . "</p>"
    );
}

// 2. Verificar estructura de la base de datos
echo "<h2>2. 🗄️ Estructura de la Base de Datos</h2>\n";

try {
    // Verificar columnas de la tabla membresias
    $columns = $pdo->query("SHOW COLUMNS FROM membresias")->fetchAll(PDO::FETCH_COLUMN);
    $requiredColumns = ['mp_status', 'mp_preapproval_id', 'mp_cancellation_fee', 'mp_cancelled_at'];
    $missingColumns = array_diff($requiredColumns, $columns);
    
    if (empty($missingColumns)) {
        showSection("✅ Estructura de membresias", "success", 
            "<p>Todas las columnas requeridas están presentes.</p>"
        );
    } else {
        showSection("⚠️ Columnas faltantes en membresias", "warning", 
            "<p>Faltan las siguientes columnas:</p><ul>" .
            implode('', array_map(function($col) { return "<li>$col</li>"; }, $missingColumns)) .
            "</ul>"
        );
    }
    
    // Verificar columnas de la tabla tipos_membresia
    $columns = $pdo->query("SHOW COLUMNS FROM tipos_membresia")->fetchAll(PDO::FETCH_COLUMN);
    if (in_array('monto_cancelacion', $columns)) {
        showSection("✅ Estructura de tipos_membresia", "success", 
            "<p>La columna monto_cancelacion está presente.</p>"
        );
    } else {
        showSection("❌ Columna faltante en tipos_membresia", "error", 
            "<p>La columna monto_cancelacion no existe. Ejecuta el script sql/agregar_monto_cancelacion.sql para agregarla.</p>" .
            "<p><strong>Comando SQL:</strong> ALTER TABLE tipos_membresia ADD COLUMN monto_cancelacion DECIMAL(10,2) DEFAULT 0.00;</p>"
        );
    }
    
} catch (Exception $e) {
    showSection("❌ Error al verificar estructura", "error", 
        "<p>Error: " . $e->getMessage() . "</p>"
    );
}

// 3. Verificar membresías activas
echo "<h2>3. 📋 Membresías Activas</h2>\n";

try {
    $membresias = $pdo->query("
        SELECT m.id, m.mp_status, m.mp_preapproval_id, m.mp_cancellation_fee, m.mp_cancelled_at,
               c.nombre, c.apellido_paterno, c.correo,
               tm.nombre as tipo_nombre, tm.monto_cancelacion
        FROM membresias m
        LEFT JOIN clientes c ON m.cliente_id = c.id
        LEFT JOIN tipos_membresia tm ON m.tipo_membresia_id = tm.id
        WHERE m.mp_status IS NOT NULL
        ORDER BY m.id DESC
        LIMIT 10
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($membresias)) {
        showSection("⚠️ No hay membresías", "warning", 
            "<p>No se encontraron membresías con estado de MercadoPago.</p>"
        );
    } else {
        $content = "<table><thead><tr><th>ID</th><th>Cliente</th><th>Estado MP</th><th>PreApproval ID</th><th>Tipo</th><th>Cargo Config</th><th>Cargo Aplicado</th></tr></thead><tbody>";
        
        foreach ($membresias as $m) {
            $content .= "<tr>";
            $content .= "<td>" . $m['id'] . "</td>";
            $content .= "<td>" . ($m['nombre'] ?? 'N/A') . " " . ($m['apellido_paterno'] ?? '') . "</td>";
            $content .= "<td>" . ($m['mp_status'] ?? 'N/A') . "</td>";
            $content .= "<td>" . ($m['mp_preapproval_id'] ?? 'N/A') . "</td>";
            $content .= "<td>" . ($m['tipo_nombre'] ?? 'N/A') . "</td>";
            $content .= "<td>$" . number_format($m['monto_cancelacion'] ?? 0, 2) . "</td>";
            $content .= "<td>$" . number_format($m['mp_cancellation_fee'] ?? 0, 2) . "</td>";
            $content .= "</tr>";
        }
        
        $content .= "</tbody></table>";
        
        showSection("📊 Membresías encontradas", "info", $content);
    }
    
} catch (Exception $e) {
    showSection("❌ Error al consultar membresías", "error", 
        "<p>Error: " . $e->getMessage() . "</p>"
    );
}

// 4. Verificar tipos de membresía con cargo por cancelación
echo "<h2>4. 💰 Tipos de Membresía con Cargo por Cancelación</h2>\n";

try {
    $tipos = $pdo->query("
        SELECT id, nombre, precio, monto_cancelacion
        FROM tipos_membresia
        WHERE monto_cancelacion > 0
        ORDER BY monto_cancelacion DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($tipos)) {
        showSection("⚠️ No hay tipos con cargo", "warning", 
            "<p>No se encontraron tipos de membresía con cargo por cancelación configurado.</p>"
        );
    } else {
        $content = "<table><thead><tr><th>ID</th><th>Nombre</th><th>Precio</th><th>Cargo Cancelación</th></tr></thead><tbody>";
        
        foreach ($tipos as $tipo) {
            $content .= "<tr>";
            $content .= "<td>" . $tipo['id'] . "</td>";
            $content .= "<td>" . $tipo['nombre'] . "</td>";
            $content .= "<td>$" . number_format($tipo['precio'], 2) . "</td>";
            $content .= "<td>$" . number_format($tipo['monto_cancelacion'], 2) . "</td>";
            $content .= "</tr>";
        }
        
        $content .= "</tbody></table>";
        
        showSection("💰 Tipos con cargo por cancelación", "info", $content);
    }
    
} catch (Exception $e) {
    showSection("❌ Error al consultar tipos", "error", 
        "<p>Error: " . $e->getMessage() . "</p>"
    );
}

// 5. Verificar logs recientes
echo "<h2>5. 📝 Logs Recientes</h2>\n";

$logFile = __DIR__ . '/logs/error.log';
if (file_exists($logFile)) {
    $logs = file_get_contents($logFile);
    $lines = explode("\n", $logs);
    $recentLogs = array_slice($lines, -20); // Últimas 20 líneas
    
    $content = "<h4>Últimas 20 líneas del error.log:</h4><pre>";
    foreach ($recentLogs as $line) {
        if (strpos($line, 'Webhook MP') !== false || strpos($line, 'MP ') !== false) {
            $content .= htmlspecialchars($line) . "\n";
        }
    }
    $content .= "</pre>";
    
    showSection("📝 Logs de MercadoPago", "info", $content);
} else {
    showSection("⚠️ Archivo de log no encontrado", "warning", 
        "<p>No se encontró el archivo logs/error.log</p>"
    );
}

// 6. Verificar webhook
echo "<h2>6. 🔗 Configuración del Webhook</h2>\n";

$webhookUrl = defined('MP_WEBHOOK_URL') ? MP_WEBHOOK_URL : 'No definida';
showSection("🔗 URL del Webhook", "info", 
    "<p><strong>URL:</strong> $webhookUrl</p>" .
    "<p><strong>Archivo:</strong> " . (file_exists(__DIR__ . '/webhook.php') ? '✅ Existe' : '❌ No existe') . "</p>"
);

// 7. Recomendaciones
echo "<h2>7. 💡 Recomendaciones</h2>\n";

$recommendations = [];

// Verificar si hay membresías activas sin preapproval_id
try {
    $count = $pdo->query("SELECT COUNT(*) FROM membresias WHERE mp_status = 'authorized' AND mp_preapproval_id IS NULL")->fetchColumn();
    if ($count > 0) {
        $recommendations[] = "Hay $count membresías activas sin preapproval_id. Estas no se pueden cancelar automáticamente.";
    }
} catch (Exception $e) {
    $recommendations[] = "Error al verificar membresías sin preapproval_id: " . $e->getMessage();
}

// Verificar si hay tipos sin cargo configurado
try {
    $count = $pdo->query("SELECT COUNT(*) FROM tipos_membresia WHERE monto_cancelacion = 0 OR monto_cancelacion IS NULL")->fetchColumn();
    if ($count > 0) {
        $recommendations[] = "Hay $count tipos de membresía sin cargo por cancelación configurado.";
    }
} catch (Exception $e) {
    $recommendations[] = "Error al verificar tipos sin cargo: " . $e->getMessage();
}

if (empty($recommendations)) {
    showSection("✅ Sistema en buen estado", "success", 
        "<p>No se encontraron problemas críticos en el sistema.</p>"
    );
} else {
    $content = "<ul>";
    foreach ($recommendations as $rec) {
        $content .= "<li>$rec</li>";
    }
    $content .= "</ul>";
    
    showSection("⚠️ Recomendaciones", "warning", $content);
}

echo "<p><em>Verificación completada el " . date('Y-m-d H:i:s') . "</em></p>\n";
?>
