<?php
/**
 * Script simple para probar las credenciales de MercadoPago
 */

require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'config/mercadopago_config.php';

initConfig();

echo "<h1>🔑 Prueba Simple de Credenciales de MercadoPago</h1>\n";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { background-color: #d4edda; border-color: #c3e6cb; color: #155724; }
    .error { background-color: #f8d7da; border-color: #f5c6cb; color: #721c24; }
    .info { background-color: #d1ecf1; border-color: #bee5eb; color: #0c5460; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
</style>\n";

function showResult($title, $success, $message, $data = null) {
    $class = $success ? 'success' : 'error';
    echo "<div class='test-section $class'>\n";
    echo "<h3>$title</h3>\n";
    echo "<p>$message</p>\n";
    if ($data) {
        echo "<pre>" . print_r($data, true) . "</pre>\n";
    }
    echo "</div>\n";
}

// 1. Verificar configuración
echo "<h2>1. 📋 Configuración</h2>\n";
showResult("Configuración", true, "Verificando configuración de MercadoPago", [
    'MP_PUBLIC_KEY' => defined('MP_PUBLIC_KEY') ? MP_PUBLIC_KEY : 'No definida',
    'MP_ACCESS_TOKEN' => defined('MP_ACCESS_TOKEN') ? substr(MP_ACCESS_TOKEN, 0, 20) . '...' : 'No definida',
    'MP_WEBHOOK_URL' => defined('MP_WEBHOOK_URL') ? MP_WEBHOOK_URL : 'No definida',
    'Collector ID' => getCollectorIdFromToken(MP_ACCESS_TOKEN)
]);

// 2. Probar inicialización
echo "<h2>2. 🔧 Inicialización</h2>\n";
try {
    mpInit();
    showResult("Inicialización", true, "SDK de MercadoPago inicializado correctamente");
} catch (Exception $e) {
    showResult("Inicialización", false, "Error al inicializar: " . $e->getMessage());
}

// 3. Probar verificación de credenciales
echo "<h2>3. ✅ Verificación de Credenciales</h2>\n";
try {
    $result = mpVerifyCredentials();
    if ($result['success']) {
        showResult("Credenciales", true, "Credenciales válidas", $result);
    } else {
        showResult("Credenciales", false, "Error en credenciales: " . ($result['error'] ?? 'Error desconocido'), $result);
    }
} catch (Exception $e) {
    showResult("Credenciales", false, "Error al verificar credenciales: " . $e->getMessage());
}

// 4. Probar conexión
echo "<h2>4. 🌐 Prueba de Conexión</h2>\n";
try {
    $result = mpTestConnection();
    if ($result['success']) {
        showResult("Conexión", true, "Conexión exitosa con MercadoPago", $result);
    } else {
        showResult("Conexión", false, "Error de conexión: " . ($result['error'] ?? 'Error desconocido'), $result);
    }
} catch (Exception $e) {
    showResult("Conexión", false, "Error al probar conexión: " . $e->getMessage());
}

// 5. Probar creación de plan (opcional)
echo "<h2>5. 🧪 Prueba de Creación de Plan (Opcional)</h2>\n";
echo "<div class='test-section info'>\n";
echo "<h3>⚠️ Nota Importante</h3>\n";
echo "<p>Esta prueba intentará crear un plan real en MercadoPago. Solo ejecuta si las pruebas básicas pasaron.</p>\n";
echo "<p>Si hay problemas de país, esta prueba fallará pero las credenciales básicas pueden estar correctas.</p>\n";
echo "</div>\n";

if (isset($_GET['test_plan']) && $_GET['test_plan'] === '1') {
    try {
        $result = mpTestPlanCreation();
        if ($result['success']) {
            showResult("Creación de Plan", true, "Plan creado exitosamente", $result);
        } else {
            showResult("Creación de Plan", false, "Error al crear plan: " . ($result['error'] ?? 'Error desconocido'), $result);
        }
    } catch (Exception $e) {
        showResult("Creación de Plan", false, "Error al probar creación de plan: " . $e->getMessage());
    }
} else {
    echo "<div class='test-section info'>\n";
    echo "<h3>Prueba de Creación de Plan</h3>\n";
    echo "<p>Para probar la creación de planes, agrega <code>?test_plan=1</code> a la URL.</p>\n";
    echo "<p><a href='?test_plan=1' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Probar Creación de Plan</a></p>\n";
    echo "</div>\n";
}

echo "<p><em>Prueba completada el " . date('Y-m-d H:i:s') . "</em></p>\n";
?>
