<?php
require_once __DIR__ . '/includes/db.php';

echo "<h2>Verificando usuario administrador...</h2>";

try {
    // Verificar si existe la tabla usuarios
    $stmt = $pdo->query("SHOW TABLES LIKE 'usuarios'");
    if ($stmt->rowCount() == 0) {
        echo "<p style='color: red;'>❌ La tabla 'usuarios' no existe.</p>";
        echo "<p>Ejecuta primero el archivo SQL: membresias.sql</p>";
        exit;
    }
    
    // Verificar si existe la tabla roles
    $stmt = $pdo->query("SHOW TABLES LIKE 'roles'");
    if ($stmt->rowCount() == 0) {
        echo "<p style='color: red;'>❌ La tabla 'roles' no existe.</p>";
        echo "<p>Ejecuta primero el archivo SQL: membresias.sql</p>";
        exit;
    }
    
    // Verificar si existen roles
    $stmt = $pdo->query("SELECT COUNT(*) FROM roles");
    $rolesCount = $stmt->fetchColumn();
    
    if ($rolesCount == 0) {
        echo "<p>📝 Insertando roles...</p>";
        $pdo->exec("INSERT INTO roles (nombre) VALUES ('Administrador'), ('Usuario'), ('Operador'), ('Supervisor')");
        echo "<p style='color: green;'>✅ Roles insertados correctamente.</p>";
    } else {
        echo "<p style='color: green;'>✅ Roles ya existen.</p>";
    }
    
    // Verificar si existe el usuario admin
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE usuario = 'admin'");
    $stmt->execute();
    $userExists = $stmt->fetchColumn();
    
    if ($userExists == 0) {
        echo "<p>📝 Creando usuario administrador...</p>";
        
        // Crear usuario admin
        $password_hash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, usuario, password, correo, rol_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            'Administrador del Sistema',
            'admin',
            $password_hash,
            'admin@sistema.com',
            1
        ]);
        
        echo "<p style='color: green;'>✅ Usuario administrador creado correctamente.</p>";
        echo "<p><strong>Credenciales:</strong></p>";
        echo "<ul>";
        echo "<li><strong>Usuario:</strong> admin</li>";
        echo "<li><strong>Contraseña:</strong> admin123</li>";
        echo "</ul>";
    } else {
        echo "<p style='color: green;'>✅ El usuario administrador ya existe.</p>";
        
        // Verificar la contraseña
        $stmt = $pdo->prepare("SELECT password FROM usuarios WHERE usuario = 'admin'");
        $stmt->execute();
        $user = $stmt->fetch();
        
        if (password_verify('admin123', $user['password'])) {
            echo "<p style='color: green;'>✅ La contraseña es correcta.</p>";
        } else {
            echo "<p style='color: orange;'>⚠️ La contraseña no coincide con 'admin123'.</p>";
            echo "<p>Actualizando contraseña...</p>";
            
            $password_hash = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE usuarios SET password = ? WHERE usuario = 'admin'");
            $stmt->execute([$password_hash]);
            
            echo "<p style='color: green;'>✅ Contraseña actualizada correctamente.</p>";
        }
    }
    
    echo "<hr>";
    echo "<p><strong>Credenciales para acceder:</strong></p>";
    echo "<ul>";
    echo "<li><strong>Usuario:</strong> admin</li>";
    echo "<li><strong>Contraseña:</strong> admin123</li>";
    echo "</ul>";
    echo "<p><a href='index.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Ir al Login</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?> 