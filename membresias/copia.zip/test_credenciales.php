<?php
/**
 * Script simple para probar las credenciales de MercadoPago
 */

require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'config/mercadopago_config.php';

initConfig();

echo "<h1>🔑 Prueba de Credenciales de MercadoPago</h1>\n";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { background-color: #d4edda; border-color: #c3e6cb; color: #155724; }
    .error { background-color: #f8d7da; border-color: #f5c6cb; color: #721c24; }
    .info { background-color: #d1ecf1; border-color: #bee5eb; color: #0c5460; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
</style>\n";

function showResult($title, $success, $message, $data = null) {
    $class = $success ? 'success' : 'error';
    echo "<div class='test-section $class'>\n";
    echo "<h3>$title</h3>\n";
    echo "<p>$message</p>\n";
    if ($data) {
        echo "<pre>" . print_r($data, true) . "</pre>\n";
    }
    echo "</div>\n";
}

// 1. Verificar configuración
echo "<h2>1. 📋 Configuración</h2>\n";
showResult("Configuración", true, "Verificando configuración de MercadoPago", [
    'MP_PUBLIC_KEY' => defined('MP_PUBLIC_KEY') ? MP_PUBLIC_KEY : 'No definida',
    'MP_ACCESS_TOKEN' => defined('MP_ACCESS_TOKEN') ? substr(MP_ACCESS_TOKEN, 0, 20) . '...' : 'No definida',
    'MP_WEBHOOK_URL' => defined('MP_WEBHOOK_URL') ? MP_WEBHOOK_URL : 'No definida'
]);

// 2. Probar inicialización
echo "<h2>2. 🔧 Inicialización</h2>\n";
try {
    mpInit();
    showResult("Inicialización", true, "SDK de MercadoPago inicializado correctamente");
} catch (Exception $e) {
    showResult("Inicialización", false, "Error al inicializar: " . $e->getMessage());
}

// 3. Probar verificación de credenciales
echo "<h2>3. ✅ Verificación de Credenciales</h2>\n";
try {
    $result = mpVerifyCredentials();
    if ($result['success']) {
        showResult("Credenciales", true, "Credenciales válidas", $result);
    } else {
        showResult("Credenciales", false, "Error en credenciales: " . ($result['error'] ?? 'Error desconocido'), $result);
    }
} catch (Exception $e) {
    showResult("Credenciales", false, "Error al verificar credenciales: " . $e->getMessage());
}

// 4. Probar conexión
echo "<h2>4. 🌐 Prueba de Conexión</h2>\n";
try {
    $result = mpTestConnection();
    if ($result['success']) {
        showResult("Conexión", true, "Conexión exitosa con MercadoPago", $result);
    } else {
        showResult("Conexión", false, "Error de conexión: " . ($result['error'] ?? 'Error desconocido'), $result);
    }
} catch (Exception $e) {
    showResult("Conexión", false, "Error al probar conexión: " . $e->getMessage());
}

echo "<p><em>Prueba completada el " . date('Y-m-d H:i:s') . "</em></p>\n";
?>
