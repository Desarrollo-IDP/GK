# Guía de Estilo - Sistema Ticket SecuriTI Moderno

## 🎨 Paleta de Colores

### Colores Principales
- **Azul Profundo**: `#1d4ed8` (Primary-700)
- **Azul Medio**: `#3b82f6` (Primary-500)
- **Azul Claro**: `#60a5fa` (Primary-400)

### Grises Neutros
- **Gris Oscuro**: `#111827` (Gray-900)
- **Gris Medio**: `#6b7280` (Gray-500)
- **Gris Claro**: `#f3f4f6` (Gray-100)
- **Gris Muy Claro**: `#f9fafb` (Gray-50)

### Colores de Acento
- **Verde Salvia**: `#5f715f` (Sage-500)
- **Terracota Suave**: `#d17a5f` (Terracotta-500)

### Estados y Feedback
- **Éxito**: `#22c55e` (Success-500)
- **Advertencia**: `#f59e0b` (Warning-500)
- **Error**: `#ef4444` (Error-500)
- **Información**: `#3b82f6` (Info-500)

## 📝 Tipografía

### Familia de Fuentes
```css
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
```

### Jerarquía de Títulos
- **H1**: `2rem` (32px) - Páginas principales
- **H2**: `1.75rem` (28px) - Secciones importantes
- **H3**: `1.5rem` (24px) - Subsecciones
- **H4**: `1.25rem` (20px) - Elementos de formulario
- **H5**: `1.125rem` (18px) - Texto destacado
- **H6**: `1rem` (16px) - Texto normal

### Pesos de Fuente
- **Light**: 300
- **Regular**: 400
- **Medium**: 500
- **Semibold**: 600
- **Bold**: 700

## 🧱 Componentes

### Botones

#### Botón Primario
```html
<button class="btn btn-primary">
    <i class="fas fa-plus me-2"></i>Crear Ticket
</button>
```

#### Botón Secundario
```html
<button class="btn btn-secondary">
    <i class="fas fa-edit me-2"></i>Editar
</button>
```

#### Botón Outline
```html
<button class="btn btn-outline">
    <i class="fas fa-eye me-2"></i>Ver Detalles
</button>
```

### Tarjetas

#### Tarjeta Básica
```html
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Título de la Tarjeta</h5>
    </div>
    <div class="card-body">
        Contenido de la tarjeta
    </div>
</div>
```

#### Tarjeta con Estadísticas
```html
<div class="card h-100">
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-between">
            <div>
                <div class="text-sm text-muted mb-1">Etiqueta</div>
                <div class="h3 font-bold text-primary">Valor</div>
            </div>
            <div class="bg-primary bg-opacity-10 p-3 rounded">
                <i class="fas fa-icon fa-2x text-primary"></i>
            </div>
        </div>
    </div>
</div>
```

### Tablas

#### Tabla Moderna
```html
<div class="table-container">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Columna 1</th>
                    <th>Columna 2</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Dato 1</td>
                    <td>Dato 2</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
```

### Badges

#### Badge de Estado
```html
<span class="badge badge-primary">
    <i class="fas fa-check-circle me-1"></i>Activo
</span>
```

### Formularios

#### Campo de Entrada
```html
<div class="form-group">
    <label class="form-label">Etiqueta del Campo</label>
    <input type="text" class="form-control" placeholder="Placeholder">
</div>
```

#### Select
```html
<div class="form-group">
    <label class="form-label">Seleccionar Opción</label>
    <select class="form-select">
        <option>Opción 1</option>
        <option>Opción 2</option>
    </select>
</div>
```

### Alertas

#### Alerta de Éxito
```html
<div class="alert alert-success">
    <i class="fas fa-check-circle me-2"></i>
    Operación completada exitosamente
</div>
```

#### Alerta de Error
```html
<div class="alert alert-danger">
    <i class="fas fa-exclamation-triangle me-2"></i>
    Ha ocurrido un error
</div>
```

## 🎯 Iconografía

### Iconos Principales
- **Dashboard**: `fas fa-tachometer-alt`
- **Tickets**: `fas fa-ticket-alt`
- **Usuarios**: `fas fa-users`
- **Técnicos**: `fas fa-tools`
- **Reportes**: `fas fa-chart-bar`
- **Configuración**: `fas fa-cog`
- **Correo**: `fas fa-envelope`

### Iconos de Acción
- **Ver**: `fas fa-eye`
- **Editar**: `fas fa-edit`
- **Eliminar**: `fas fa-trash`
- **Agregar**: `fas fa-plus`
- **Buscar**: `fas fa-search`
- **Descargar**: `fas fa-download`

### Iconos de Estado
- **Abierto**: `fas fa-folder-open`
- **En Proceso**: `fas fa-cogs`
- **Cerrado**: `fas fa-check-circle`
- **Sin Asignar**: `fas fa-user-clock`

## 📱 Responsive Design

### Breakpoints
- **Mobile**: < 768px
- **Tablet**: 768px - 1024px
- **Desktop**: > 1024px

### Comportamiento Responsive
- Sidebar se oculta en móvil y se muestra como overlay
- Tablas se vuelven scrollables horizontalmente
- Botones se apilan verticalmente en móvil
- Espaciado se reduce en pantallas pequeñas

## 🎭 Animaciones y Microinteracciones

### Transiciones
- **Rápida**: 150ms ease-in-out
- **Normal**: 250ms ease-in-out
- **Lenta**: 350ms ease-in-out

### Animaciones
- **Fade In**: Para elementos que aparecen
- **Slide In**: Para navegación
- **Pulse**: Para elementos importantes
- **Hover**: Elevación sutil en tarjetas y botones

## ♿ Accesibilidad

### Contraste
- Ratio mínimo de 4.5:1 para texto normal
- Ratio mínimo de 3:1 para texto grande
- Colores de alto contraste disponibles

### Navegación por Teclado
- Todos los elementos interactivos son focusables
- Indicadores de focus visibles
- Navegación lógica con Tab

### Lectores de Pantalla
- Etiquetas ARIA apropiadas
- Textos alternativos para iconos
- Estructura semántica correcta

## 🎨 Tema Oscuro

### Variables CSS para Tema Oscuro
```css
[data-theme="dark"] {
    --bg-primary: #1f2937;
    --bg-secondary: #374151;
    --text-primary: #f9fafb;
    --text-secondary: #d1d5db;
    --border-color: #4b5563;
}
```

### Implementación
- Toggle en el sidebar
- Persistencia en localStorage
- Transición suave entre temas

## 📋 Checklist de Implementación

### ✅ Completado
- [x] Sistema de variables CSS
- [x] Paleta de colores moderna
- [x] Tipografía Inter
- [x] Componentes base (botones, tarjetas, tablas)
- [x] Header moderno
- [x] Sidebar reorganizado
- [x] Página de tickets moderna
- [x] Responsive design
- [x] Animaciones básicas

### 🔄 En Progreso
- [ ] Tema oscuro completo
- [ ] Más páginas modernizadas
- [ ] Componentes avanzados
- [ ] Optimización de rendimiento

### 📋 Pendiente
- [ ] Dashboard moderno
- [ ] Formularios avanzados
- [ ] Gráficos y reportes
- [ ] Notificaciones en tiempo real
- [ ] Búsqueda avanzada
- [ ] Filtros dinámicos

## 🚀 Próximos Pasos

1. **Implementar tema oscuro completo**
2. **Modernizar todas las páginas existentes**
3. **Crear componentes reutilizables**
4. **Optimizar para dispositivos móviles**
5. **Implementar funcionalidades avanzadas**
6. **Documentación de componentes**
7. **Testing y QA**

---

*Esta guía de estilo está diseñada para mantener consistencia visual y de experiencia de usuario en todo el sistema Ticket SecuriTI.* 