-- Actualización de la tabla tipos_membresia para integrar Stripe
-- Ejecutar este script para agregar los campos necesarios para pagos recurrentes

-- Agregar campos para configuración de duración y Stripe
ALTER TABLE tipos_membresia 
ADD COLUMN duracion_dias INT DEFAULT 30 COMMENT 'Duración de la membresía en días',
ADD COLUMN `interval` ENUM('day', 'week', 'month', 'year') DEFAULT 'month' COMMENT 'Intervalo de facturación para suscripciones recurrentes',
ADD COLUMN interval_count INT DEFAULT 1 COMMENT 'Número de intervalos entre cada facturación',
ADD COLUMN stripe_product_id VARCHAR(255) NULL COMMENT 'ID del producto en Stripe',
ADD COLUMN stripe_price_id VARCHAR(255) NULL COMMENT 'ID del precio en Stripe';

-- Agregar índices para mejorar el rendimiento
CREATE INDEX idx_tipos_membresia_interval ON tipos_membresia(`interval`);
CREATE INDEX idx_tipos_membresia_stripe_product ON tipos_membresia(stripe_product_id);
CREATE INDEX idx_tipos_membresia_stripe_price ON tipos_membresia(stripe_price_id);

-- Actualizar registros existentes con valores por defecto
UPDATE tipos_membresia SET 
    duracion_dias = 30,
    `interval` = 'month',
    interval_count = 1
WHERE duracion_dias IS NULL;

-- Agregar campos a la tabla membresias para Stripe
ALTER TABLE membresias 
ADD COLUMN stripe_customer_id VARCHAR(255) NULL COMMENT 'ID del cliente en Stripe',
ADD COLUMN stripe_subscription_id VARCHAR(255) NULL COMMENT 'ID de la suscripción en Stripe';

-- Agregar índices para la tabla membresias
CREATE INDEX idx_membresias_stripe_customer ON membresias(stripe_customer_id);
CREATE INDEX idx_membresias_stripe_subscription ON membresias(stripe_subscription_id);

-- Crear tabla para logs de pagos de Stripe
CREATE TABLE IF NOT EXISTS stripe_payment_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    membresia_id INT NOT NULL,
    stripe_customer_id VARCHAR(255) NULL,
    stripe_subscription_id VARCHAR(255) NULL,
    stripe_payment_intent_id VARCHAR(255) NULL,
    amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'MXN',
    status VARCHAR(50) NOT NULL,
    payment_method VARCHAR(50) NULL,
    error_message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (membresia_id) REFERENCES membresias(id) ON DELETE CASCADE,
    INDEX idx_stripe_logs_membresia (membresia_id),
    INDEX idx_stripe_logs_customer (stripe_customer_id),
    INDEX idx_stripe_logs_subscription (stripe_subscription_id),
    INDEX idx_stripe_logs_payment_intent (stripe_payment_intent_id),
    INDEX idx_stripe_logs_status (status),
    INDEX idx_stripe_logs_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crear tabla para webhooks de Stripe
CREATE TABLE IF NOT EXISTS stripe_webhooks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    stripe_event_id VARCHAR(255) NOT NULL UNIQUE,
    event_type VARCHAR(100) NOT NULL,
    stripe_object_id VARCHAR(255) NULL,
    stripe_object_type VARCHAR(50) NULL,
    payload JSON NOT NULL,
    processed BOOLEAN DEFAULT FALSE,
    error_message TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    
    INDEX idx_webhooks_event_id (stripe_event_id),
    INDEX idx_webhooks_event_type (event_type),
    INDEX idx_webhooks_processed (processed),
    INDEX idx_webhooks_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insertar datos de ejemplo para tipos de membresía con configuración de Stripe
INSERT INTO tipos_membresia (nombre, descripcion, precio, duracion_dias, `interval`, interval_count) VALUES
('Membresía Básica Mensual', 'Acceso básico a las instalaciones', 299.00, 30, 'month', 1),
('Membresía Premium Mensual', 'Acceso completo con beneficios adicionales', 599.00, 30, 'month', 1),
('Membresía Anual', 'Membresía anual con descuento', 2999.00, 365, 'year', 1),
('Membresía Semanal', 'Acceso por una semana', 99.00, 7, 'week', 1),
('Membresía Trimestral', 'Membresía por 3 meses', 799.00, 90, 'month', 3)
ON DUPLICATE KEY UPDATE
    duracion_dias = VALUES(duracion_dias),
    `interval` = VALUES(`interval`),
    interval_count = VALUES(interval_count);

-- Crear vista para información completa de membresías con Stripe
CREATE OR REPLACE VIEW v_membresias_completas AS
SELECT 
    m.id,
    m.cliente_id,
    c.nombre,
    c.apellido_paterno,
    c.apellido_materno,
    c.correo,
    c.telefono,
    tm.nombre as tipo_membresia_nombre,
    tm.precio,
    tm.duracion_dias,
    tm.`interval`,
    tm.interval_count,
    m.fecha_inicio,
    m.fecha_fin,
    m.metodo_pago,
    m.stripe_customer_id,
    m.stripe_subscription_id,
    m.firma_digital,
    m.created_at,
    CASE 
        WHEN m.fecha_fin < CURDATE() THEN 'expirada'
        WHEN m.fecha_inicio > CURDATE() THEN 'pendiente'
        ELSE 'activa'
    END as estado
FROM membresias m
JOIN clientes c ON m.cliente_id = c.id
JOIN tipos_membresia tm ON m.tipo_membresia_id = tm.id;

-- Crear procedimiento almacenado para sincronizar productos con Stripe
DELIMITER //
CREATE PROCEDURE sp_sincronizar_stripe_productos()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE tipo_id INT;
    DECLARE tipo_nombre VARCHAR(255);
    DECLARE tipo_descripcion TEXT;
    DECLARE tipo_precio DECIMAL(10,2);
    DECLARE tipo_duracion INT;
    DECLARE tipo_interval VARCHAR(20);
    DECLARE tipo_interval_count INT;
    
    DECLARE cur CURSOR FOR 
        SELECT id, nombre, descripcion, precio, duracion_dias, `interval`, interval_count 
        FROM tipos_membresia 
        WHERE stripe_product_id IS NULL OR stripe_price_id IS NULL;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO tipo_id, tipo_nombre, tipo_descripcion, tipo_precio, tipo_duracion, tipo_interval, tipo_interval_count;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Aquí se ejecutaría la lógica para crear productos y precios en Stripe
        -- Por ahora solo actualizamos con valores de ejemplo
        UPDATE tipos_membresia 
        SET stripe_product_id = CONCAT('prod_', tipo_id),
            stripe_price_id = CONCAT('price_', tipo_id)
        WHERE id = tipo_id;
        
    END LOOP;
    
    CLOSE cur;
END //
DELIMITER ;

-- Crear trigger para actualizar fecha_fin automáticamente
DELIMITER //
CREATE TRIGGER tr_calcular_fecha_fin
BEFORE INSERT ON membresias
FOR EACH ROW
BEGIN
    DECLARE duracion_dias INT;
    
    IF NEW.fecha_fin IS NULL OR NEW.fecha_fin = '' THEN
        SELECT tm.duracion_dias INTO duracion_dias
        FROM tipos_membresia tm
        WHERE tm.id = NEW.tipo_membresia_id;
        
        IF duracion_dias IS NOT NULL THEN
            SET NEW.fecha_fin = DATE_ADD(NEW.fecha_inicio, INTERVAL duracion_dias DAY);
        END IF;
    END IF;
END //
DELIMITER ;

-- Crear trigger para actualizar fecha_fin en actualizaciones
DELIMITER //
CREATE TRIGGER tr_calcular_fecha_fin_update
BEFORE UPDATE ON membresias
FOR EACH ROW
BEGIN
    DECLARE duracion_dias INT;
    
    IF NEW.fecha_fin IS NULL OR NEW.fecha_fin = '' OR NEW.tipo_membresia_id != OLD.tipo_membresia_id THEN
        SELECT tm.duracion_dias INTO duracion_dias
        FROM tipos_membresia tm
        WHERE tm.id = NEW.tipo_membresia_id;
        
        IF duracion_dias IS NOT NULL THEN
            SET NEW.fecha_fin = DATE_ADD(NEW.fecha_inicio, INTERVAL duracion_dias DAY);
        END IF;
    END IF;
END //
DELIMITER ;

-- Comentarios sobre la estructura
-- 
-- Campos agregados a tipos_membresia:
-- - duracion_dias: Duración de la membresía en días
-- - interval: Intervalo de facturación (day, week, month, year)
-- - interval_count: Número de intervalos entre facturaciones
-- - stripe_product_id: ID del producto en Stripe
-- - stripe_price_id: ID del precio en Stripe
--
-- Campos agregados a membresias:
-- - stripe_customer_id: ID del cliente en Stripe
-- - stripe_subscription_id: ID de la suscripción en Stripe
--
-- Tablas nuevas:
-- - stripe_payment_logs: Registro de todos los pagos procesados
-- - stripe_webhooks: Registro de webhooks recibidos de Stripe
--
-- Vistas y procedimientos:
-- - v_membresias_completas: Vista con información completa de membresías
-- - sp_sincronizar_stripe_productos: Procedimiento para sincronizar con Stripe
-- - Triggers para calcular automáticamente las fechas de fin 