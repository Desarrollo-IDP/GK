-- Migración: Integración Mercado Pago (planes y suscripciones)
-- MySQL 8.0+

START TRANSACTION;

-- 1) Nuevas columnas en tipos_membresia
ALTER TABLE tipos_membresia 
  ADD COLUMN IF NOT EXISTS mp_plan_id VARCHAR(255) NULL COMMENT 'ID del plan de preaprobación en Mercado Pago';

-- 2) Nuevas columnas en membresias
ALTER TABLE membresias 
  ADD COLUMN IF NOT EXISTS mp_preapproval_id VARCHAR(255) NULL COMMENT 'ID de la suscripción (preapproval) en Mercado Pago',
  ADD COLUMN IF NOT EXISTS mp_plan_id VARCHAR(255) NULL COMMENT 'Plan asociado usado para suscripción',
  ADD COLUMN IF NOT EXISTS mp_status VARCHAR(50) NULL COMMENT 'Estado de la suscripción reportado por MP',
  ADD COLUMN IF NOT EXISTS mp_next_payment_date DATETIME NULL COMMENT 'Próxima fecha de cobro provista por MP';

-- 3) Índices idempotentes (solo se crean si no existen)
-- tipos_membresia(mp_plan_id)
SET @exist := (
  SELECT COUNT(1) FROM information_schema.statistics 
  WHERE table_schema = DATABASE() AND table_name = 'tipos_membresia' AND index_name = 'idx_tipos_membresia_mp_plan'
);
SET @sql := IF(@exist = 0, 'CREATE INDEX idx_tipos_membresia_mp_plan ON tipos_membresia(mp_plan_id);', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- membresias(mp_preapproval_id)
SET @exist := (
  SELECT COUNT(1) FROM information_schema.statistics 
  WHERE table_schema = DATABASE() AND table_name = 'membresias' AND index_name = 'idx_membresias_mp_preapproval'
);
SET @sql := IF(@exist = 0, 'CREATE INDEX idx_membresias_mp_preapproval ON membresias(mp_preapproval_id);', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- membresias(mp_plan_id)
SET @exist := (
  SELECT COUNT(1) FROM information_schema.statistics 
  WHERE table_schema = DATABASE() AND table_name = 'membresias' AND index_name = 'idx_membresias_mp_plan'
);
SET @sql := IF(@exist = 0, 'CREATE INDEX idx_membresias_mp_plan ON membresias(mp_plan_id);', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- membresias(mp_status)
SET @exist := (
  SELECT COUNT(1) FROM information_schema.statistics 
  WHERE table_schema = DATABASE() AND table_name = 'membresias' AND index_name = 'idx_membresias_mp_status'
);
SET @sql := IF(@exist = 0, 'CREATE INDEX idx_membresias_mp_status ON membresias(mp_status);', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

COMMIT;

-- Fin de migración

