-- Datos iniciales para el sistema de usuarios
-- Ejecutar después de crear las tablas

-- Insertar roles básicos
INSERT INTO roles (nombre) VALUES 
('Administrador'),
('Usuario'),
('Operador'),
('Supervisor');

-- Insertar usuario administrador por defecto
-- Contraseña: admin123 (hash generado con password_hash)
INSERT INTO usuarios (nombre, usuario, password, correo, rol_id) VALUES 
('Administrador del Sistema', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@sistema.com', 1);

-- Nota: La contraseña por defecto es 'admin123'
-- Para cambiar la contraseña, usar:
-- UPDATE usuarios SET password = '$2y$10$' || password_hash('nueva_contraseña', PASSWORD_DEFAULT) WHERE usuario = 'admin'; 