-- Campos recomendados para integración Mercado Pago
ALTER TABLE tipos_membresia 
    ADD COLUMN IF NOT EXISTS mp_plan_id VARCHAR(255) NULL COMMENT 'ID del plan de preaprobación en Mercado Pago';

ALTER TABLE membresias 
    ADD COLUMN IF NOT EXISTS mp_preapproval_id VARCHAR(255) NULL COMMENT 'ID de la suscripción (preapproval) en Mercado Pago',
    ADD COLUMN IF NOT EXISTS mp_plan_id VARCHAR(255) NULL COMMENT 'Plan asociado usado para suscripción',
    ADD COLUMN IF NOT EXISTS mp_status VARCHAR(50) NULL COMMENT 'Estado de la suscripción reportado por MP',
    ADD COLUMN IF NOT EXISTS mp_next_payment_date DATETIME NULL COMMENT 'Próxima fecha de cobro provista por MP';

CREATE INDEX IF NOT EXISTS idx_tipos_membresia_mp_plan ON tipos_membresia(mp_plan_id);
CREATE INDEX IF NOT EXISTS idx_membresias_mp_preapproval ON membresias(mp_preapproval_id);
CREATE INDEX IF NOT EXISTS idx_membresias_mp_plan ON membresias(mp_plan_id);
-- Estructura de la base de datos para el sistema de membresías

-- Tabla de roles de usuario
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL
);

-- Tabla de usuarios
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    correo VARCHAR(100),
    rol_id INT,
    FOREIGN KEY (rol_id) REFERENCES roles(id)
);

-- Tabla de clientes
CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido_paterno VARCHAR(50) NOT NULL,
    apellido_materno VARCHAR(50),
    edad INT,
    fecha_nacimiento DATE,
    sexo ENUM('M','F','Otro'),
    curp VARCHAR(18),
    foto VARCHAR(255),
    direccion TEXT,
    correo VARCHAR(100),
    telefono VARCHAR(20),
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de tipos de membresía
CREATE TABLE tipos_membresia (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10,2)
);

-- Tabla de membresías
CREATE TABLE membresias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT DEFAULT NULL,
    tipo_membresia_id INT,
    fecha_inicio DATE,
    fecha_fin DATE,
    metodo_pago VARCHAR(50),
    firma_digital VARCHAR(255),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    FOREIGN KEY (tipo_membresia_id) REFERENCES tipos_membresia(id)
); 