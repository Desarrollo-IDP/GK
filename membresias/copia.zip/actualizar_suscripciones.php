<?php
/**
 * Actualizador Manual de Suscripciones
 * 
 * Este script permite actualizar manualmente las suscripciones pendientes
 * cuando los webhooks no llegan correctamente.
 */

require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'config/mercadopago_config.php';

initConfig();

echo "<h1>🔄 Actualizador Manual de Suscripciones</h1>\n";
echo "<style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }
    .success { background-color: #d4edda; border-color: #c3e6cb; color: #155724; }
    .error { background-color: #f8d7da; border-color: #f5c6cb; color: #721c24; }
    .info { background-color: #d1ecf1; border-color: #bee5eb; color: #0c5460; }
    .warning { background-color: #fff3cd; border-color: #ffeaa7; color: #856404; }
    pre { background: #f8f9fa; padding: 10px; border-radius: 3px; overflow-x: auto; }
    .step { font-weight: bold; margin-bottom: 10px; }
    .form-group { margin: 10px 0; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
    .form-group input, .form-group select { width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
    .btn { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; }
    .btn:hover { background: #0056b3; }
</style>\n";

function showResult($title, $success, $message, $data = null) {
    $class = $success ? 'success' : 'error';
    echo "<div class='test-section $class'>\n";
    echo "<div class='step'>$title</div>\n";
    echo "<p>$message</p>\n";
    if ($data) {
        echo "<pre>" . print_r($data, true) . "</pre>\n";
    }
    echo "</div>\n";
}

function showInfo($title, $message, $data = null) {
    echo "<div class='test-section info'>\n";
    echo "<div class='step'>$title</div>\n";
    echo "<p>$message</p>\n";
    if ($data) {
        echo "<pre>" . print_r($data, true) . "</pre>\n";
    }
    echo "</div>\n";
}

// Procesar actualización manual
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_membresia'])) {
    $membresiaId = (int)$_POST['membresia_id'];
    $preapprovalId = $_POST['preapproval_id'];
    $status = $_POST['status'];
    $payerEmail = $_POST['payer_email'];
    
    try {
        // Verificar que la membresía existe
        $membresiaStmt = $pdo->prepare("SELECT m.*, c.correo, c.nombre, c.apellido_paterno 
                                       FROM membresias m 
                                       LEFT JOIN clientes c ON m.cliente_id = c.id 
                                       WHERE m.id = ?");
        $membresiaStmt->execute([$membresiaId]);
        $membresia = $membresiaStmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$membresia) {
            showResult("❌ Error", false, "Membresía no encontrada");
        } else {
            // Actualizar membresía
            $updateSql = "UPDATE membresias SET 
                         mp_preapproval_id = ?, 
                         mp_status = ?, 
                         mp_payment_method = 'credit_card',
                         mp_last_payment_date = NOW(),
                         mp_next_payment_date = DATE_ADD(NOW(), INTERVAL 1 MONTH)
                         WHERE id = ?";
            
            $stmt = $pdo->prepare($updateSql);
            $stmt->execute([$preapprovalId, $status, $membresiaId]);
            
            // Actualizar email del cliente si es diferente
            if ($payerEmail && $membresia['correo'] !== $payerEmail) {
                $clienteStmt = $pdo->prepare("UPDATE clientes SET correo = ? WHERE id = ?");
                $clienteStmt->execute([$payerEmail, $membresia['cliente_id']]);
            }
            
            showResult("✅ Actualización exitosa", true, "Membresía actualizada correctamente", [
                'membresia_id' => $membresiaId,
                'cliente' => $membresia['nombre'] . ' ' . $membresia['apellido_paterno'],
                'preapproval_id' => $preapprovalId,
                'status' => $status,
                'email_actualizado' => $payerEmail ?: $membresia['correo']
            ]);
        }
    } catch (Exception $e) {
        showResult("❌ Error al actualizar", false, "Error: " . $e->getMessage());
    }
}

// Mostrar membresías pendientes
echo "<h2>📋 Membresías Pendientes</h2>\n";

try {
    $membresiasPendientes = $pdo->query("
        SELECT m.*, c.nombre as cliente_nombre, c.apellido_paterno, c.correo, t.nombre as tipo_nombre
        FROM membresias m 
        JOIN clientes c ON m.cliente_id = c.id 
        JOIN tipos_membresia t ON m.tipo_membresia_id = t.id 
        WHERE m.mp_status = 'pending' AND m.metodo_pago = 'mercadopago'
        ORDER BY m.created_at DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($membresiasPendientes)) {
        showResult("✅ No hay membresías pendientes", true, "Todas las membresías están procesadas");
    } else {
        showInfo("Membresías pendientes", "Se encontraron " . count($membresiasPendientes) . " membresías pendientes");
        
        foreach ($membresiasPendientes as $membresia) {
            echo "<div class='test-section info'>\n";
            echo "<div class='step'>Membresía ID: " . $membresia['id'] . "</div>\n";
            echo "<p><strong>Cliente:</strong> " . $membresia['cliente_nombre'] . " " . $membresia['apellido_paterno'] . "</p>\n";
            echo "<p><strong>Email:</strong> " . $membresia['correo'] . "</p>\n";
            echo "<p><strong>Tipo:</strong> " . $membresia['tipo_nombre'] . "</p>\n";
            echo "<p><strong>Plan ID:</strong> " . $membresia['mp_plan_id'] . "</p>\n";
            echo "<p><strong>Fecha de registro:</strong> " . $membresia['created_at'] . "</p>\n";
            
            // Formulario para actualizar esta membresía
            echo "<form method='POST' style='margin-top: 10px;'>\n";
            echo "<input type='hidden' name='membresia_id' value='" . $membresia['id'] . "'>\n";
            echo "<div class='form-group'>\n";
            echo "<label>PreApproval ID (de MercadoPago):</label>\n";
            echo "<input type='text' name='preapproval_id' placeholder='Ej: 123456789' required>\n";
            echo "</div>\n";
            echo "<div class='form-group'>\n";
            echo "<label>Estado:</label>\n";
            echo "<select name='status' required>\n";
            echo "<option value='authorized'>Autorizada</option>\n";
            echo "<option value='pending'>Pendiente</option>\n";
            echo "<option value='paused'>Pausada</option>\n";
            echo "<option value='cancelled'>Cancelada</option>\n";
            echo "</select>\n";
            echo "</div>\n";
            echo "<div class='form-group'>\n";
            echo "<label>Email del pagador (opcional):</label>\n";
            echo "<input type='email' name='payer_email' placeholder='email@ejemplo.com'>\n";
            echo "</div>\n";
            echo "<button type='submit' name='update_membresia' class='btn'>Actualizar Membresía</button>\n";
            echo "</form>\n";
            echo "</div>\n";
        }
    }
} catch (Exception $e) {
    showResult("❌ Error al consultar membresías", false, "Error: " . $e->getMessage());
}

// Instrucciones
echo "<h2>📖 Instrucciones</h2>\n";

echo "<div class='test-section info'>\n";
echo "<div class='step'>🔧 Cómo usar este actualizador</div>\n";
echo "<ol>\n";
echo "<li><strong>Busca la suscripción en MercadoPago:</strong> Ve a tu cuenta de MercadoPago y busca la suscripción</li>\n";
echo "<li><strong>Copia el PreApproval ID:</strong> Es un ID largo que aparece en los detalles de la suscripción</li>\n";
echo "<li><strong>Verifica el estado:</strong> Confirma si la suscripción está 'authorized', 'pending', etc.</li>\n";
echo "<li><strong>Actualiza en el formulario:</strong> Completa los datos y haz clic en 'Actualizar Membresía'</li>\n";
echo "</ol>\n";
echo "</div>\n";

echo "<div class='test-section warning'>\n";
echo "<div class='step'>⚠️ Importante</div>\n";
echo "<p>Este actualizador es una solución temporal. Para que el sistema funcione automáticamente, debes:</p>\n";
echo "<ol>\n";
echo "<li>Configurar el webhook en MercadoPago Developer Dashboard</li>\n";
echo "<li>Verificar que la URL del webhook sea accesible</li>\n";
echo "<li>Probar que los webhooks llegan correctamente</li>\n";
echo "</ol>\n";
echo "</div>\n";

echo "<p><em>Actualizador completado el " . date('Y-m-d H:i:s') . "</em></p>\n";
?>
