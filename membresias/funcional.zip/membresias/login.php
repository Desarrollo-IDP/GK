<?php
include '../includes/db.php';
include '../includes/config.php';
include '../config/mercadopago_config.php';

initConfig();

$errores = [];
$mensaje = '';

// Si viene con token de primer acceso
$token = $_GET['token'] ?? '';
$mid = isset($_GET['mid']) ? intval($_GET['mid']) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';
    $correo = trim($_POST['correo'] ?? '');
    if ($accion === 'login') {
        $password = $_POST['password'] ?? '';
        try {
            $stmt = $pdo->prepare("SELECT * FROM clientes WHERE correo = ? LIMIT 1");
            $stmt->execute([$correo]);
            $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$cliente || empty($cliente['password_hash'])) {
                $errores[] = 'Credenciales inválidas.';
            } elseif (!password_verify($password, $cliente['password_hash'])) {
                $errores[] = 'Credenciales inválidas.';
            } else {
                $_SESSION['cliente'] = [
                    'id' => $cliente['id'],
                    'correo' => $cliente['correo'],
                    'nombre' => $cliente['nombre']
                ];
                header('Location: dashboard.php');
                exit;
            }
        } catch (Throwable $e) {
            $errores[] = 'Error al iniciar sesión: ' . $e->getMessage();
        }
    } elseif ($accion === 'set_password') {
        $password = $_POST['password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $correo = trim($_POST['correo'] ?? '');
        try {
            $stmt = $pdo->prepare("SELECT * FROM clientes WHERE correo = ? LIMIT 1");
            $stmt->execute([$correo]);
            $cliente = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$cliente) {
                $errores[] = 'Correo no encontrado.';
            } elseif ($password === '' || $password !== $confirm) {
                $errores[] = 'Las contraseñas no coinciden.';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
                $upd = $pdo->prepare("UPDATE clientes SET password_hash = ?, must_set_password = 0, first_login_token = NULL, first_login_expires_at = NULL WHERE id = ?");
                $upd->execute([$hash, $cliente['id']]);
                $_SESSION['cliente'] = [
                    'id' => $cliente['id'],
                    'correo' => $cliente['correo'],
                    'nombre' => $cliente['nombre']
                ];
                header('Location: dashboard.php');
                exit;
            }
        } catch (Throwable $e) {
            $errores[] = 'Error al establecer contraseña: ' . $e->getMessage();
        }
    }
}

// Si viene mid y el cliente aún no tiene password, mostrar set password guiado por correo
$showSetPassword = false;
$correoPrefill = '';
if (!empty($mid)) {
    try {
        $q = $pdo->prepare("SELECT c.* FROM membresias m JOIN clientes c ON m.cliente_id = c.id WHERE m.id = ? LIMIT 1");
        $q->execute([$mid]);
        if ($row = $q->fetch(PDO::FETCH_ASSOC)) {
            $correoPrefill = $row['correo'] ?? '';
            if (empty($row['password_hash']) || (int)$row['must_set_password'] === 1) {
                $showSetPassword = true;
            }
        }
    } catch (Throwable $e) {
        $errores[] = 'Error al preparar el acceso: ' . $e->getMessage();
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Portal de Clientes - Acceso</title>
    <link href="../css/modern-design-system.css" rel="stylesheet">
    <link href="../css/components.css" rel="stylesheet">
    <link href="../css/responsive.css" rel="stylesheet">
    <link href="../css/membresias.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="body-bg">
    <div class="container" style="max-width:480px; margin-top:40px;">
        <div class="main-content-boxed">
            <!-- Header con logo -->
            <div class="text-center mb-4">
                <div class="membership-card" style="padding: 20px; margin-bottom: 20px;">
                    <div class="card-header">
                        <h3 class="card-title mb-0">
                            <i class="fas fa-id-card me-2"></i>Portal de Clientes
                        </h3>
                    </div>
                    <p class="text-white mb-0" style="opacity: 0.9;">
                        <i class="fas fa-shield-alt me-2"></i>Acceso seguro a tu membresía
                    </p>
                </div>
            </div>

            <?php if (!empty($errores)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <ul class="mb-0">
                        <?php foreach ($errores as $e): ?>
                            <li><?= htmlspecialchars($e) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if ($showSetPassword): ?>
                <div class="form-section">
                    <h5 class="text-center mb-3">
                        <i class="fas fa-user-plus me-2"></i>Configurar tu cuenta
                    </h5>
                    <p class="text-muted text-center mb-4">
                        Es la primera vez que accedes. Por favor, crea una contraseña para tu cuenta.
                    </p>
                    
                    <form method="post">
                        <input type="hidden" name="accion" value="set_password">
                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-envelope me-2"></i>Correo electrónico
                            </label>
                            <input type="email" name="correo" class="form-control" value="<?= htmlspecialchars($correoPrefill) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-lock me-2"></i>Crear contraseña
                            </label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">
                                <i class="fas fa-check-circle me-2"></i>Confirmar contraseña
                            </label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <button class="btn btn-primary w-100" type="submit">
                            <i class="fas fa-save me-2"></i>Guardar y continuar
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <div class="form-section">
                    <h5 class="text-center mb-3">
                        <i class="fas fa-sign-in-alt me-2"></i>Iniciar sesión
                    </h5>
                    <p class="text-muted text-center mb-4">
                        Ingresa tus credenciales para acceder a tu membresía
                    </p>
                    
                    <form method="post">
                        <input type="hidden" name="accion" value="login">
                        <div class="mb-3">
                            <label class="form-label">
                                <i class="fas fa-envelope me-2"></i>Correo electrónico
                            </label>
                            <input type="email" name="correo" class="form-control" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label">
                                <i class="fas fa-lock me-2"></i>Contraseña
                            </label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button class="btn btn-primary w-100" type="submit">
                            <i class="fas fa-sign-in-alt me-2"></i>Iniciar sesión
                        </button>
                    </form>
                </div>
            <?php endif; ?>

            <!-- Footer -->
            <div class="text-center mt-4">
                <small class="text-muted">
                    <i class="fas fa-shield-alt me-1"></i>
                    Tu información está protegida con encriptación SSL
                </small>
            </div>
        </div>
    </div>

    <script>
        // Agregar efectos visuales
        document.addEventListener('DOMContentLoaded', function() {
            // Efecto de focus en los inputs
            const inputs = document.querySelectorAll('.form-control');
            inputs.forEach(input => {
                input.addEventListener('focus', function() {
                    this.parentElement.style.transform = 'scale(1.02)';
                    this.parentElement.style.transition = 'transform 0.2s ease';
                });
                
                input.addEventListener('blur', function() {
                    this.parentElement.style.transform = 'scale(1)';
                });
            });
            
            // Validación en tiempo real para confirmar contraseña
            const passwordInput = document.querySelector('input[name="password"]');
            const confirmInput = document.querySelector('input[name="confirm_password"]');
            
            if (passwordInput && confirmInput) {
                function validatePassword() {
                    if (confirmInput.value && passwordInput.value !== confirmInput.value) {
                        confirmInput.setCustomValidity('Las contraseñas no coinciden');
                        confirmInput.classList.add('is-invalid');
                    } else {
                        confirmInput.setCustomValidity('');
                        confirmInput.classList.remove('is-invalid');
                    }
                }
                
                passwordInput.addEventListener('input', validatePassword);
                confirmInput.addEventListener('input', validatePassword);
            }
        });
    </script>
</body>
</html>


