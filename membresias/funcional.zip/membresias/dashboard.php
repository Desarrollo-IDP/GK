<?php
session_start();

// Verificar si el cliente está logueado
if (!isset($_SESSION['cliente'])) {
    header('Location: login.php');
    exit;
}

$cliente = $_SESSION['cliente'];

// Incluir configuración de base de datos
require_once '../config/database_config.php';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Obtener datos reales de la membresía del cliente
    $stmt = $pdo->prepare("
        SELECT 
            m.id,
            m.plan_id,
            m.estado,
            m.fecha_inicio,
            m.fecha_fin,
            p.nombre as plan_nombre,
            p.precio,
            p.descripcion
        FROM membresias m
        LEFT JOIN planes p ON m.plan_id = p.id
        WHERE m.cliente_id = ?
        ORDER BY m.fecha_inicio DESC
        LIMIT 1
    ");
    $stmt->execute([$cliente['id']]);
    $membresia = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Verificar si tiene método de pago registrado
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as tiene_metodo
        FROM metodos_pago
        WHERE cliente_id = ? AND activo = 1
    ");
    $stmt->execute([$cliente['id']]);
    $metodo_pago = $stmt->fetch(PDO::FETCH_ASSOC);
    $hasPaymentMethod = $metodo_pago['tiene_metodo'] > 0;
    
    // Si no tiene membresía, crear una por defecto
    if (!$membresia) {
        $membresia = [
            'plan_nombre' => 'Plan Básico',
            'precio' => 299.00,
            'estado' => 'pendiente',
            'fecha_inicio' => date('Y-m-d'),
            'fecha_fin' => date('Y-m-d', strtotime('+1 month'))
        ];
    }
    
} catch (PDOException $e) {
    // En caso de error, usar datos por defecto
    $membresia = [
        'plan_nombre' => 'Plan Básico',
        'precio' => 299.00,
        'estado' => 'pendiente',
        'fecha_inicio' => date('Y-m-d'),
        'fecha_fin' => date('Y-m-d', strtotime('+1 month'))
    ];
    $hasPaymentMethod = false;
    error_log("Error en dashboard: " . $e->getMessage());
}

// Procesar cambio de contraseña
if ($_POST['accion'] ?? '' === 'change_password') {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if ($new_password === $confirm_password) {
        try {
            // Verificar contraseña actual
            $stmt = $pdo->prepare("SELECT password FROM clientes WHERE id = ?");
            $stmt->execute([$cliente['id']]);
            $cliente_db = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (password_verify($current_password, $cliente_db['password'])) {
                // Actualizar contraseña
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE clientes SET password = ? WHERE id = ?");
                $stmt->execute([$hashed_password, $cliente['id']]);
                
                $mensaje = "Contraseña actualizada correctamente";
            } else {
                $error = "La contraseña actual es incorrecta";
            }
        } catch (PDOException $e) {
            $error = "Error al actualizar la contraseña";
            error_log("Error cambio contraseña: " . $e->getMessage());
        }
    } else {
        $error = "Las contraseñas no coinciden";
    }
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard de Membresías</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .header p {
            opacity: 0.9;
            font-size: 16px;
        }
        
        .content {
            padding: 30px;
        }
        
        .membership-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 20px;
            padding: 30px;
            color: white;
            position: relative;
            overflow: hidden;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        
        .membership-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 70%);
            animation: float 6s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            position: relative;
            z-index: 1;
        }
        
        .card-title {
            font-size: 24px;
            font-weight: 700;
            margin: 0;
        }
        
        .card-status {
            background: rgba(255,255,255,0.2);
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .card-details {
            margin-bottom: 25px;
            position: relative;
            z-index: 1;
        }
        
        .detail-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 14px;
        }
        
        .detail-label {
            opacity: 0.8;
        }
        
        .detail-value {
            font-weight: 600;
        }
        
        .card-actions {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            position: relative;
            z-index: 1;
        }
        
        .btn-card {
            flex: 1;
            min-width: 140px;
            padding: 12px 20px;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            text-decoration: none;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
            font-size: 14px;
        }
        
        .btn-activate {
            background: linear-gradient(45deg, #4CAF50, #45a049);
            color: white;
        }
        
        .btn-activate:hover {
            background: linear-gradient(45deg, #45a049, #4CAF50);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(76, 175, 80, 0.3);
        }
        
        .btn-activate:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .btn-payment {
            background: rgba(255,255,255,0.2);
            color: white;
            border: 2px solid rgba(255,255,255,0.3);
        }
        
        .btn-payment:hover {
            background: rgba(255,255,255,0.3);
            border-color: rgba(255,255,255,0.5);
            transform: translateY(-2px);
        }
        
        .settings-icon {
            position: fixed;
            top: 20px;
            right: 20px;
            width: 50px;
            height: 50px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            cursor: pointer;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: all 0.3s ease;
            z-index: 1000;
        }
        
        .settings-icon:hover {
            transform: rotate(90deg);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        }
        
        .settings-icon i {
            font-size: 20px;
        }
        
        .qr-section {
            background: white;
            border-radius: 20px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: none;
        }
        
        .qr-container {
            margin: 20px 0;
        }
        
        .qr-container svg {
            max-width: 200px;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .subscription-link {
            display: inline-block;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            padding: 15px 30px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 20px;
            transition: all 0.3s ease;
        }
        
        .subscription-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
            color: white;
        }
        
        /* Modal Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 2000;
        }
        
        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            position: relative;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .modal-title {
            font-size: 20px;
            font-weight: 700;
            margin: 0;
            color: #333;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
        }
        
        .modal-close:hover {
            background: #f0f0f0;
            color: #333;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        
        .btn-primary {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background: #5a6268;
        }
        
        .d-flex {
            display: flex;
        }
        
        .gap-2 {
            gap: 10px;
        }
        
        .flex-fill {
            flex: 1;
        }
        
        .me-2 {
            margin-right: 8px;
        }
        
        .mb-3 {
            margin-bottom: 15px;
        }
        
        .loading {
            position: relative;
            pointer-events: none;
        }
        
        .loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 20px;
            height: 20px;
            margin: -10px 0 0 -10px;
            border: 2px solid transparent;
            border-top: 2px solid currentColor;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .btn-success {
            background: linear-gradient(45deg, #4CAF50, #45a049) !important;
            color: white !important;
            cursor: default !important;
        }
        
        .btn-success:hover {
            background: linear-gradient(45deg, #4CAF50, #45a049) !important;
            transform: none !important;
            box-shadow: none !important;
        }
        
        .status-pending {
            background: linear-gradient(45deg, #FF9800, #F57C00);
        }
        
        .status-success {
            background: linear-gradient(45deg, #4CAF50, #45a049);
        }
        
        .status-cancelled {
            background: linear-gradient(45deg, #f44336, #d32f2f);
        }
        

        
        @media (max-width: 768px) {
            .membership-card {
                padding: 20px;
            }
            
            .card-actions {
                flex-direction: column;
            }
            
            .btn-card {
                min-width: auto;
            }
            
            .settings-icon {
                top: 15px;
                right: 15px;
                width: 45px;
                height: 45px;
            }
            
            .modal-content {
                margin: 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Settings Icon -->
    <div class="settings-icon" id="settingsIcon">
        <i class="fas fa-cog"></i>
    </div>

    <div class="container">
        <div class="header">
            <h1><i class="fas fa-id-card me-2"></i>Dashboard de Membresías</h1>
            <p>Bienvenido, <?= htmlspecialchars($cliente['nombre']) ?></p>
        </div>
        
        <div class="content">
            <?php if (isset($mensaje)): ?>
                <div class="alert alert-success"><?= $mensaje ?></div>
            <?php endif; ?>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            


            <!-- Tarjeta de Membresía -->
            <div class="membership-card">
                <div class="card-header">
                    <h3 class="card-title">
                        <i class="fas fa-id-card me-2"></i>
                        <?= htmlspecialchars($membresia['plan_nombre']) ?>
                    </h3>
                    <div class="card-status status-<?= $membresia['estado'] ?>">
                        <?= ucfirst($membresia['estado']) ?>
                    </div>
                </div>

                <div class="card-details">
                    <div class="detail-item">
                        <span class="detail-label">Plan:</span>
                        <span class="detail-value"><?= htmlspecialchars($membresia['plan_nombre']) ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Precio:</span>
                        <span class="detail-value">$<?= number_format($membresia['precio'], 2) ?> MXN</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Fecha de inicio:</span>
                        <span class="detail-value"><?= date('d/m/Y', strtotime($membresia['fecha_inicio'])) ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Fecha de fin:</span>
                        <span class="detail-value"><?= date('d/m/Y', strtotime($membresia['fecha_fin'])) ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Método de pago:</span>
                        <span class="detail-value">
                            <?php if ($hasPaymentMethod): ?>
                                <i class="fas fa-check-circle text-success"></i> Configurado
                            <?php else: ?>
                                <i class="fas fa-times-circle text-warning"></i> No configurado
                            <?php endif; ?>
                        </span>
                    </div>
                </div>

                <div class="card-actions">
                    <button class="btn-card btn-payment" id="btnPayment">
                        <i class="fas fa-credit-card me-2"></i>
                        Método de Pago
                    </button>
                    <button class="btn-card btn-activate" id="btnActivate" <?= !$hasPaymentMethod ? 'disabled' : '' ?>>
                        <i class="fas fa-play me-2"></i>
                        Activar Tarjeta
                    </button>
                </div>
            </div>

            <!-- QR Section -->
            <div class="qr-section" id="qrSection">
                <h3><i class="fas fa-qrcode me-2"></i>Código QR de Acceso</h3>
                <p>Escanea este código para acceder a tu membresía</p>
                
                <div class="qr-container">
                    <svg width="200" height="200" viewBox="0 0 200 200">
                        <rect width="200" height="200" fill="white"/>
                        <rect x="10" y="10" width="180" height="180" fill="black"/>
                        <rect x="20" y="20" width="160" height="160" fill="white"/>
                        <rect x="30" y="30" width="140" height="140" fill="black"/>
                        <rect x="40" y="40" width="120" height="120" fill="white"/>
                        <rect x="50" y="50" width="100" height="100" fill="black"/>
                        <rect x="60" y="60" width="80" height="80" fill="white"/>
                        <rect x="70" y="70" width="60" height="60" fill="black"/>
                        <rect x="80" y="80" width="40" height="40" fill="white"/>
                        <rect x="90" y="90" width="20" height="20" fill="black"/>
                    </svg>
                </div>
                
                <a href="#" class="subscription-link" target="_blank">
                    <i class="fas fa-external-link-alt me-2"></i>
                    Suscripción Mercado Pago
                </a>
            </div>
        </div>
    </div>

    <!-- Modal de Configuración -->
    <div class="modal-overlay" id="settingsModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">
                    <i class="fas fa-cog me-2"></i>Configuración
                </h3>
                <button class="modal-close" id="modalClose">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="modal-body">
                <h5><i class="fas fa-key me-2"></i>Cambiar Contraseña</h5>
                
                <form method="post" id="passwordForm">
                    <input type="hidden" name="accion" value="change_password">
                    
                    <div class="form-group">
                        <label class="form-label">Contraseña actual</label>
                        <input type="password" name="current_password" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Nueva contraseña</label>
                        <input type="password" name="new_password" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Confirmar nueva contraseña</label>
                        <input type="password" name="confirm_password" class="form-control" required>
                    </div>
                    
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary flex-fill" type="submit">
                            <i class="fas fa-save me-2"></i>Actualizar contraseña
                        </button>
                        <button class="btn btn-secondary" type="button" id="cancelBtn">
                            Cancelar
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function log(message, type = 'info') {
            console.log(`[${type.toUpperCase()}] ${message}`);
        }
        
        // Variables globales
        let isActivated = false;
        let hasPaymentMethod = <?= $hasPaymentMethod ? 'true' : 'false' ?>;
        
        // Función para verificar estado del método de pago
        function checkPaymentMethodStatus() {
            fetch('check_payment_method.php')
                .then(response => response.json())
                .then(data => {
                    hasPaymentMethod = data.hasPaymentMethod;
                    updatePaymentMethodUI();
                })
                .catch(error => {
                    console.error('Error verificando método de pago:', error);
                });
        }
        
        // Función para actualizar la UI del método de pago
        function updatePaymentMethodUI() {
            const btnActivate = document.getElementById('btnActivate');
            const paymentStatus = document.querySelector('.detail-value:last-child');
            
            if (hasPaymentMethod) {
                if (btnActivate) {
                    btnActivate.disabled = false;
                    btnActivate.title = '';
                }
                if (paymentStatus) {
                    paymentStatus.innerHTML = '<i class="fas fa-check-circle text-success"></i> Configurado';
                }
            } else {
                if (btnActivate) {
                    btnActivate.disabled = true;
                    btnActivate.title = 'Configura un método de pago primero';
                }
                if (paymentStatus) {
                    paymentStatus.innerHTML = '<i class="fas fa-times-circle text-warning"></i> No configurado';
                }
            }
        }
        
        // Funciones del modal
        function openSettingsModal() {
            log('Abriendo modal...', 'info');
            const modal = document.getElementById('settingsModal');
            if (modal) {
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
                log('Modal abierto correctamente', 'success');
            } else {
                log('ERROR: Modal no encontrado', 'error');
            }
        }
        
        function closeSettingsModal() {
            log('Cerrando modal...', 'info');
            const modal = document.getElementById('settingsModal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
                log('Modal cerrado correctamente', 'success');
            } else {
                log('ERROR: Modal no encontrado', 'error');
            }
        }
        
        // Función para activar membresía
        function activateMembership() {
            log('Activando membresía...', 'info');
            if (!hasPaymentMethod) {
                alert('Debes configurar un método de pago antes de activar tu tarjeta.');
                log('Activación bloqueada - sin método de pago', 'error');
                return;
            }
            
            const btnActivate = document.getElementById('btnActivate');
            if (!btnActivate) {
                log('ERROR: Botón activar no encontrado', 'error');
                return;
            }
            
            // Mostrar loading
            btnActivate.classList.add('loading');
            btnActivate.disabled = true;
            
            // Enviar solicitud de activación al servidor
            fetch('activate_membership.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'activate'
                })
            })
            .then(response => response.json())
            .then(data => {
                btnActivate.classList.remove('loading');
                
                if (data.success) {
                    isActivated = true;
                    
                    // Cambiar texto del botón
                    btnActivate.innerHTML = '<i class="fas fa-check me-2"></i>Tarjeta Activada';
                    btnActivate.classList.remove('btn-activate');
                    btnActivate.classList.add('btn-success');
                    btnActivate.disabled = true;
                    
                    // Mostrar QR
                    const qrSection = document.getElementById('qrSection');
                    if (qrSection) {
                        qrSection.style.display = 'block';
                        qrSection.scrollIntoView({ behavior: 'smooth' });
                    }
                    
                    log('Membresía activada correctamente', 'success');
                } else {
                    btnActivate.disabled = false;
                    alert('Error al activar la membresía: ' + (data.message || 'Error desconocido'));
                    log('Error al activar membresía: ' + data.message, 'error');
                }
            })
            .catch(error => {
                btnActivate.classList.remove('loading');
                btnActivate.disabled = false;
                alert('Error al activar la membresía');
                log('Error en activación: ' + error.message, 'error');
            });
        }
        
        // Función para ir a método de pago
        function goToPayment() {
            log('Redirigiendo a método de pago...', 'info');
            try {
                window.location.href = 'save_card.php';
                log('Redirección iniciada exitosamente', 'success');
            } catch (error) {
                log(`Error en redirección: ${error.message}`, 'error');
                alert('Error al redirigir: ' + error.message);
            }
        }
        
        // Event Listeners
        document.addEventListener('DOMContentLoaded', function() {
            log('DOM cargado, configurando eventos...', 'success');
            
            // Settings icon click
            const settingsIcon = document.getElementById('settingsIcon');
            if (settingsIcon) {
                settingsIcon.addEventListener('click', openSettingsModal);
                log('Event listener configurado para settingsIcon', 'success');
            } else {
                log('ERROR: settingsIcon no encontrado', 'error');
            }
            
            // Modal close buttons
            const modalClose = document.getElementById('modalClose');
            if (modalClose) {
                modalClose.addEventListener('click', closeSettingsModal);
                log('Event listener configurado para modalClose', 'success');
            } else {
                log('ERROR: modalClose no encontrado', 'error');
            }
            
            const cancelBtn = document.getElementById('cancelBtn');
            if (cancelBtn) {
                cancelBtn.addEventListener('click', closeSettingsModal);
                log('Event listener configurado para cancelBtn', 'success');
            } else {
                log('ERROR: cancelBtn no encontrado', 'error');
            }
            
            // Payment button click
            const btnPayment = document.getElementById('btnPayment');
            if (btnPayment) {
                btnPayment.addEventListener('click', goToPayment);
                log('Event listener configurado para btnPayment', 'success');
            } else {
                log('ERROR: btnPayment no encontrado', 'error');
            }
            
            // Activate button click
            const btnActivate = document.getElementById('btnActivate');
            if (btnActivate) {
                btnActivate.addEventListener('click', activateMembership);
                log('Event listener configurado para btnActivate', 'success');
            } else {
                log('ERROR: btnActivate no encontrado', 'error');
            }
            
            // Close modal when clicking outside
            const settingsModal = document.getElementById('settingsModal');
            if (settingsModal) {
                settingsModal.addEventListener('click', function(e) {
                    if (e.target === this) {
                        closeSettingsModal();
                    }
                });
                log('Event listener configurado para cerrar modal al hacer clic fuera', 'success');
            } else {
                log('ERROR: settingsModal no encontrado', 'error');
            }
            
            // Password form submit
            const passwordForm = document.getElementById('passwordForm');
            if (passwordForm) {
                passwordForm.addEventListener('submit', function(e) {
                    log('Formulario de contraseña enviado', 'info');
                    const submitBtn = this.querySelector('button[type="submit"]');
                    if (submitBtn) {
                        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Actualizando...';
                        submitBtn.disabled = true;
                    }
                });
                log('Event listener configurado para passwordForm', 'success');
            } else {
                log('ERROR: passwordForm no encontrado', 'error');
            }
            
            // Inicializar UI del método de pago
            updatePaymentMethodUI();
            
            // Verificar estado del método de pago cada 30 segundos
            setInterval(checkPaymentMethodStatus, 30000);
            
            log('Configuración completada - Sistema listo', 'success');
        });
        
        // Capturar errores
        window.addEventListener('error', function(e) {
            log(`ERROR JS: ${e.message} en ${e.filename}:${e.lineno}`, 'error');
        });
    </script>
</body>
</html>
