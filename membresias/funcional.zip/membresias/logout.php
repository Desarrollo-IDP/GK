<?php
include '../includes/config.php';
initConfig();
unset($_SESSION['cliente']);
// Mantener otras sesiones administrativas intactas
header('Location: login.php');
exit;
?>